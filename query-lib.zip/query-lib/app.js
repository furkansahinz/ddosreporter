/**
 * SPL Detection Library
 * Pure Vanilla JavaScript - No Dependencies
 * SOC Analyst Helper Application
 */

// =============================================================================
// STATE MANAGEMENT
// =============================================================================

const AppState = {
    rules: [],
    selectedRuleId: null,
    editingRuleId: null,
    searchQuery: '',
    theme: 'dark',
    currentView: 'default',  // default, category, severity, starred, verified, mitremap, coverage
    draggedRuleId: null,
    verifiedFilter: 'all'  // all, verified, unverified
};

// =============================================================================
// MITRE ATT&CK FRAMEWORK DATA (Official IDs)
// =============================================================================

const MITRE_ATTACK = {
    "TA0001": {
        name: "Initial Access",
        order: 1,
        techniques: {
            "T1078": "Valid Accounts",
            "T1190": "Exploit Public-Facing Application",
            "T1133": "External Remote Services",
            "T1200": "Hardware Additions",
            "T1566": "Phishing",
            "T1091": "Replication Through Removable Media",
            "T1195": "Supply Chain Compromise",
            "T1199": "Trusted Relationship"
        }
    },
    "TA0002": {
        name: "Execution",
        order: 2,
        techniques: {
            "T1059": "Command and Scripting Interpreter",
            "T1059.001": "PowerShell",
            "T1059.003": "Windows Command Shell",
            "T1059.006": "Python",
            "T1203": "Exploitation for Client Execution",
            "T1204": "User Execution",
            "T1047": "Windows Management Instrumentation",
            "T1053": "Scheduled Task/Job"
        }
    },
    "TA0003": {
        name: "Persistence",
        order: 3,
        techniques: {
            "T1098": "Account Manipulation",
            "T1197": "BITS Jobs",
            "T1547": "Boot or Logon Autostart Execution",
            "T1136": "Create Account",
            "T1543": "Create or Modify System Process",
            "T1546": "Event Triggered Execution",
            "T1574": "Hijack Execution Flow",
            "T1137": "Office Application Startup",
            "T1053": "Scheduled Task/Job",
            "T1078": "Valid Accounts"
        }
    },
    "TA0004": {
        name: "Privilege Escalation",
        order: 4,
        techniques: {
            "T1548": "Abuse Elevation Control Mechanism",
            "T1548.003": "Sudo and Sudo Caching",
            "T1134": "Access Token Manipulation",
            "T1547": "Boot or Logon Autostart Execution",
            "T1543": "Create or Modify System Process",
            "T1484": "Domain Policy Modification",
            "T1611": "Escape to Host",
            "T1068": "Exploitation for Privilege Escalation",
            "T1574": "Hijack Execution Flow",
            "T1053": "Scheduled Task/Job",
            "T1078": "Valid Accounts"
        }
    },
    "TA0005": {
        name: "Defense Evasion",
        order: 5,
        techniques: {
            "T1548": "Abuse Elevation Control Mechanism",
            "T1134": "Access Token Manipulation",
            "T1197": "BITS Jobs",
            "T1140": "Deobfuscate/Decode Files or Information",
            "T1562": "Impair Defenses",
            "T1562.001": "Disable or Modify Tools",
            "T1070": "Indicator Removal on Host",
            "T1070.001": "Clear Windows Event Logs",
            "T1070.004": "File Deletion",
            "T1202": "Indirect Command Execution",
            "T1036": "Masquerading",
            "T1112": "Modify Registry",
            "T1027": "Obfuscated Files or Information",
            "T1055": "Process Injection",
            "T1218": "Signed Binary Proxy Execution",
            "T1553": "Subvert Trust Controls",
            "T1078": "Valid Accounts"
        }
    },
    "TA0006": {
        name: "Credential Access",
        order: 6,
        techniques: {
            "T1110": "Brute Force",
            "T1110.001": "Password Guessing",
            "T1110.003": "Password Spraying",
            "T1555": "Credentials from Password Stores",
            "T1212": "Exploitation for Credential Access",
            "T1187": "Forced Authentication",
            "T1056": "Input Capture",
            "T1056.001": "Keylogging",
            "T1557": "Man-in-the-Middle",
            "T1040": "Network Sniffing",
            "T1003": "OS Credential Dumping",
            "T1003.001": "LSASS Memory",
            "T1528": "Steal Application Access Token",
            "T1539": "Steal Web Session Cookie"
        }
    },
    "TA0007": {
        name: "Discovery",
        order: 7,
        techniques: {
            "T1087": "Account Discovery",
            "T1010": "Application Window Discovery",
            "T1217": "Browser Bookmark Discovery",
            "T1580": "Cloud Infrastructure Discovery",
            "T1538": "Cloud Service Dashboard",
            "T1526": "Cloud Service Discovery",
            "T1482": "Domain Trust Discovery",
            "T1083": "File and Directory Discovery",
            "T1046": "Network Service Scanning",
            "T1135": "Network Share Discovery",
            "T1040": "Network Sniffing",
            "T1201": "Password Policy Discovery",
            "T1120": "Peripheral Device Discovery",
            "T1069": "Permission Groups Discovery",
            "T1057": "Process Discovery",
            "T1018": "Remote System Discovery",
            "T1518": "Software Discovery",
            "T1082": "System Information Discovery",
            "T1016": "System Network Configuration Discovery",
            "T1049": "System Network Connections Discovery",
            "T1033": "System Owner/User Discovery",
            "T1007": "System Service Discovery",
            "T1124": "System Time Discovery"
        }
    },
    "TA0008": {
        name: "Lateral Movement",
        order: 8,
        techniques: {
            "T1210": "Exploitation of Remote Services",
            "T1534": "Internal Spearphishing",
            "T1570": "Lateral Tool Transfer",
            "T1021": "Remote Services",
            "T1021.001": "Remote Desktop Protocol",
            "T1021.002": "SMB/Windows Admin Shares",
            "T1021.004": "SSH",
            "T1091": "Replication Through Removable Media",
            "T1072": "Software Deployment Tools",
            "T1080": "Taint Shared Content",
            "T1550": "Use Alternate Authentication Material"
        }
    },
    "TA0009": {
        name: "Collection",
        order: 9,
        techniques: {
            "T1560": "Archive Collected Data",
            "T1123": "Audio Capture",
            "T1115": "Clipboard Data",
            "T1530": "Data from Cloud Storage Object",
            "T1602": "Data from Configuration Repository",
            "T1213": "Data from Information Repositories",
            "T1005": "Data from Local System",
            "T1039": "Data from Network Shared Drive",
            "T1025": "Data from Removable Media",
            "T1114": "Email Collection",
            "T1114.002": "Remote Email Collection",
            "T1056": "Input Capture",
            "T1113": "Screen Capture",
            "T1125": "Video Capture"
        }
    },
    "TA0011": {
        name: "Command and Control",
        order: 10,
        techniques: {
            "T1071": "Application Layer Protocol",
            "T1071.001": "Web Protocols",
            "T1071.004": "DNS",
            "T1132": "Data Encoding",
            "T1001": "Data Obfuscation",
            "T1568": "Dynamic Resolution",
            "T1573": "Encrypted Channel",
            "T1008": "Fallback Channels",
            "T1105": "Ingress Tool Transfer",
            "T1104": "Multi-Stage Channels",
            "T1095": "Non-Application Layer Protocol",
            "T1571": "Non-Standard Port",
            "T1572": "Protocol Tunneling",
            "T1090": "Proxy",
            "T1219": "Remote Access Software",
            "T1205": "Traffic Signaling",
            "T1102": "Web Service"
        }
    },
    "TA0010": {
        name: "Exfiltration",
        order: 11,
        techniques: {
            "T1020": "Automated Exfiltration",
            "T1030": "Data Transfer Size Limits",
            "T1048": "Exfiltration Over Alternative Protocol",
            "T1041": "Exfiltration Over C2 Channel",
            "T1011": "Exfiltration Over Other Network Medium",
            "T1052": "Exfiltration Over Physical Medium",
            "T1567": "Exfiltration Over Web Service",
            "T1029": "Scheduled Transfer",
            "T1537": "Transfer Data to Cloud Account"
        }
    },
    "TA0040": {
        name: "Impact",
        order: 12,
        techniques: {
            "T1531": "Account Access Removal",
            "T1485": "Data Destruction",
            "T1486": "Data Encrypted for Impact",
            "T1565": "Data Manipulation",
            "T1491": "Defacement",
            "T1561": "Disk Wipe",
            "T1499": "Endpoint Denial of Service",
            "T1495": "Firmware Corruption",
            "T1490": "Inhibit System Recovery",
            "T1498": "Network Denial of Service",
            "T1496": "Resource Hijacking",
            "T1489": "Service Stop",
            "T1529": "System Shutdown/Reboot"
        }
    }
};

// Get tactic by technique ID
function getTacticByTechniqueId(techniqueId) {
    for (const [tacticId, tacticData] of Object.entries(MITRE_ATTACK)) {
        if (tacticData.techniques[techniqueId]) {
            return {
                tacticId,
                tacticName: tacticData.name,
                techniqueName: tacticData.techniques[techniqueId]
            };
        }
    }
    return null;
}

// Validate MITRE Technique ID format
function validateMitreTechniqueId(techniqueId) {
    // Format: T1234 or T1234.001
    const regex = /^T\d{4}(\.\d{3})?$/;
    return regex.test(techniqueId);
}

// Legacy: Auto-assign MITRE for old rules (backward compatibility)
function autoAssignMitre(rule) {
    const name = rule.name.toLowerCase();
    
    // Simple heuristics for backward compatibility
    if (name.includes('brute force') || name.includes('failed login')) {
        return { tacticId: 'TA0006', techniqueId: 'T1110' };
    }
    if (name.includes('privilege') || name.includes('escalation') || name.includes('sudo')) {
        return { tacticId: 'TA0004', techniqueId: 'T1548.003' };
    }
    if (name.includes('lateral')) {
        return { tacticId: 'TA0008', techniqueId: 'T1021' };
    }
    if (name.includes('exfiltration') || name.includes('data transfer')) {
        return { tacticId: 'TA0010', techniqueId: 'T1041' };
    }
    if (name.includes('malware') || name.includes('backdoor')) {
        return { tacticId: 'TA0002', techniqueId: 'T1059' };
    }
    if (name.includes('c2') || name.includes('dns tunneling') || name.includes('command and control')) {
        return { tacticId: 'TA0011', techniqueId: 'T1071' };
    }
    if (name.includes('collection') || name.includes('email')) {
        return { tacticId: 'TA0009', techniqueId: 'T1114' };
    }
    
    // Default: Discovery
    return { tacticId: 'TA0007', techniqueId: 'T1046' };
}

// =============================================================================
// INITIAL DATA - Sample SPL Queries
// =============================================================================

const INITIAL_RULES = [
    {
        id: generateId(),
        name: 'Brute Force Login Attempt',
        description: 'Başarısız login denemelerini tespit eder. 5 dakika içinde aynı kullanıcı için 5\'ten fazla başarısız deneme yapıldığında alarm verir.',
        category: 'Authentication',
        severity: 'High',
        query: `index=security sourcetype=auth action=failure
| stats count by user, src_ip
| where count > 5
| table user, src_ip, count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Suspicious Network Traffic',
        description: 'Anormal port kullanımı ve yüksek veri transferi tespit eder.',
        category: 'Network',
        severity: 'Critical',
        query: `index=network sourcetype=firewall
| stats sum(bytes_out) as total_bytes by src_ip, dest_port
| where total_bytes > 1000000000
| eval total_gb = round(total_bytes/1024/1024/1024, 2)
| table src_ip, dest_port, total_gb`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Malware File Detection',
        description: 'Zararlı dosya hash\'lerini tespit eder ve ilgili host bilgilerini gösterir.',
        category: 'Malware',
        severity: 'Critical',
        query: `index=endpoint sourcetype=antivirus action=blocked
| stats count by file_hash, file_name, host
| lookup malware_hashes.csv hash as file_hash OUTPUT threat_name
| where isnotnull(threat_name)
| table host, file_name, file_hash, threat_name, count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Privilege Escalation Attempt',
        description: 'Yetki yükseltme girişimlerini tespit eder (sudo, runas, vb.)',
        category: 'Privilege Escalation',
        severity: 'High',
        query: `index=linux sourcetype=secure (sudo OR su)
| rex field=_raw "(?<command>sudo\\s+.+|su\\s+.+)"
| stats count by user, host, command
| where count > 3
| table _time, user, host, command, count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Data Exfiltration via Email',
        description: 'Büyük dosya ekli email gönderimlerini tespit eder.',
        category: 'Data Exfiltration',
        severity: 'Medium',
        query: `index=email sourcetype=mail
| where attachment_size > 10485760
| eval size_mb = round(attachment_size/1024/1024, 2)
| stats count, sum(size_mb) as total_mb by sender, recipient
| where total_mb > 100
| table sender, recipient, count, total_mb`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Failed VPN Authentication',
        description: 'VPN bağlantı başarısızlıklarını izler.',
        category: 'Authentication',
        severity: 'Medium',
        query: `index=vpn sourcetype=vpn_logs action=failure
| stats count by user, src_ip, reason
| where count > 3
| table _time, user, src_ip, reason, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Lateral Movement Detection',
        description: 'Ağ içinde lateral movement hareketlerini tespit eder (psexec, wmi, vb.)',
        category: 'Lateral Movement',
        severity: 'Critical',
        query: `index=windows sourcetype=WinEventLog:Security EventCode IN (4624, 4648, 4672)
| stats dc(dest_host) as unique_hosts by user
| where unique_hosts > 5
| table user, unique_hosts
| sort -unique_hosts`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'DNS Tunneling Detection',
        description: 'DNS üzerinden veri sızıntısı veya C2 iletişimi tespit eder.',
        category: 'Command & Control',
        severity: 'High',
        query: `index=dns sourcetype=dns
| eval query_length=len(query)
| where query_length > 50
| stats count, avg(query_length) as avg_len by src_ip, query
| where count > 100 OR avg_len > 75
| table src_ip, query, count, avg_len
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    
    // ========== WINDOWS / AD / AUTH ==========
    {
        id: generateId(),
        name: 'Windows - A logon was attempted using explicit credentials',
        description: 'Explicit credentials kullanılarak yapılan login girişimlerini izler (RunAs, net use vb.)',
        category: 'Windows',
        severity: 'Medium',
        query: `index=windows sourcetype=WinEventLog:Security EventCode=4648
| stats count by user, TargetUserName, dest, process
| table _time, user, TargetUserName, dest, process, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Windows - An account failed to log on',
        description: 'Windows başarısız login denemelerini tespit eder.',
        category: 'Windows',
        severity: 'High',
        query: `index=windows sourcetype=WinEventLog:Security EventCode=4625
| stats count by user, src_ip, dest, FailureReason
| where count > 3
| table _time, user, src_ip, dest, FailureReason, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Windows - An account was logged off',
        description: 'Windows hesap logoff işlemlerini izler.',
        category: 'Windows',
        severity: 'Info',
        query: `index=windows sourcetype=WinEventLog:Security EventCode=4634
| stats count by user, dest, LogonType
| table _time, user, dest, LogonType, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Windows - An account was successfully logged on',
        description: 'Windows başarılı login işlemlerini izler.',
        category: 'Windows',
        severity: 'Info',
        query: `index=windows sourcetype=WinEventLog:Security EventCode=4624
| stats count by user, src_ip, dest, LogonType
| table _time, user, src_ip, dest, LogonType, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'SGM-0014 - Windows - A user has been added or removed from the ITSecurity AD Group',
        description: 'ITSecurity Active Directory grubuna kullanıcı ekleme/çıkarma işlemlerini tespit eder.',
        category: 'Windows',
        severity: 'Critical',
        query: `index=windows sourcetype=WinEventLog:Security (EventCode=4728 OR EventCode=4729 OR EventCode=4732 OR EventCode=4733)
| search GroupName="ITSecurity" OR GroupName="IT Security"
| eval action=if(EventCode IN (4728,4732), "Added", "Removed")
| table _time, user, TargetUserName, GroupName, action, dest
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'SGM-0031 - Windows - Interactive NPA Logon Anomaly Notification',
        description: 'Non-Personal Account (NPA) üzerinden anormal interaktif login girişimlerini tespit eder.',
        category: 'Windows',
        severity: 'High',
        query: `index=windows sourcetype=WinEventLog:Security EventCode=4624 LogonType=2
| search user="NPA_*" OR user="SVC_*"
| stats count by user, src_ip, dest, _time
| where count > 1
| table _time, user, src_ip, dest, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'SGMTEST - Windows - CMC Subnet Failed Logon',
        description: 'CMC subnet\'inden gelen başarısız login denemelerini tespit eder.',
        category: 'Windows',
        severity: 'High',
        query: `index=windows sourcetype=WinEventLog:Security EventCode=4625
| search src_ip="10.10.*" OR src_ip="172.16.*"
| stats count by user, src_ip, dest
| where count > 5
| table _time, user, src_ip, dest, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'SGMTEST - Windows - An operation was attempted on a privileged object',
        description: 'Privileged object üzerinde yapılan işlem denemelerini izler.',
        category: 'Windows',
        severity: 'Medium',
        query: `index=windows sourcetype=WinEventLog:Security EventCode=4674
| stats count by user, ObjectName, ProcessName, dest
| table _time, user, ObjectName, ProcessName, dest, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Domain Users group added to Remote Desktop User on CyberArk Server',
        description: 'CyberArk sunucusunda Remote Desktop Users grubuna Domain Users eklenmesini tespit eder.',
        category: 'Windows',
        severity: 'Critical',
        query: `index=windows sourcetype=WinEventLog:Security EventCode=4732
| search dest="*CyberArk*" GroupName="Remote Desktop Users" MemberName="Domain Users"
| table _time, user, dest, GroupName, MemberName, src_ip
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },

    // ========== LINUX / UNIX ==========
    {
        id: generateId(),
        name: 'RHEL: Centrify dzdo granted',
        description: 'Centrify dzdo yetki verme işlemlerini izler.',
        category: 'Linux/Unix',
        severity: 'Medium',
        query: `index=linux sourcetype=linux_secure "dzdo" "granted"
| rex field=_raw "user=(?<user>\\S+)"
| rex field=_raw "command=(?<command>.+)"
| stats count by user, host, command
| table _time, user, host, command, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'RHEL: Centrify dzdo granted root',
        description: 'Centrify dzdo ile root yetkisi verme işlemlerini tespit eder.',
        category: 'Linux/Unix',
        severity: 'High',
        query: `index=linux sourcetype=linux_secure "dzdo" "granted" "root"
| rex field=_raw "user=(?<user>\\S+)"
| rex field=_raw "command=(?<command>.+)"
| stats count by user, host, command
| table _time, user, host, command, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Linux Server Access Over Console',
        description: 'Linux sunuculara konsol üzerinden erişimleri izler.',
        category: 'Linux/Unix',
        severity: 'Medium',
        query: `index=linux sourcetype=linux_secure "session opened" "tty"
| stats count by user, host, src_ip
| table _time, user, host, src_ip, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Remote Successful Login with Root',
        description: 'Root kullanıcısı ile uzaktan başarılı login işlemlerini tespit eder.',
        category: 'Linux/Unix',
        severity: 'Critical',
        query: `index=linux sourcetype=linux_secure user=root "Accepted"
| stats count by user, src_ip, host
| table _time, user, src_ip, host, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Successful Login After Failed Login Attempt',
        description: 'Başarısız login denemelerinden sonra başarılı login olan durumları tespit eder.',
        category: 'Linux/Unix',
        severity: 'High',
        query: `index=linux sourcetype=linux_secure
| transaction user, src_ip maxspan=5m
| search "Failed password" AND "Accepted"
| table _time, user, src_ip, host
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Successful Login After Failed Login Attempt from Same User',
        description: 'Aynı kullanıcının başarısız denemelerden sonra başarılı login olmasını izler.',
        category: 'Linux/Unix',
        severity: 'High',
        query: `index=linux sourcetype=linux_secure
| transaction user maxspan=5m
| search "Failed password" AND "Accepted"
| stats count by user, src_ip, host
| table _time, user, src_ip, host, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Unix Brute Force Login Attempt from same source to same destination',
        description: 'Aynı kaynaktan aynı hedefe brute force login denemelerini tespit eder.',
        category: 'Linux/Unix',
        severity: 'Critical',
        query: `index=linux sourcetype=linux_secure "Failed password"
| stats count by src_ip, dest, user
| where count > 10
| table _time, src_ip, dest, user, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Unix Brute Force Login Attempt from same source to different destinations',
        description: 'Aynı kaynaktan farklı hedeflere brute force login denemelerini tespit eder.',
        category: 'Linux/Unix',
        severity: 'Critical',
        query: `index=linux sourcetype=linux_secure "Failed password"
| stats dc(dest) as unique_targets, count by src_ip, user
| where unique_targets > 3 AND count > 15
| table _time, src_ip, user, unique_targets, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Unix: Multiple failed logon from same user',
        description: 'Aynı kullanıcıdan gelen çoklu başarısız login denemelerini tespit eder.',
        category: 'Linux/Unix',
        severity: 'High',
        query: `index=linux sourcetype=linux_secure "Failed password"
| stats count by user, src_ip
| where count > 5
| table _time, user, src_ip, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Anonymous FTP Connection Detected',
        description: 'Anonymous FTP bağlantılarını tespit eder.',
        category: 'Linux/Unix',
        severity: 'Medium',
        query: `index=linux sourcetype=ftp "anonymous" OR user="ftp"
| stats count by src_ip, dest, user
| table _time, src_ip, dest, user, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },

    // ========== WEB / APPLICATION / ATTACK ==========
    {
        id: generateId(),
        name: 'Suspicious URI Accessed',
        description: 'Şüpheli URI erişimlerini tespit eder (admin, backup, config vb.)',
        category: 'Web Application',
        severity: 'High',
        query: `index=web sourcetype=access_combined
| search uri IN ("*/admin/*", "*/backup/*", "*/config/*", "*/.git/*", "*/phpMyAdmin/*")
| stats count by src_ip, uri, status
| table _time, src_ip, uri, status, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Suspicious User Agent',
        description: 'Şüpheli User-Agent header değerlerini tespit eder (scanner, bot vb.)',
        category: 'Web Application',
        severity: 'Medium',
        query: `index=web sourcetype=access_combined
| search useragent IN ("*sqlmap*", "*nikto*", "*nmap*", "*masscan*", "*burp*", "*scanner*")
| stats count by src_ip, useragent, uri
| table _time, src_ip, useragent, uri, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'User Agent Inconsistency',
        description: 'Aynı IP\'den farklı User-Agent kullanımını tespit eder.',
        category: 'Web Application',
        severity: 'Medium',
        query: `index=web sourcetype=access_combined
| stats dc(useragent) as ua_count by src_ip
| where ua_count > 5
| table src_ip, ua_count
| sort -ua_count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Web Application HTTP Protocol Anomaly',
        description: 'HTTP protokol anomalilerini tespit eder (büyük header, invalid method vb.)',
        category: 'Web Application',
        severity: 'High',
        query: `index=web sourcetype=access_combined
| eval header_length=len(_raw)
| where header_length > 8192 OR method NOT IN ("GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS")
| stats count by src_ip, method, uri
| table _time, src_ip, method, uri, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Web App Suspicious Parameter Usage',
        description: 'Şüpheli parametre kullanımını tespit eder (SQL injection, XSS, command injection vb.)',
        category: 'Web Application',
        severity: 'Critical',
        query: `index=web sourcetype=access_combined
| search uri="*UNION*SELECT*" OR uri="*<script*" OR uri="*../../../*" OR uri="*cmd=*" OR uri="*exec*"
| stats count by src_ip, uri, method
| table _time, src_ip, method, uri, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Web App Unexpected Response Size',
        description: 'Beklenmedik büyüklükte response size tespit eder.',
        category: 'Web Application',
        severity: 'Medium',
        query: `index=web sourcetype=access_combined
| where bytes > 10485760
| eval size_mb = round(bytes/1024/1024, 2)
| stats count, avg(size_mb) as avg_size by src_ip, uri
| table _time, src_ip, uri, avg_size, count
| sort -avg_size`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Suspicious Request Method Usage',
        description: 'Şüpheli HTTP method kullanımını tespit eder (TRACE, CONNECT, DEBUG vb.)',
        category: 'Web Application',
        severity: 'High',
        query: `index=web sourcetype=access_combined
| search method IN ("TRACE", "CONNECT", "DEBUG", "TRACK", "PROPFIND")
| stats count by src_ip, method, uri
| table _time, src_ip, method, uri, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Suspicious File Upload',
        description: 'Şüpheli dosya yükleme işlemlerini tespit eder (.php, .jsp, .asp, .exe vb.)',
        category: 'Web Application',
        severity: 'Critical',
        query: `index=web sourcetype=access_combined method=POST
| rex field=uri "(?<filename>[^/]+\\.(php|jsp|asp|aspx|exe|sh|cmd|bat|dll))$"
| where isnotnull(filename)
| stats count by src_ip, uri, filename
| table _time, src_ip, uri, filename, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Webshell Activity Detection',
        description: 'Web shell aktivitesi tespit eder (c99, r57, WSO vb.)',
        category: 'Web Application',
        severity: 'Critical',
        query: `index=web sourcetype=access_combined
| search uri IN ("*c99.php*", "*r57.php*", "*wso.php*", "*shell.php*", "*cmd.php*", "*backdoor*")
| stats count by src_ip, uri, status
| table _time, src_ip, uri, status, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Shellshock Code Injection',
        description: 'Shellshock saldırı girişimlerini tespit eder.',
        category: 'Web Application',
        severity: 'Critical',
        query: `index=web sourcetype=access_combined
| search useragent="*() {*" OR uri="*() {*" OR referer="*() {*"
| stats count by src_ip, uri, useragent
| table _time, src_ip, uri, useragent, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Attack from Well-Known Scan Tools',
        description: 'Bilinen tarama araçlarından gelen saldırıları tespit eder.',
        category: 'Web Application',
        severity: 'High',
        query: `index=web sourcetype=access_combined
| search useragent IN ("*nmap*", "*masscan*", "*zmap*", "*acunetix*", "*nessus*", "*qualys*", "*openvas*")
| stats count by src_ip, useragent, uri
| table _time, src_ip, useragent, uri, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Suspicious Response Codes (300-310)',
        description: '300-310 arası HTTP response kodlarını izler (multiple choices, redirect anomalileri).',
        category: 'Web Application',
        severity: 'Low',
        query: `index=web sourcetype=access_combined status>=300 status<=310
| stats count by src_ip, uri, status
| table _time, src_ip, uri, status, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Suspicious Response Codes (404-505)',
        description: '404-505 arası HTTP hata kodlarını izler (scanner aktivitesi göstergesi).',
        category: 'Web Application',
        severity: 'Medium',
        query: `index=web sourcetype=access_combined status>=404 status<=505
| stats count by src_ip, uri, status
| where count > 20
| table _time, src_ip, uri, status, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Suspicious IP Address Source Match',
        description: 'Threat intelligence listesindeki kaynak IP adreslerini tespit eder.',
        category: 'Web Application',
        severity: 'Critical',
        query: `index=web sourcetype=access_combined
| lookup threat_intel.csv ip as src_ip OUTPUT threat_type, threat_score
| where isnotnull(threat_type)
| stats count by src_ip, threat_type, threat_score, uri
| table _time, src_ip, threat_type, threat_score, uri, count
| sort -threat_score`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Suspicious IP Address Destination Match',
        description: 'Threat intelligence listesindeki hedef IP adreslerine erişimi tespit eder.',
        category: 'Web Application',
        severity: 'High',
        query: `index=web sourcetype=access_combined
| lookup threat_intel.csv ip as dest_ip OUTPUT threat_type, threat_score
| where isnotnull(threat_type)
| stats count by dest_ip, threat_type, threat_score, src_ip
| table _time, src_ip, dest_ip, threat_type, threat_score, count
| sort -threat_score`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'SQL Injection sonrası: Suspicious AV Event',
        description: 'SQL Injection sonrası antivirus event tespit eder (post-exploitation göstergesi).',
        category: 'Web Application',
        severity: 'Critical',
        query: `index=web sourcetype=access_combined uri="*UNION*SELECT*" OR uri="*1=1*" 
| join src_ip [search index=endpoint sourcetype=antivirus action=blocked | fields src_ip, file_name, threat_name]
| table _time, src_ip, uri, file_name, threat_name
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'SQL Injection sonrası: User Account Created',
        description: 'SQL Injection sonrası kullanıcı hesabı oluşturma tespit eder.',
        category: 'Web Application',
        severity: 'Critical',
        query: `index=web sourcetype=access_combined uri="*UNION*SELECT*" OR uri="*1=1*"
| join src_ip [search index=windows sourcetype=WinEventLog:Security EventCode=4720 | fields src_ip, TargetUserName]
| table _time, src_ip, uri, TargetUserName
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },

    // ========== NETWORK / VPN / INFRA ==========
    {
        id: generateId(),
        name: 'TOR Network Connection Attempt',
        description: 'TOR ağına bağlantı girişimlerini tespit eder.',
        category: 'Network',
        severity: 'High',
        query: `index=network sourcetype=firewall
| lookup tor_exit_nodes.csv ip as dest_ip OUTPUT is_tor
| where is_tor="true"
| stats count by src_ip, dest_ip, dest_port
| table _time, src_ip, dest_ip, dest_port, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Rogue Wireless Device Detected',
        description: 'Yetkisiz wireless cihaz tespit eder.',
        category: 'Network',
        severity: 'Critical',
        query: `index=network sourcetype=wireless action=detected
| search NOT [| inputlookup authorized_aps.csv | fields mac_address]
| stats count by mac_address, ssid, src_ip
| table _time, mac_address, ssid, src_ip, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Rogue Device Detected',
        description: 'Ağda yetkisiz cihaz tespit eder.',
        category: 'Network',
        severity: 'Critical',
        query: `index=network sourcetype=dhcp action=request
| search NOT [| inputlookup authorized_devices.csv | fields mac_address]
| stats count by mac_address, src_ip, hostname
| table _time, mac_address, src_ip, hostname, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Span / Mirror Port Configured',
        description: 'Switch üzerinde span/mirror port konfigürasyonunu tespit eder (traffic sniffing göstergesi).',
        category: 'Network',
        severity: 'Critical',
        query: `index=network sourcetype=cisco:ios "monitor session" OR "port monitor"
| rex field=_raw "monitor session (?<session_id>\\d+)"
| stats count by host, session_id, user
| table _time, host, session_id, user, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'VPN: Host AV Check Failed',
        description: 'VPN bağlantısında host antivirus kontrolünün başarısız olmasını tespit eder.',
        category: 'VPN',
        severity: 'High',
        query: `index=vpn sourcetype=vpn_logs "av check" "failed"
| stats count by user, src_ip, host
| table _time, user, src_ip, host, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'VPN Access for Over Times (00:00-06:00)',
        description: 'Mesai dışı saatlerde (gece 00:00-06:00) VPN erişimlerini tespit eder.',
        category: 'VPN',
        severity: 'Medium',
        query: `index=vpn sourcetype=vpn_logs action=success
| eval hour=strftime(_time, "%H")
| where hour>=0 AND hour<6
| stats count by user, src_ip, hour
| table _time, user, src_ip, hour, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'VPN Access for IT Security Team',
        description: 'IT Security ekibi VPN erişimlerini izler (monitoring ve compliance için).',
        category: 'VPN',
        severity: 'Info',
        query: `index=vpn sourcetype=vpn_logs action=success
| search user IN ("*itsec*", "*security*", "*soc*")
| stats count by user, src_ip, dest
| table _time, user, src_ip, dest, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },

    // ========== DLP / MAIL / PROXY ==========
    {
        id: generateId(),
        name: 'ForcePoint DLP Closed Incident by non-MonitoringStaff',
        description: 'DLP incident\'inin monitoring staff dışındaki kullanıcılar tarafından kapatılmasını tespit eder.',
        category: 'DLP',
        severity: 'High',
        query: `index=dlp sourcetype=forcepoint action="incident_closed"
| search NOT user IN ("monitoring*", "soc*", "admin*")
| stats count by user, incident_id, severity
| table _time, user, incident_id, severity, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'ForcePoint DLP Endpoint Bypass',
        description: 'DLP endpoint bypass girişimlerini tespit eder.',
        category: 'DLP',
        severity: 'Critical',
        query: `index=dlp sourcetype=forcepoint action="bypass_attempt" OR action="agent_disabled"
| stats count by user, host, action
| table _time, user, host, action, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'ForcePoint DLP Exclusion Audit',
        description: 'DLP exclusion eklemelerini audit eder.',
        category: 'DLP',
        severity: 'Medium',
        query: `index=dlp sourcetype=forcepoint action="exclusion_added"
| stats count by user, exclusion_type, exclusion_value
| table _time, user, exclusion_type, exclusion_value, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'ForcePoint DLP Rule Deleted',
        description: 'DLP rule silme işlemlerini tespit eder.',
        category: 'DLP',
        severity: 'Critical',
        query: `index=dlp sourcetype=forcepoint action="rule_deleted"
| stats count by user, rule_name, rule_id
| table _time, user, rule_name, rule_id, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'ForcePoint DLP Rule Updated',
        description: 'DLP rule güncelleme işlemlerini izler.',
        category: 'DLP',
        severity: 'Medium',
        query: `index=dlp sourcetype=forcepoint action="rule_updated"
| stats count by user, rule_name, rule_id
| table _time, user, rule_name, rule_id, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Mail Sender External Init',
        description: 'External mail sender başlatma işlemlerini tespit eder.',
        category: 'Mail',
        severity: 'Medium',
        query: `index=email sourcetype=mail direction=outbound
| search sender="*@*" NOT sender="*@yourdomain.com"
| stats count by sender, recipient, subject
| table _time, sender, recipient, subject, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Mail Sender Set',
        description: 'Mail sender değişikliklerini izler.',
        category: 'Mail',
        severity: 'Medium',
        query: `index=email sourcetype=exchange action="sender_modified"
| stats count by user, original_sender, new_sender
| table _time, user, original_sender, new_sender, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Mail Size Calculation',
        description: 'Büyük boyutlu email gönderimlerini tespit eder.',
        category: 'Mail',
        severity: 'Low',
        query: `index=email sourcetype=mail
| eval size_mb = round(size/1024/1024, 2)
| where size_mb > 25
| stats count, sum(size_mb) as total_mb by sender, recipient
| table _time, sender, recipient, total_mb, count
| sort -total_mb`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Possible Phishing Attack Over Mail',
        description: 'Olası phishing saldırılarını tespit eder (suspicious links, attachments vb.)',
        category: 'Mail',
        severity: 'High',
        query: `index=email sourcetype=mail
| search subject IN ("*urgent*", "*verify*", "*account*", "*suspended*", "*click here*")
| search attachment IN ("*.exe", "*.scr", "*.zip", "*.js")
| stats count by sender, recipient, subject, attachment
| table _time, sender, recipient, subject, attachment, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Mailbox Read Access (Full Access)',
        description: 'Mailbox üzerinde full access yetkisi verilmesini tespit eder.',
        category: 'Mail',
        severity: 'High',
        query: `index=email sourcetype=exchange EventCode=1 action="Add-MailboxPermission"
| search AccessRights="FullAccess"
| stats count by user, mailbox, AccessRights
| table _time, user, mailbox, AccessRights, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Mailbox Disabled',
        description: 'Mailbox devre dışı bırakma işlemlerini tespit eder.',
        category: 'Mail',
        severity: 'Medium',
        query: `index=email sourcetype=exchange action="Disable-Mailbox"
| stats count by user, mailbox
| table _time, user, mailbox, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Mailbox Removed / Deleted Content',
        description: 'Mailbox içerik silme işlemlerini tespit eder.',
        category: 'Mail',
        severity: 'High',
        query: `index=email sourcetype=exchange action="Remove-MailboxContent" OR action="Delete"
| stats count by user, mailbox, folder
| table _time, user, mailbox, folder, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'Suspicious File Download Attempt Over Proxy',
        description: 'Proxy üzerinden şüpheli dosya indirme girişimlerini tespit eder.',
        category: 'Proxy',
        severity: 'High',
        query: `index=proxy sourcetype=bluecoat action=allowed
| search uri IN ("*.exe", "*.dll", "*.scr", "*.bat", "*.cmd", "*.ps1", "*.vbs")
| stats count by src_ip, uri, category
| table _time, src_ip, uri, category, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },

    // ========== CYBERARK / PAM ==========
    {
        id: generateId(),
        name: 'CyberArk: Change Password Failed (Bireysel)',
        description: 'CyberArk üzerinde bireysel hesap için şifre değiştirme başarısızlığını tespit eder.',
        category: 'CyberArk/PAM',
        severity: 'High',
        query: `index=pam sourcetype=cyberark action="ChangePassword" result="failed"
| search account_type="Individual"
| stats count by user, account_name, safe
| table _time, user, account_name, safe, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: Change Password Failed (Mobil)',
        description: 'CyberArk üzerinde mobil hesap için şifre değiştirme başarısızlığını tespit eder.',
        category: 'CyberArk/PAM',
        severity: 'High',
        query: `index=pam sourcetype=cyberark action="ChangePassword" result="failed"
| search account_type="Mobile" OR account_name="MOBIL*"
| stats count by user, account_name, safe
| table _time, user, account_name, safe, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: Failed Login Attempts',
        description: 'CyberArk başarısız login denemelerini tespit eder.',
        category: 'CyberArk/PAM',
        severity: 'High',
        query: `index=pam sourcetype=cyberark action="Logon" result="failed"
| stats count by user, src_ip, reason
| where count > 3
| table _time, user, src_ip, reason, count
| sort -count`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: User Added',
        description: 'CyberArk\'a yeni kullanıcı ekleme işlemlerini izler.',
        category: 'CyberArk/PAM',
        severity: 'Medium',
        query: `index=pam sourcetype=cyberark action="AddUser"
| stats count by user, NewUserName, UserType
| table _time, user, NewUserName, UserType, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: User Removed',
        description: 'CyberArk\'tan kullanıcı silme işlemlerini tespit eder.',
        category: 'CyberArk/PAM',
        severity: 'Medium',
        query: `index=pam sourcetype=cyberark action="DeleteUser"
| stats count by user, DeletedUserName
| table _time, user, DeletedUserName, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: User Added to Group',
        description: 'CyberArk grubuna kullanıcı ekleme işlemlerini izler.',
        category: 'CyberArk/PAM',
        severity: 'Medium',
        query: `index=pam sourcetype=cyberark action="AddUserToGroup"
| stats count by user, TargetUser, GroupName
| table _time, user, TargetUser, GroupName, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: User Removed from Group',
        description: 'CyberArk grubundan kullanıcı çıkarma işlemlerini tespit eder.',
        category: 'CyberArk/PAM',
        severity: 'Medium',
        query: `index=pam sourcetype=cyberark action="RemoveUserFromGroup"
| stats count by user, TargetUser, GroupName
| table _time, user, TargetUser, GroupName, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: User Added to CyberArk NPA Group',
        description: 'CyberArk NPA (Non-Personal Account) grubuna kullanıcı ekleme işlemlerini tespit eder.',
        category: 'CyberArk/PAM',
        severity: 'High',
        query: `index=pam sourcetype=cyberark action="AddUserToGroup"
| search GroupName="*NPA*"
| stats count by user, TargetUser, GroupName
| table _time, user, TargetUser, GroupName, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: User Removed from CyberArk NPA Group',
        description: 'CyberArk NPA grubundan kullanıcı çıkarma işlemlerini tespit eder.',
        category: 'CyberArk/PAM',
        severity: 'High',
        query: `index=pam sourcetype=cyberark action="RemoveUserFromGroup"
| search GroupName="*NPA*"
| stats count by user, TargetUser, GroupName
| table _time, user, TargetUser, GroupName, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: One user retrieved by someone (Robotics)',
        description: 'Robotik hesapların şifresinin alınmasını tespit eder.',
        category: 'CyberArk/PAM',
        severity: 'Medium',
        query: `index=pam sourcetype=cyberark action="RetrievePassword"
| search account_name="*ROBOT*" OR account_name="*RPA*" OR account_name="*BOT*"
| stats count by user, account_name, safe
| table _time, user, account_name, safe, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: MOBIL users retrieved by someone',
        description: 'Mobil kullanıcı hesaplarının şifresinin alınmasını tespit eder.',
        category: 'CyberArk/PAM',
        severity: 'High',
        query: `index=pam sourcetype=cyberark action="RetrievePassword"
| search account_name="MOBIL*"
| stats count by user, account_name, safe, src_ip
| table _time, user, account_name, safe, src_ip, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: Retrieve Password Periodic',
        description: 'Periyodik şifre alımlarını tespit eder (anomali tespiti için).',
        category: 'CyberArk/PAM',
        severity: 'Medium',
        query: `index=pam sourcetype=cyberark action="RetrievePassword"
| timechart span=1h count by account_name
| where count > 10`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    },
    {
        id: generateId(),
        name: 'CyberArk: Certificate retrieved by someone',
        description: 'CyberArk üzerinden sertifika alınmasını tespit eder.',
        category: 'CyberArk/PAM',
        severity: 'High',
        query: `index=pam sourcetype=cyberark action="RetrieveCertificate" OR action="RetrieveFile"
| search file_name="*.pfx" OR file_name="*.cer" OR file_name="*.pem"
| stats count by user, account_name, file_name, safe
| table _time, user, account_name, file_name, safe, count
| sort -_time`,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    }
];

// =============================================================================
// INITIALIZATION
// =============================================================================

function init() {
    loadStateFromStorage();
    
    // Force reload if rule count is less than expected (for updates)
    // Initialize rules if empty OR if we have new rules to add
    if (AppState.rules.length === 0 || AppState.rules.length < INITIAL_RULES.length) {
        AppState.rules = INITIAL_RULES;
        saveStateToStorage();
    }
    
    // Ensure all rules have new fields (backward compatibility)
    AppState.rules = AppState.rules.map(rule => {
        // Handle MITRE field
        let mitre = rule.mitre;
        if (!mitre || !mitre.techniqueId) {
            // Auto-assign for old rules
            const auto = autoAssignMitre(rule);
            const tacticInfo = getTacticByTechniqueId(auto.techniqueId);
            mitre = {
                tacticId: auto.tacticId,
                tacticName: tacticInfo ? tacticInfo.tacticName : 'Unknown',
                techniqueId: auto.techniqueId,
                techniqueName: tacticInfo ? tacticInfo.techniqueName : 'Unknown'
            };
        }
        
        return {
            ...rule,
            isStarred: rule.isStarred !== undefined ? rule.isStarred : false,
            isActive: rule.isActive !== undefined ? rule.isActive : true,
            verified: rule.verified !== undefined ? rule.verified : false,
            verified_at: rule.verified_at || null,
            verified_by: rule.verified_by || null,
            note: rule.note || '',
            mitre: mitre
        };
    });
    saveStateToStorage();
    
    // Apply theme
    applyTheme();
    
    // Setup event listeners
    setupEventListeners();
    
    // Render initial UI
    renderRuleList();
    updateRuleCount();
}

// =============================================================================
// LOCAL STORAGE
// =============================================================================

function loadStateFromStorage() {
    try {
        const savedRules = localStorage.getItem('splunk_rules');
        const savedTheme = localStorage.getItem('splunk_theme');
        
        if (savedRules) {
            AppState.rules = JSON.parse(savedRules);
        }
        
        if (savedTheme) {
            AppState.theme = savedTheme;
        }
    } catch (error) {
        console.error('Error loading from storage:', error);
        showToast('Veri yüklenirken hata oluştu', 'error');
    }
}

function saveStateToStorage() {
    try {
        localStorage.setItem('splunk_rules', JSON.stringify(AppState.rules));
        localStorage.setItem('splunk_theme', AppState.theme);
    } catch (error) {
        console.error('Error saving to storage:', error);
        showToast('Veri kaydedilirken hata oluştu', 'error');
    }
}

// =============================================================================
// VIEW SWITCHING
// =============================================================================

function switchView(viewName) {
    console.log('=== SWITCH VIEW ===');
    console.log('Target view:', viewName);
    AppState.currentView = viewName;
    
    // Update navigation buttons
    document.querySelectorAll('.view-nav-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.view === viewName);
    });
    
    // Show/hide view containers
    const allViews = document.querySelectorAll('.view-container');
    console.log('All views found:', allViews.length);
    allViews.forEach(container => {
        console.log('Removing active from:', container.id);
        container.classList.remove('active');
    });
    
    if (viewName === 'default') {
        const defaultView = document.getElementById('defaultView');
        console.log('✓ Activating defaultView:', defaultView);
        if (defaultView) defaultView.classList.add('active');
    } else if (viewName === 'category') {
        const categoryView = document.getElementById('categoryView');
        console.log('✓ Activating categoryView:', categoryView);
        if (categoryView) {
            categoryView.classList.add('active');
            renderCategoryMap();
        }
    } else if (viewName === 'severity') {
        const severityView = document.getElementById('severityView');
        console.log('✓ Activating severityView:', severityView);
        console.log('severityView classes:', severityView?.className);
        if (severityView) {
            severityView.classList.add('active');
            console.log('After adding active:', severityView.className);
            renderSeverityMap();
        }
    } else if (viewName === 'starred') {
        const starredView = document.getElementById('starredView');
        console.log('✓ Activating starredView:', starredView);
        if (starredView) {
            starredView.classList.add('active');
            renderStarredView();
        }
    } else if (viewName === 'verified') {
        const verifiedView = document.getElementById('verifiedView');
        console.log('✓ Activating verifiedView:', verifiedView);
        if (verifiedView) {
            verifiedView.classList.add('active');
            renderVerifiedView();
        }
    } else if (viewName === 'mitremap') {
        const mitreMapView = document.getElementById('mitreMapView');
        console.log('✓ Activating mitreMapView:', mitreMapView);
        if (mitreMapView) {
            mitreMapView.classList.add('active');
            renderMitreMap();
        }
    } else if (viewName === 'coverage') {
        const coverageView = document.getElementById('coverageView');
        console.log('✓ Activating coverageView:', coverageView);
        if (coverageView) {
            coverageView.classList.add('active');
            renderCoverageDashboard();
        }
    }
    
    console.log('===================');
}

// =============================================================================
// CATEGORY MAP VIEW
// =============================================================================

function renderCategoryMap() {
    const container = document.getElementById('categoryMapContainer');
    
    // Severity order for sorting
    const severityOrder = {
        'Critical': 1,
        'High': 2,
        'Medium': 3,
        'Low': 4,
        'Info': 5
    };
    
    // Get unique categories
    const categories = [...new Set(AppState.rules.map(r => r.category))].sort();
    
    container.innerHTML = categories.map(category => {
        // Get rules for this category and sort by severity (Critical first)
        const categoryRules = AppState.rules
            .filter(r => r.category === category)
            .sort((a, b) => {
                const orderA = severityOrder[a.severity] || 999;
                const orderB = severityOrder[b.severity] || 999;
                return orderA - orderB;
            });
        
        return `
            <div class="category-section" data-category="${escapeHtml(category)}" ondrop="handleDrop(event)" ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)">
                <div class="category-header">
                    <h3 class="category-name">${escapeHtml(category)}</h3>
                    <span class="category-count">${categoryRules.length} rules</span>
                </div>
                <div class="category-cards">
                    ${categoryRules.map(rule => renderRuleCard(rule)).join('')}
                </div>
            </div>
        `;
    }).join('');
}

// =============================================================================
// SEVERITY MAP VIEW
// =============================================================================

function renderSeverityMap() {
    const container = document.getElementById('severityMapContainer');
    const severityLevels = ['Critical', 'High', 'Medium', 'Low', 'Info'];
    
    container.innerHTML = severityLevels.map(severity => {
        const severityRules = AppState.rules.filter(r => r.severity === severity);
        
        return `
            <div class="severity-section ${severity.toLowerCase()}" data-severity="${severity}" ondrop="handleDrop(event)" ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)">
                <div class="severity-header">
                    <h3 class="severity-name">${severity}</h3>
                    <span class="severity-count">${severityRules.length} rules</span>
                </div>
                <div class="severity-cards">
                    ${severityRules.map(rule => renderRuleCard(rule)).join('')}
                </div>
            </div>
        `;
    }).join('');
}

// =============================================================================
// RULE CARD RENDERING
// =============================================================================

function renderRuleCard(rule) {
    const starIcon = rule.isStarred ? '★' : '☆';
    const starClass = rule.isStarred ? 'starred' : '';
    const mitreId = rule.mitre?.techniqueId || 'N/A';
    const verifiedBadge = rule.verified ? '<span class="verified-badge" title="This rule has been tested and approved for production use">✓ VERIFIED</span>' : '';
    
    return `
        <div class="rule-card ${rule.verified ? 'verified-card' : ''}" 
             draggable="true" 
             data-rule-id="${rule.id}"
             ondragstart="handleDragStart(event)"
             ondragend="handleDragEnd(event)"
             onclick="handleCardClick(event, '${rule.id}')">
            <div class="rule-card-header">
                <span class="rule-card-id mitre-technique-badge">${mitreId}</span>
                <button class="star-btn ${starClass}" 
                        onclick="toggleStar(event, '${rule.id}')"
                        title="${rule.isStarred ? 'Remove from starred' : 'Add to starred'}">
                    ${starIcon}
                </button>
            </div>
            <div class="rule-card-name">
                ${escapeHtml(rule.name)}
                ${verifiedBadge}
            </div>
            <div class="rule-card-description">${escapeHtml(rule.description)}</div>
            <div class="rule-card-footer">
                <span class="rule-card-category">${escapeHtml(rule.category)}</span>
                <span class="rule-card-severity ${rule.severity.toLowerCase()}">${rule.severity}</span>
            </div>
        </div>
    `;
}

// =============================================================================
// DRAG & DROP HANDLERS
// =============================================================================

function handleDragStart(event) {
    const ruleId = event.target.dataset.ruleId;
    AppState.draggedRuleId = ruleId;
    event.target.classList.add('dragging');
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', ruleId);
}

function handleDragEnd(event) {
    event.target.classList.remove('dragging');
    AppState.draggedRuleId = null;
    
    // Remove all drag-over classes
    document.querySelectorAll('.drag-over').forEach(el => {
        el.classList.remove('drag-over');
    });
}

function handleDragOver(event) {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
    
    const dropZone = event.currentTarget;
    if (dropZone.classList.contains('category-section') || dropZone.classList.contains('severity-section')) {
        dropZone.classList.add('drag-over');
    }
}

function handleDragLeave(event) {
    const dropZone = event.currentTarget;
    if (!dropZone.contains(event.relatedTarget)) {
        dropZone.classList.remove('drag-over');
    }
}

function handleDrop(event) {
    event.preventDefault();
    
    const dropZone = event.currentTarget;
    dropZone.classList.remove('drag-over');
    
    const ruleId = AppState.draggedRuleId;
    if (!ruleId) return;
    
    const rule = getRuleById(ruleId);
    if (!rule) return;
    
    let updated = false;
    
    // Update category
    if (dropZone.dataset.category) {
        const newCategory = dropZone.dataset.category;
        if (rule.category !== newCategory) {
            rule.category = newCategory;
            updated = true;
        }
    }
    
    // Update severity
    if (dropZone.dataset.severity) {
        const newSeverity = dropZone.dataset.severity;
        if (rule.severity !== newSeverity) {
            rule.severity = newSeverity;
            updated = true;
        }
    }
    
    if (updated) {
        rule.updated = new Date().toISOString();
        saveStateToStorage();
        
        // Re-render current view with animation
        if (AppState.currentView === 'category') {
            renderCategoryMap();
        } else if (AppState.currentView === 'severity') {
            renderSeverityMap();
        }
        
        // Also update main view
        renderRuleList();
        if (AppState.selectedRuleId === ruleId) {
            renderRuleDetails(rule);
        }
        
        showToast('Rule updated successfully', 'success');
    }
}

// =============================================================================
// CARD CLICK HANDLER
// =============================================================================

function handleCardClick(event, ruleId) {
    // Prevent click during drag
    if (event.target.classList.contains('dragging')) {
        return;
    }
    
    // Switch to default view and select the rule
    switchView('default');
    selectRule(ruleId);
}

// =============================================================================
// SIDEBAR TOGGLE
// =============================================================================

function toggleSidebar() {
    const panelLeft = document.querySelector('.panel-left');
    const appMain = document.querySelector('.app-main');
    
    panelLeft.classList.toggle('collapsed');
    appMain.classList.toggle('sidebar-collapsed');
}

// =============================================================================
// THEME MANAGEMENT
// =============================================================================

function applyTheme() {
    const body = document.body;
    if (AppState.theme === 'light') {
        body.classList.remove('dark-theme');
        body.classList.add('light-theme');
    } else {
        body.classList.remove('light-theme');
        body.classList.add('dark-theme');
    }
}

function toggleTheme() {
    AppState.theme = AppState.theme === 'dark' ? 'light' : 'dark';
    applyTheme();
    saveStateToStorage();
}

// =============================================================================
// EVENT LISTENERS
// =============================================================================

function setupEventListeners() {
    // View navigation
    const viewButtons = document.querySelectorAll('.view-nav-btn');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', () => switchView(btn.dataset.view));
    });
    
    // Menu toggle (sidebar)
    const menuToggle = document.getElementById('menuToggle');
    menuToggle.addEventListener('click', toggleSidebar);
    
    // Export/Import buttons
    const exportBtn = document.getElementById('exportBtn');
    const importBtn = document.getElementById('importBtn');
    const importFileInput = document.getElementById('importFileInput');
    
    exportBtn.addEventListener('click', exportRules);
    importBtn.addEventListener('click', () => importFileInput.click());
    importFileInput.addEventListener('change', importRules);
    
    // Theme toggle
    const themeToggle = document.getElementById('themeToggle');
    themeToggle.addEventListener('click', toggleTheme);
    
    // Add rule button
    const addRuleBtn = document.getElementById('addRuleBtn');
    addRuleBtn.addEventListener('click', openAddRuleModal);
    
    // Search input - Real-time search (keyup)
    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('input', handleSearch);
    
    // Search clear button
    const searchClear = document.getElementById('searchClear');
    searchClear.addEventListener('click', clearSearch);
    
    // Verified filter
    const verifiedFilter = document.getElementById('verifiedFilter');
    verifiedFilter.addEventListener('change', handleVerifiedFilter);
    
    // Modal close
    const modalClose = document.getElementById('modalClose');
    const modalCancel = document.getElementById('modalCancel');
    const modalOverlay = document.getElementById('modalOverlay');
    
    modalClose.addEventListener('click', closeModal);
    modalCancel.addEventListener('click', closeModal);
    
    // Close modal on overlay click
    modalOverlay.addEventListener('click', (e) => {
        if (e.target === modalOverlay) {
            closeModal();
        }
    });
    
    // Modal form submit
    const ruleForm = document.getElementById('ruleForm');
    ruleForm.addEventListener('submit', handleFormSubmit);
    
    // MITRE Technique ID validation
    const mitreTechniqueInput = document.getElementById('mitreTechnique');
    mitreTechniqueInput.addEventListener('input', validateMitreInput);
    mitreTechniqueInput.addEventListener('blur', validateMitreInput);
    
    // Rule detail actions
    const editRuleBtn = document.getElementById('editRuleBtn');
    const deleteRuleBtn = document.getElementById('deleteRuleBtn');
    
    editRuleBtn.addEventListener('click', handleEditRule);
    deleteRuleBtn.addEventListener('click', handleDeleteRule);
    
    // Copy query button
    const copyQueryBtn = document.getElementById('copyQueryBtn');
    copyQueryBtn.addEventListener('click', handleCopyQuery);
    
    // Coverage verified-only filter
    const coverageVerifiedOnly = document.getElementById('coverageVerifiedOnly');
    if (coverageVerifiedOnly) {
        coverageVerifiedOnly.addEventListener('change', () => {
            if (AppState.currentView === 'coverage') {
                renderCoverageDashboard();
            }
        });
    }
    
    // Query editor - No auto-save (temporary edits only)
    // Removed: queryEditor.addEventListener('input', handleQueryEdit);
}

// =============================================================================
// SEARCH FUNCTIONALITY
// =============================================================================

function handleSearch(e) {
    AppState.searchQuery = e.target.value.trim().toLowerCase();
    
    // Show/hide clear button
    const searchClear = document.getElementById('searchClear');
    if (AppState.searchQuery) {
        searchClear.classList.add('visible');
    } else {
        searchClear.classList.remove('visible');
    }
    
    renderRuleList();
}

function clearSearch() {
    const searchInput = document.getElementById('searchInput');
    searchInput.value = '';
    AppState.searchQuery = '';
    
    const searchClear = document.getElementById('searchClear');
    searchClear.classList.remove('visible');
    
    renderRuleList();
}

function handleVerifiedFilter(e) {
    AppState.verifiedFilter = e.target.value;
    renderRuleList();
    updateRuleCount();
}

function filterRules() {
    let filtered = AppState.rules;
    
    // Apply verified filter
    if (AppState.verifiedFilter === 'verified') {
        filtered = filtered.filter(r => r.verified === true);
    } else if (AppState.verifiedFilter === 'unverified') {
        filtered = filtered.filter(r => r.verified !== true);
    }
    
    // Apply search query
    if (AppState.searchQuery) {
        const searchText = AppState.searchQuery;
        filtered = filtered.filter(rule => (
            rule.name.toLowerCase().includes(searchText) ||
            rule.description.toLowerCase().includes(searchText) ||
            rule.category.toLowerCase().includes(searchText) ||
            rule.severity.toLowerCase().includes(searchText) ||
            rule.query.toLowerCase().includes(searchText) ||
            (rule.mitre && rule.mitre.techniqueId.toLowerCase().includes(searchText)) ||
            (rule.mitre && rule.mitre.tacticId.toLowerCase().includes(searchText)) ||
            (rule.mitre && rule.mitre.tacticName.toLowerCase().includes(searchText)) ||
            (rule.mitre && rule.mitre.techniqueName.toLowerCase().includes(searchText))
        ));
    }
    
    return filtered;
}

// =============================================================================
// RENDER FUNCTIONS
// =============================================================================

function renderRuleList() {
    const ruleList = document.getElementById('ruleList');
    const noResults = document.getElementById('noResults');
    const filteredRules = filterRules();
    
    if (filteredRules.length === 0) {
        ruleList.innerHTML = '';
        noResults.style.display = 'block';
        return;
    }
    
    noResults.style.display = 'none';
    
    ruleList.innerHTML = filteredRules.map(rule => {
        const verifiedBadge = rule.verified ? '<span class="verified-badge" title="This rule has been tested and approved">✓ VERIFIED</span>' : '';
        
        return `
            <div class="rule-item ${rule.id === AppState.selectedRuleId ? 'active' : ''} ${rule.verified ? 'verified-card' : ''}" 
                 data-rule-id="${rule.id}"
                 onclick="selectRule('${rule.id}')">
                <div class="rule-item-name">
                    ${escapeHtml(rule.name)}
                    ${verifiedBadge}
                </div>
                <div class="rule-item-category">${escapeHtml(rule.category)}</div>
                <div class="rule-item-description">${escapeHtml(rule.description)}</div>
            </div>
        `;
    }).join('');
}

function renderRuleDetails(rule) {
    const emptyState = document.getElementById('emptyState');
    const ruleDetails = document.getElementById('ruleDetails');
    
    if (!rule) {
        emptyState.style.display = 'flex';
        ruleDetails.style.display = 'none';
        return;
    }
    
    emptyState.style.display = 'none';
    ruleDetails.style.display = 'block';
    
    document.getElementById('detailRuleName').textContent = rule.name;
    document.getElementById('detailCategory').textContent = rule.category;
    document.getElementById('detailDescription').textContent = rule.description;
    document.getElementById('detailCategoryFull').textContent = rule.category;
    
    const severityBadge = document.getElementById('detailSeverity');
    severityBadge.textContent = rule.severity;
    severityBadge.className = `severity-badge ${rule.severity.toLowerCase()}`;
    
    document.getElementById('detailCreated').textContent = formatDate(rule.created);
    document.getElementById('detailUpdated').textContent = formatDate(rule.updated);
    
    // Show MITRE info if available
    const mitreRow = document.getElementById('detailMitreRow');
    const mitreDetail = document.getElementById('detailMitre');
    
    if (rule.mitre && rule.mitre.techniqueId) {
        mitreRow.style.display = 'flex';
        mitreDetail.innerHTML = `
            <div class="mitre-detail-tactic">
                <span class="mitre-badge tactic">${rule.mitre.tacticId}</span>
                <span>${rule.mitre.tacticName}</span>
            </div>
            <div class="mitre-detail-technique">
                <span class="mitre-badge technique">${rule.mitre.techniqueId}</span>
                <span>${rule.mitre.techniqueName}</span>
            </div>
        `;
    } else {
        mitreRow.style.display = 'none';
    }
    
    // Show Verified info if verified
    const verifiedRow = document.getElementById('detailVerifiedRow');
    const verifiedInfo = document.getElementById('detailVerifiedInfo');
    
    if (rule.verified) {
        verifiedRow.style.display = 'flex';
        if (rule.verified_at) {
            verifiedInfo.textContent = `Verified on ${formatDate(rule.verified_at)}`;
        } else {
            verifiedInfo.textContent = 'Production-ready rule';
        }
    } else {
        verifiedRow.style.display = 'none';
    }
    
    // Render note section
    renderNoteSection(rule);
}

// =============================================================================
// NOTE SECTION RENDERING AND MANAGEMENT
// =============================================================================

function renderNoteSection(rule) {
    const noteText = document.getElementById('noteText');
    const noteDisplay = document.getElementById('noteDisplay');
    const noteEditor = document.getElementById('noteEditor');
    const noteEditBtn = document.getElementById('noteEditBtn');
    
    if (!noteText || !noteDisplay || !noteEditor) return;
    
    // Reset state
    noteEditor.style.display = 'none';
    noteDisplay.style.display = 'flex';
    
    if (rule.note && rule.note.trim()) {
        noteText.textContent = rule.note;
        noteText.className = 'note-text';
        noteEditBtn.style.display = 'block';
    } else {
        noteText.textContent = 'No notes added yet. Click "Edit" to add analyst notes.';
        noteText.className = 'note-text empty';
        noteEditBtn.style.display = 'block';
    }
    
    // Setup event listeners
    setupNoteListeners(rule);
}

function setupNoteListeners(rule) {
    const noteEditBtn = document.getElementById('noteEditBtn');
    const noteSaveBtn = document.getElementById('noteSaveBtn');
    const noteCancelBtn = document.getElementById('noteCancelBtn');
    const noteTextarea = document.getElementById('noteTextarea');
    
    // Remove old listeners
    const newEditBtn = noteEditBtn.cloneNode(true);
    const newSaveBtn = noteSaveBtn.cloneNode(true);
    const newCancelBtn = noteCancelBtn.cloneNode(true);
    
    noteEditBtn.parentNode.replaceChild(newEditBtn, noteEditBtn);
    noteSaveBtn.parentNode.replaceChild(newSaveBtn, noteSaveBtn);
    noteCancelBtn.parentNode.replaceChild(newCancelBtn, noteCancelBtn);
    
    // Edit button
    newEditBtn.addEventListener('click', () => {
        const noteDisplay = document.getElementById('noteDisplay');
        const noteEditor = document.getElementById('noteEditor');
        const noteTextarea = document.getElementById('noteTextarea');
        
        noteDisplay.style.display = 'none';
        noteEditor.style.display = 'block';
        noteTextarea.value = rule.note || '';
        noteTextarea.focus();
        updateCharCount();
    });
    
    // Save button
    newSaveBtn.addEventListener('click', () => {
        const noteTextarea = document.getElementById('noteTextarea');
        const newNote = noteTextarea.value.trim();
        
        rule.note = newNote;
        rule.updated = new Date().toISOString();
        saveStateToStorage();
        
        renderNoteSection(rule);
        showToast('Note saved successfully', 'success');
    });
    
    // Cancel button
    newCancelBtn.addEventListener('click', () => {
        renderNoteSection(rule);
    });
    
    // Character count
    noteTextarea.addEventListener('input', updateCharCount);
}

function updateCharCount() {
    const noteTextarea = document.getElementById('noteTextarea');
    const noteCharCount = document.getElementById('noteCharCount');
    
    if (noteTextarea && noteCharCount) {
        noteCharCount.textContent = noteTextarea.value.length;
    }
}

function renderQueryPanel(rule) {
    const queryEmptyState = document.getElementById('queryEmptyState');
    const queryPanel = document.getElementById('queryPanel');
    const queryEditor = document.getElementById('queryEditor');
    const previewSection = document.getElementById('previewSection');
    
    if (!rule) {
        queryEmptyState.style.display = 'flex';
        queryPanel.style.display = 'none';
        if (previewSection) previewSection.style.display = 'none';
        return;
    }
    
    queryEmptyState.style.display = 'none';
    queryPanel.style.display = 'flex';
    if (previewSection) previewSection.style.display = 'block';
    
    queryEditor.value = rule.query;
    
    // Setup preview toggle
    setupPreviewToggle(rule);
}

function updateRuleCount() {
    const ruleCount = document.getElementById('ruleCount');
    const filtered = filterRules();
    const total = AppState.rules.length;
    const verified = AppState.rules.filter(r => r.verified).length;
    
    if (AppState.verifiedFilter === 'all') {
        ruleCount.textContent = `${filtered.length} kural (${verified} verified)`;
    } else {
        ruleCount.textContent = `${filtered.length} kural`;
    }
}

// =============================================================================
// RULE SELECTION
// =============================================================================

function selectRule(ruleId) {
    AppState.selectedRuleId = ruleId;
    const rule = getRuleById(ruleId);
    
    renderRuleList();
    renderRuleDetails(rule);
    renderQueryPanel(rule);
}

// =============================================================================
// MODAL MANAGEMENT
// =============================================================================

function openAddRuleModal() {
    AppState.editingRuleId = null;
    
    const modalOverlay = document.getElementById('modalOverlay');
    const modalTitle = document.getElementById('modalTitle');
    const ruleForm = document.getElementById('ruleForm');
    
    modalTitle.textContent = 'Yeni Kural Ekle';
    ruleForm.reset();
    
    // Clear MITRE validation state
    const mitreInput = document.getElementById('mitreTechnique');
    const mitreFeedback = document.getElementById('mitreFeedback');
    const mitreInfo = document.getElementById('mitreInfo');
    
    if (mitreInput) {
        mitreInput.classList.remove('valid', 'invalid', 'shake');
    }
    if (mitreFeedback) {
        mitreFeedback.className = 'mitre-feedback';
        mitreFeedback.innerHTML = '';
    }
    if (mitreInfo) {
        mitreInfo.style.display = 'none';
    }
    
    modalOverlay.style.display = 'flex';
}

function openEditRuleModal(rule) {
    AppState.editingRuleId = rule.id;
    
    const modalOverlay = document.getElementById('modalOverlay');
    const modalTitle = document.getElementById('modalTitle');
    
    modalTitle.textContent = 'Kuralı Düzenle';
    
    document.getElementById('ruleName').value = rule.name;
    document.getElementById('ruleDescription').value = rule.description;
    document.getElementById('ruleCategory').value = rule.category;
    document.getElementById('ruleSeverity').value = rule.severity;
    document.getElementById('ruleQuery').value = rule.query;
    document.getElementById('ruleStarred').checked = rule.isStarred || false;
    document.getElementById('ruleVerified').checked = rule.verified || false;
    document.getElementById('mitreTechnique').value = rule.mitre?.techniqueId || '';
    
    // Trigger validation
    if (rule.mitre?.techniqueId) {
        setTimeout(() => {
            const input = document.getElementById('mitreTechnique');
            validateMitreInput({ target: input });
        }, 100);
    }
    
    modalOverlay.style.display = 'flex';
}

function closeModal() {
    const modalOverlay = document.getElementById('modalOverlay');
    const ruleForm = document.getElementById('ruleForm');
    const mitreInput = document.getElementById('mitreTechnique');
    const mitreFeedback = document.getElementById('mitreFeedback');
    const mitreInfo = document.getElementById('mitreInfo');
    
    modalOverlay.style.display = 'none';
    ruleForm.reset();
    
    // Clear MITRE validation state
    if (mitreInput) {
        mitreInput.classList.remove('valid', 'invalid', 'shake');
    }
    if (mitreFeedback) {
        mitreFeedback.className = 'mitre-feedback';
        mitreFeedback.innerHTML = '';
    }
    if (mitreInfo) {
        mitreInfo.style.display = 'none';
    }
    
    AppState.editingRuleId = null;
}

// =============================================================================
// MITRE VALIDATION
// =============================================================================

function validateMitreInput(e) {
    const input = e.target;
    const value = input.value.trim().toUpperCase();
    const feedback = document.getElementById('mitreFeedback');
    const mitreInfo = document.getElementById('mitreInfo');
    const mitreTacticInfo = document.getElementById('mitreTacticInfo');
    const mitreTechniqueInfo = document.getElementById('mitreTechniqueInfo');
    
    // Clear previous state
    input.classList.remove('valid', 'invalid', 'shake');
    feedback.className = 'mitre-feedback';
    mitreInfo.style.display = 'none';
    
    if (!value) {
        return;
    }
    
    // Validate format
    if (!validateMitreTechniqueId(value)) {
        input.classList.add('invalid', 'shake');
        feedback.className = 'mitre-feedback error';
        feedback.innerHTML = '❌ Invalid format. Use T#### or T####.### (e.g., T1110 or T1110.001)';
        return;
    }
    
    // Check if exists in MITRE database
    const tacticInfo = getTacticByTechniqueId(value);
    
    if (!tacticInfo) {
        input.classList.add('invalid', 'shake');
        feedback.className = 'mitre-feedback error';
        feedback.innerHTML = '❌ Technique ID not found in MITRE ATT&CK database';
        return;
    }
    
    // Valid!
    input.classList.add('valid');
    feedback.className = 'mitre-feedback success';
    feedback.innerHTML = '✓ Valid MITRE ATT&CK Technique ID';
    
    // Show info
    mitreInfo.style.display = 'block';
    mitreTacticInfo.textContent = `${tacticInfo.tacticId} - ${tacticInfo.tacticName}`;
    mitreTechniqueInfo.textContent = `${value} - ${tacticInfo.techniqueName}`;
}

// =============================================================================
// CRUD OPERATIONS
// =============================================================================

function handleFormSubmit(e) {
    e.preventDefault();
    
    const mitreTechniqueId = document.getElementById('mitreTechnique').value.trim().toUpperCase();
    
    // Validate MITRE
    if (!validateMitreTechniqueId(mitreTechniqueId)) {
        showToast('Invalid MITRE Technique ID format', 'error');
        return;
    }
    
    const tacticInfo = getTacticByTechniqueId(mitreTechniqueId);
    if (!tacticInfo) {
        showToast('MITRE Technique ID not found in database', 'error');
        return;
    }
    
    const isVerified = document.getElementById('ruleVerified').checked;
    
    const formData = {
        name: document.getElementById('ruleName').value.trim(),
        description: document.getElementById('ruleDescription').value.trim(),
        category: document.getElementById('ruleCategory').value,
        severity: document.getElementById('ruleSeverity').value,
        query: document.getElementById('ruleQuery').value.trim(),
        isStarred: document.getElementById('ruleStarred').checked,
        verified: isVerified,
        verified_at: isVerified ? new Date().toISOString() : null,
        verified_by: isVerified ? 'local_user' : null,
        mitre: {
            tacticId: tacticInfo.tacticId,
            tacticName: tacticInfo.tacticName,
            techniqueId: mitreTechniqueId,
            techniqueName: tacticInfo.techniqueName
        }
    };
    
    if (AppState.editingRuleId) {
        updateRule(AppState.editingRuleId, formData);
    } else {
        createRule(formData);
    }
    
    closeModal();
}

function createRule(data) {
    const newRule = {
        id: generateId(),
        ...data,
        isActive: true,
        created: new Date().toISOString(),
        updated: new Date().toISOString()
    };
    
    AppState.rules.unshift(newRule);
    saveStateToStorage();
    
    renderRuleList();
    updateRuleCount();
    
    // Auto-select the new rule
    selectRule(newRule.id);
    
    showToast('Kural başarıyla eklendi', 'success');
}

function updateRule(ruleId, data) {
    const rule = getRuleById(ruleId);
    if (!rule) return;
    
    Object.assign(rule, data, {
        updated: new Date().toISOString()
    });
    
    saveStateToStorage();
    
    renderRuleList();
    
    // Update details if this rule is selected
    if (AppState.selectedRuleId === ruleId) {
        renderRuleDetails(rule);
        renderQueryPanel(rule);
    }
    
    showToast('Kural başarıyla güncellendi', 'success');
}

function deleteRule(ruleId) {
    const ruleIndex = AppState.rules.findIndex(r => r.id === ruleId);
    if (ruleIndex === -1) return;
    
    AppState.rules.splice(ruleIndex, 1);
    saveStateToStorage();
    
    // Clear selection if deleted rule was selected
    if (AppState.selectedRuleId === ruleId) {
        AppState.selectedRuleId = null;
        renderRuleDetails(null);
        renderQueryPanel(null);
    }
    
    renderRuleList();
    updateRuleCount();
    
    showToast('Kural silindi', 'info');
}

function handleEditRule() {
    if (!AppState.selectedRuleId) return;
    const rule = getRuleById(AppState.selectedRuleId);
    if (rule) {
        openEditRuleModal(rule);
    }
}

function handleDeleteRule() {
    if (!AppState.selectedRuleId) return;
    
    const rule = getRuleById(AppState.selectedRuleId);
    if (!rule) return;
    
    if (confirm(`"${rule.name}" kuralını silmek istediğinizden emin misiniz?`)) {
        deleteRule(AppState.selectedRuleId);
    }
}

// =============================================================================
// QUERY OPERATIONS
// =============================================================================

// Query editor no longer auto-saves - temporary edits only
// Main query remains unchanged unless explicitly saved via Edit button

function handleCopyQuery() {
    const queryEditor = document.getElementById('queryEditor');
    const copyBtn = document.getElementById('copyQueryBtn');
    
    if (!queryEditor.value) {
        showToast('Kopyalanacak sorgu yok', 'error');
        return;
    }
    
    // Copy to clipboard
    navigator.clipboard.writeText(queryEditor.value).then(() => {
        // Visual feedback
        copyBtn.classList.add('copied');
        
        const originalHTML = copyBtn.innerHTML;
        copyBtn.innerHTML = `
            <svg class="btn-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
            Kopyalandı!
        `;
        
        setTimeout(() => {
            copyBtn.classList.remove('copied');
            copyBtn.innerHTML = originalHTML;
        }, 2000);
        
        showToast('Query kopyalandı', 'success');
    }).catch(err => {
        console.error('Copy failed:', err);
        showToast('Kopyalama başarısız oldu', 'error');
    });
}

// =============================================================================
// UTILITY FUNCTIONS
// =============================================================================

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function getRuleById(ruleId) {
    return AppState.rules.find(r => r.id === ruleId);
}

function formatDate(isoString) {
    const date = new Date(isoString);
    const options = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return date.toLocaleDateString('tr-TR', options);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// =============================================================================
// TOAST NOTIFICATIONS
// =============================================================================

function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toastContainer');
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const icons = {
        success: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
        error: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        info: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>'
    };
    
    toast.innerHTML = `
        ${icons[type]}
        <div class="toast-message">${escapeHtml(message)}</div>
    `;
    
    toastContainer.appendChild(toast);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => {
            toastContainer.removeChild(toast);
        }, 300);
    }, 3000);
}

// =============================================================================
// SPL PARSER & MOCK DATA GENERATOR
// =============================================================================

function parseSplTable(splQuery) {
    // Extract fields from | table command
    const tableMatch = splQuery.match(/\|\s*table\s+([^\|\n]+)/i);
    if (tableMatch) {
        return tableMatch[1].trim().split(/[\s,]+/).filter(f => f);
    }
    
    // Extract from | stats ... by ...
    const statsByMatch = splQuery.match(/\|\s*stats\s+[^|]*\s+by\s+([^\|\n]+)/i);
    if (statsByMatch) {
        const byFields = statsByMatch[1].trim().split(/[\s,]+/).filter(f => f);
        // Also get aggregation fields
        const statsMatch = splQuery.match(/\|\s*stats\s+([^|]+?)\s+by\s+/i);
        if (statsMatch) {
            const aggFields = statsMatch[1].match(/(?:count|sum|avg|max|min|dc)\s*\(?\s*(\w+)?\s*\)?\s*(?:as\s+(\w+))?/gi);
            const aggNames = [];
            if (aggFields) {
                aggFields.forEach(agg => {
                    const asMatch = agg.match(/as\s+(\w+)/i);
                    if (asMatch) {
                        aggNames.push(asMatch[1]);
                    } else if (agg.toLowerCase().startsWith('count')) {
                        aggNames.push('count');
                    } else {
                        const match = agg.match(/(?:sum|avg|max|min|dc)\s*\(?\s*(\w+)/i);
                        if (match) aggNames.push(match[1]);
                    }
                });
            }
            return [...byFields, ...aggNames];
        }
        return byFields;
    }
    
    // Default fields
    return ['_time', 'user', 'src_ip', 'dest', 'action'];
}

function generateMockValue(fieldName) {
    const field = fieldName.toLowerCase();
    
    // Time fields
    if (field.includes('time')) {
        const date = new Date(Date.now() - Math.random() * 3600000);
        return date.toISOString().split('T')[0] + ' ' + date.toTimeString().split(' ')[0].substr(0, 5);
    }
    
    // User fields
    if (field.includes('user') || field === 'account') {
        const users = ['admin01', 'svc_cert', 'john.doe', 'NPA_ROBOT01', 'security_team', 'operator'];
        return users[Math.floor(Math.random() * users.length)];
    }
    
    // IP addresses
    if (field.includes('ip') || field === 'src' || field === 'dest') {
        return `10.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
    }
    
    // Host fields
    if (field.includes('host') || field.includes('computer') || field.includes('hostname')) {
        const hosts = ['DC01', 'WIN-SRV01', 'CA-SRV01', 'WEB-APP-01', 'DB-PRIMARY', 'MAIL-01'];
        return hosts[Math.floor(Math.random() * hosts.length)];
    }
    
    // Action fields
    if (field.includes('action') || field.includes('result') || field === 'status') {
        const actions = ['success', 'failed', 'blocked', 'deleted', 'modified', 'created'];
        return actions[Math.floor(Math.random() * actions.length)];
    }
    
    // Count / numeric fields
    if (field === 'count' || field.includes('num') || field.includes('total')) {
        return Math.floor(Math.random() * 50) + 1;
    }
    
    // Bytes / size fields
    if (field.includes('byte') || field.includes('size') || field.includes('_mb') || field.includes('_gb')) {
        return Math.floor(Math.random() * 1000) + 100;
    }
    
    // Port fields
    if (field.includes('port')) {
        const ports = [80, 443, 22, 3389, 445, 3306, 8080];
        return ports[Math.floor(Math.random() * ports.length)];
    }
    
    // File fields
    if (field.includes('file')) {
        const files = ['malware.exe', 'script.ps1', 'config.xml', 'backup.zip', 'cert.pfx'];
        return files[Math.floor(Math.random() * files.length)];
    }
    
    // Process / command fields
    if (field.includes('process') || field.includes('command')) {
        const procs = ['powershell.exe', 'cmd.exe', 'sudo', 'psexec.exe', 'wmic.exe'];
        return procs[Math.floor(Math.random() * procs.length)];
    }
    
    // Default
    return `value_${Math.floor(Math.random() * 100)}`;
}

function generateMockTable(splQuery, rowCount = 5) {
    const fields = parseSplTable(splQuery);
    
    if (fields.length === 0) {
        return null;
    }
    
    const rows = [];
    for (let i = 0; i < rowCount; i++) {
        const row = {};
        fields.forEach(field => {
            row[field] = generateMockValue(field);
        });
        rows.push(row);
    }
    
    return { fields, rows };
}

function renderMockTable(tableData) {
    if (!tableData || !tableData.fields || tableData.fields.length === 0) {
        return '<p style="color: var(--text-tertiary); text-align: center; padding: 20px;">No table output detected in SPL query</p>';
    }
    
    const { fields, rows } = tableData;
    
    return `
        <div class="splunk-table">
            <table class="preview-table">
                <thead>
                    <tr>
                        ${fields.map(field => `<th>${escapeHtml(field)}</th>`).join('')}
                    </tr>
                </thead>
                <tbody>
                    ${rows.map((row, idx) => `
                        <tr style="animation-delay: ${idx * 0.05}s">
                            ${fields.map(field => `<td>${escapeHtml(String(row[field] || '-'))}</td>`).join('')}
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

// =============================================================================
// PREVIEW TOGGLE FUNCTIONALITY
// =============================================================================

function setupPreviewToggle(rule) {
    const toggleBtn = document.getElementById('previewToggle');
    const previewContent = document.getElementById('previewContent');
    const previewIcon = toggleBtn?.querySelector('.preview-icon');
    
    if (!toggleBtn || !previewContent) return;
    
    // Reset state
    previewContent.style.display = 'none';
    if (previewIcon) {
        previewIcon.style.transform = 'rotate(0deg)';
    }
    
    // Remove old listener and add new one
    const newToggleBtn = toggleBtn.cloneNode(true);
    toggleBtn.parentNode.replaceChild(newToggleBtn, toggleBtn);
    
    newToggleBtn.addEventListener('click', function() {
        const content = document.getElementById('previewContent');
        const icon = newToggleBtn.querySelector('.preview-icon');
        const span = newToggleBtn.querySelector('span');
        
        if (content.style.display === 'none') {
            // Generate and show preview
            const mockData = rule.sample_output || generateMockTable(rule.query);
            const tableWrapper = document.getElementById('previewTableWrapper');
            
            if (mockData) {
                tableWrapper.innerHTML = renderMockTable(mockData);
            } else {
                tableWrapper.innerHTML = '<p style="color: var(--text-tertiary); text-align: center; padding: 20px;">Unable to generate preview from this query</p>';
            }
            
            content.style.display = 'block';
            if (icon) icon.style.transform = 'rotate(180deg)';
            if (span) span.textContent = 'Hide Example Output';
        } else {
            content.style.display = 'none';
            if (icon) icon.style.transform = 'rotate(0deg)';
            if (span) span.textContent = 'Show Example Output';
        }
    });
}

// =============================================================================
// STAR TOGGLE FUNCTIONALITY
// =============================================================================

function toggleStar(event, ruleId) {
    event.stopPropagation();
    event.preventDefault();
    
    const rule = getRuleById(ruleId);
    if (!rule) return;
    
    rule.isStarred = !rule.isStarred;
    rule.updated = new Date().toISOString();
    saveStateToStorage();
    
    // Re-render current view
    if (AppState.currentView === 'category') {
        renderCategoryMap();
    } else if (AppState.currentView === 'severity') {
        renderSeverityMap();
    } else if (AppState.currentView === 'starred') {
        renderStarredView();
    }
    
    showToast(rule.isStarred ? 'Added to starred' : 'Removed from starred', 'success');
}

// =============================================================================
// STARRED RULES VIEW
// =============================================================================

function renderStarredView() {
    const container = document.getElementById('starredContent');
    const starredRules = AppState.rules.filter(r => r.isStarred);
    
    if (starredRules.length === 0) {
        container.innerHTML = `
            <div class="empty-state-dashboard">
                <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                </svg>
                <h3>No Starred Rules</h3>
                <p>Click the star icon on any rule to add it to your favorites</p>
            </div>
        `;
        return;
    }
    
    // Group by category
    const severityOrder = {
        'Critical': 1,
        'High': 2,
        'Medium': 3,
        'Low': 4,
        'Info': 5
    };
    
    const categories = [...new Set(starredRules.map(r => r.category))].sort();
    
    container.innerHTML = `
        <div class="starred-summary">
            <div class="stat-card">
                <div class="stat-value">${starredRules.length}</div>
                <div class="stat-label">Starred Rules</div>
            </div>
        </div>
        <div class="category-map-container">
            ${categories.map(category => {
                const categoryRules = starredRules
                    .filter(r => r.category === category)
                    .sort((a, b) => {
                        const orderA = severityOrder[a.severity] || 999;
                        const orderB = severityOrder[b.severity] || 999;
                        return orderA - orderB;
                    });
                
                return `
                    <div class="category-section">
                        <div class="category-header">
                            <h3 class="category-name">${escapeHtml(category)}</h3>
                            <span class="category-count">${categoryRules.length} rules</span>
                        </div>
                        <div class="category-cards">
                            ${categoryRules.map(rule => renderRuleCard(rule)).join('')}
                        </div>
                    </div>
                `;
            }).join('')}
        </div>
    `;
}

// =============================================================================
// VERIFIED RULES VIEW
// =============================================================================

function renderVerifiedView() {
    const container = document.getElementById('verifiedContent');
    const verifiedRules = AppState.rules.filter(r => r.verified === true);
    const totalRules = AppState.rules.length;
    
    if (verifiedRules.length === 0) {
        container.innerHTML = `
            <div class="empty-state-dashboard">
                <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                </svg>
                <h3>No Verified Rules</h3>
                <p>Mark rules as verified in the edit modal to add them here</p>
            </div>
        `;
        return;
    }
    
    // Group by category
    const severityOrder = {
        'Critical': 1,
        'High': 2,
        'Medium': 3,
        'Low': 4,
        'Info': 5
    };
    
    const categories = [...new Set(verifiedRules.map(r => r.category))].sort();
    
    container.innerHTML = `
        <div class="verified-summary">
            <div class="stat-card">
                <div class="stat-value">${verifiedRules.length}</div>
                <div class="stat-label">Verified Rules</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${Math.round((verifiedRules.length / totalRules) * 100)}%</div>
                <div class="stat-label">Coverage</div>
            </div>
        </div>
        <div class="category-map-container">
            ${categories.map(category => {
                const categoryRules = verifiedRules
                    .filter(r => r.category === category)
                    .sort((a, b) => {
                        const orderA = severityOrder[a.severity] || 999;
                        const orderB = severityOrder[b.severity] || 999;
                        return orderA - orderB;
                    });
                
                return `
                    <div class="category-section">
                        <div class="category-header">
                            <h3 class="category-name">${escapeHtml(category)}</h3>
                            <span class="category-count">${categoryRules.length} rules</span>
                        </div>
                        <div class="category-cards">
                            ${categoryRules.map(rule => renderRuleCard(rule)).join('')}
                        </div>
                    </div>
                `;
            }).join('')}
        </div>
    `;
}

// =============================================================================
// MITRE ATT&CK MAP VIEW
// =============================================================================

function renderMitreMap() {
    const container = document.getElementById('mitreMapContent');
    
    // Sort tactics by order
    const tacticOrder = Object.entries(MITRE_ATTACK).sort((a, b) => a[1].order - b[1].order);
    
    container.innerHTML = tacticOrder.map(([tacticId, tacticData]) => {
        // Get rules for this tactic
        const tacticRules = AppState.rules.filter(r => r.mitre && r.mitre.tacticId === tacticId);
        
        // Group by technique
        const techniqueGroups = {};
        tacticRules.forEach(rule => {
            const techId = rule.mitre.techniqueId;
            if (!techniqueGroups[techId]) {
                techniqueGroups[techId] = {
                    name: rule.mitre.techniqueName,
                    rules: []
                };
            }
            techniqueGroups[techId].rules.push(rule);
        });
        
        // Sort rules by severity
        const severityOrder = { 'Critical': 1, 'High': 2, 'Medium': 3, 'Low': 4, 'Info': 5 };
        Object.values(techniqueGroups).forEach(group => {
            group.rules.sort((a, b) => {
                const orderA = severityOrder[a.severity] || 999;
                const orderB = severityOrder[b.severity] || 999;
                return orderA - orderB;
            });
        });
        
        return `
            <div class="mitre-tactic-section">
                <div class="mitre-tactic-header">
                    <div class="mitre-tactic-id">${tacticId}</div>
                    <h3 class="mitre-tactic-name">${tacticData.name}</h3>
                    <span class="mitre-tactic-count">${tacticRules.length} rules</span>
                </div>
                <div class="mitre-techniques">
                    ${Object.keys(techniqueGroups).length === 0 
                        ? `<div class="mitre-empty">⚠️ No rules mapped to this tactic</div>`
                        : Object.entries(techniqueGroups).map(([techId, techData]) => `
                            <div class="mitre-technique-section">
                                <div class="mitre-technique-header">
                                    <span class="mitre-technique-id">${techId}</span>
                                    <span class="mitre-technique-name">${techData.name}</span>
                                    <span class="mitre-technique-count">${techData.rules.length}</span>
                                </div>
                                <div class="mitre-rule-cards">
                                    ${techData.rules.map(rule => `
                                        <div class="mitre-rule-card" onclick="handleCardClick(event, '${rule.id}')">
                                            <div class="mitre-rule-header">
                                                <button class="star-btn ${rule.isStarred ? 'starred' : ''}" 
                                                        onclick="toggleStar(event, '${rule.id}')"
                                                        title="${rule.isStarred ? 'Remove from starred' : 'Add to starred'}">
                                                    ${rule.isStarred ? '★' : '☆'}
                                                </button>
                                                <span class="severity-badge ${rule.severity.toLowerCase()}">${rule.severity}</span>
                                            </div>
                                            <div class="mitre-rule-name">${escapeHtml(rule.name)}</div>
                                            <div class="mitre-rule-category">${escapeHtml(rule.category)}</div>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        `).join('')
                    }
                </div>
            </div>
        `;
    }).join('');
}

// =============================================================================
// COVERAGE DASHBOARD
// =============================================================================

function renderCoverageDashboard() {
    const container = document.getElementById('dashboardContent');
    const onlyVerified = document.getElementById('coverageVerifiedOnly')?.checked || false;
    
    // Calculate statistics
    const rulesForCalc = onlyVerified ? AppState.rules.filter(r => r.verified === true) : AppState.rules;
    const totalRules = AppState.rules.length;
    const activeRules = AppState.rules.filter(r => r.isActive !== false).length;
    const starredRules = AppState.rules.filter(r => r.isStarred).length;
    const verifiedRules = AppState.rules.filter(r => r.verified === true).length;
    
    const severityCounts = {
        Critical: rulesForCalc.filter(r => r.severity === 'Critical').length,
        High: rulesForCalc.filter(r => r.severity === 'High').length,
        Medium: rulesForCalc.filter(r => r.severity === 'Medium').length,
        Low: rulesForCalc.filter(r => r.severity === 'Low').length,
        Info: rulesForCalc.filter(r => r.severity === 'Info').length
    };
    
    const categoryCounts = {};
    rulesForCalc.forEach(rule => {
        categoryCounts[rule.category] = (categoryCounts[rule.category] || 0) + 1;
    });
    
    // Calculate MITRE coverage (by real MITRE IDs)
    const tacticCoverage = {};
    const tacticOrder = Object.entries(MITRE_ATTACK).sort((a, b) => a[1].order - b[1].order);
    
    tacticOrder.forEach(([tacticId, tacticData]) => {
        const rulesForTactic = rulesForCalc.filter(r => 
            r.mitre && r.mitre.tacticId === tacticId
        ).length;
        tacticCoverage[tacticId] = {
            name: tacticData.name,
            count: rulesForTactic,
            order: tacticData.order
        };
    });
    
    const coveredTactics = Object.values(tacticCoverage).filter(t => t.count > 0).length;
    const totalTactics = Object.keys(MITRE_ATTACK).length;
    const coveragePercentage = Math.round((coveredTactics / totalTactics) * 100);
    
    const maxCategoryCount = Math.max(...Object.values(categoryCounts));
    const maxTacticCount = Math.max(...Object.values(tacticCoverage).map(t => t.count));
    
    container.innerHTML = `
        ${onlyVerified ? `
            <div class="coverage-notice">
                ✓ Showing coverage for <strong>Verified Rules Only</strong> (${verifiedRules} of ${totalRules} rules)
            </div>
        ` : ''}
        
        <!-- Summary Stats -->
        <div class="dashboard-stats">
            <div class="stat-card-large">
                <div class="stat-icon stat-icon-total">📊</div>
                <div class="stat-info">
                    <div class="stat-value">${totalRules}</div>
                    <div class="stat-label">Total Rules</div>
                </div>
            </div>
            <div class="stat-card-large">
                <div class="stat-icon stat-icon-active">✓</div>
                <div class="stat-info">
                    <div class="stat-value">${activeRules}</div>
                    <div class="stat-label">Active Rules</div>
                </div>
            </div>
            <div class="stat-card-large ${onlyVerified ? 'stat-highlighted' : ''}">
                <div class="stat-icon stat-icon-verified">✅</div>
                <div class="stat-info">
                    <div class="stat-value">${verifiedRules}</div>
                    <div class="stat-label">Verified Rules</div>
                </div>
            </div>
            <div class="stat-card-large">
                <div class="stat-icon stat-icon-starred">★</div>
                <div class="stat-info">
                    <div class="stat-value">${starredRules}</div>
                    <div class="stat-label">Starred Rules</div>
                </div>
            </div>
            <div class="stat-card-large">
                <div class="stat-icon stat-icon-coverage">🎯</div>
                <div class="stat-info">
                    <div class="stat-value">${coveragePercentage}%</div>
                    <div class="stat-label">MITRE Coverage ${onlyVerified ? '(Verified)' : ''}</div>
                </div>
            </div>
        </div>
        
        <!-- Severity Distribution -->
        <div class="dashboard-section">
            <h3 class="dashboard-section-title">Severity Distribution</h3>
            <div class="chart-container">
                ${Object.entries(severityCounts).map(([severity, count]) => {
                    const percentage = totalRules > 0 ? (count / totalRules) * 100 : 0;
                    return `
                        <div class="chart-bar-item">
                            <div class="chart-bar-label">
                                <span class="severity-badge ${severity.toLowerCase()}">${severity}</span>
                                <span class="chart-bar-value">${count}</span>
                            </div>
                            <div class="chart-bar-wrapper">
                                <div class="chart-bar chart-bar-${severity.toLowerCase()}" 
                                     style="width: ${percentage}%"
                                     data-percentage="${percentage.toFixed(1)}%"></div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
        
        <!-- Category Distribution -->
        <div class="dashboard-section">
            <h3 class="dashboard-section-title">Category Distribution</h3>
            <div class="chart-container">
                ${Object.entries(categoryCounts).map(([category, count]) => {
                    const widthPercentage = (count / maxCategoryCount) * 100;
                    return `
                        <div class="chart-bar-item">
                            <div class="chart-bar-label">
                                <span class="category-label">${category}</span>
                                <span class="chart-bar-value">${count}</span>
                            </div>
                            <div class="chart-bar-wrapper">
                                <div class="chart-bar chart-bar-category" 
                                     style="width: ${widthPercentage}%"></div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
        
        <!-- MITRE ATT&CK Coverage -->
        <div class="dashboard-section">
            <h3 class="dashboard-section-title">MITRE ATT&CK Tactic Coverage (Official Framework)</h3>
            <div class="mitre-coverage-info">
                <p>Coverage: <strong>${coveredTactics} of ${totalTactics}</strong> tactics covered (${coveragePercentage}%)</p>
                <p style="font-size: 11px; margin-top: 4px; color: var(--text-tertiary);">
                    Based on official MITRE ATT&CK Enterprise Matrix v13
                </p>
            </div>
            <div class="chart-container">
                ${tacticOrder.map(([tacticId, tacticData]) => {
                    const coverage = tacticCoverage[tacticId];
                    const widthPercentage = maxTacticCount > 0 ? (coverage.count / maxTacticCount) * 100 : 0;
                    const isCovered = coverage.count > 0;
                    return `
                        <div class="chart-bar-item ${isCovered ? '' : 'gap'}">
                            <div class="chart-bar-label">
                                <span class="tactic-label ${isCovered ? '' : 'uncovered'}">
                                    ${tacticId} - ${coverage.name}
                                </span>
                                <span class="chart-bar-value">${coverage.count}</span>
                            </div>
                            <div class="chart-bar-wrapper">
                                <div class="chart-bar ${isCovered ? 'chart-bar-mitre' : 'chart-bar-gap'}" 
                                     style="width: ${widthPercentage}%"></div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
            <div class="mitre-gaps">
                <h4 style="font-size: 13px; margin-bottom: 8px; color: var(--text-secondary);">Coverage Gaps:</h4>
                ${tacticOrder
                    .filter(([tacticId]) => tacticCoverage[tacticId].count === 0)
                    .map(([tacticId, tacticData]) => `<span class="gap-badge">⚠️ ${tacticId} - ${tacticData.name}</span>`)
                    .join('')}
                ${tacticOrder.filter(([tacticId]) => tacticCoverage[tacticId].count === 0).length === 0 
                    ? '<span style="color: var(--accent-primary); font-weight: 600;">✓ Full coverage achieved!</span>' 
                    : ''}
            </div>
        </div>
    `;
}

// =============================================================================
// EXPORT / IMPORT FUNCTIONALITY
// =============================================================================

function exportRules() {
    const dataStr = JSON.stringify(AppState.rules, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `splunk-rules-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    showToast(`Exported ${AppState.rules.length} rules`, 'success');
}

function importRules() {
    const fileInput = document.getElementById('importFileInput');
    const file = fileInput.files[0];
    
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const importedRules = JSON.parse(e.target.result);
            
            if (!Array.isArray(importedRules)) {
                throw new Error('Invalid format');
            }
            
            if (confirm(`Import ${importedRules.length} rules? This will REPLACE current rules.`)) {
                AppState.rules = importedRules;
                saveStateToStorage();
                renderRuleList();
                updateRuleCount();
                showToast(`Imported ${importedRules.length} rules successfully`, 'success');
            }
        } catch (error) {
            console.error('Import error:', error);
            showToast('Import failed. Invalid JSON file.', 'error');
        }
        
        // Reset file input
        fileInput.value = '';
    };
    
    reader.readAsText(file);
}

// =============================================================================
// GLOBAL SCOPE (for inline event handlers)
// =============================================================================

window.handleDragStart = handleDragStart;
window.handleDragEnd = handleDragEnd;
window.handleDragOver = handleDragOver;
window.handleDragLeave = handleDragLeave;
window.handleDrop = handleDrop;
window.handleCardClick = handleCardClick;
window.toggleStar = toggleStar;
window.validateMitreInput = validateMitreInput;

// =============================================================================
// START APPLICATION
// =============================================================================

// Initialize app when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
