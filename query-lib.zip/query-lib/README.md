# 🔍 SPL Detection Library

SOC analistleri için tasarlanmış, kullanıcı dostu, profesyonel bir **MITRE ATT&CK entegreli SPL Detection Kütüphane Yönetim Aracı**.

## 📋 Genel Bakış

Bu araç, Splunk kullanan SOC analistlerinin SIEM kural isimlerine göre otomatik SPL sorguları üretmesine, sorguları bir kütüphane halinde yönetmesine ve Splunk ekranında zaman kaybetmesini önlemeye yardımcı olur.

### ✨ Özellikler

- ✅ **Sıfır Bağımlılık**: Sadece HTML, CSS ve Vanilla JavaScript
- ✅ **Splunk UI'sine Benzer Tasarım**: Profesyonel ve tanıdık arayüz
- ✅ **Dark/Light Theme**: Göz yormayan tema desteği
- ✅ **Gerçek Zamanlı Arama**: ENTER tuşuna basmadan anlık filtreleme
- ✅ **CRUD İşlemleri**: Kural ekle, düzenle, sil
- ✅ **SPL Query Yönetimi**: Sorguları tek tıkla kopyala ve düzenle
- ✅ **LocalStorage**: Veriler tarayıcıda güvenle saklanır
- ✅ **Responsive Design**: Mobil ve tablet uyumlu
- ✅ **Toast Bildirimler**: Kullanıcı dostu geri bildirimler

## 🚀 Hızlı Başlangıç

### Kurulum

1. **Dosyaları indirin**
   ```bash
   git clone [repository-url]
   cd query-lib
   ```

2. **Tarayıcıda açın**
   - `index.html` dosyasını çift tıklayarak açın
   - VEYA herhangi bir web sunucusu ile çalıştırın:
     ```bash
     # Python ile
     python -m http.server 8000
     
     # Node.js ile
     npx http-server
     ```

3. **Kullanmaya başlayın!**
   - Tarayıcınızda `http://localhost:8000` adresini açın
   - Hiçbir kurulum veya bağımlılık yüklemenize gerek yok

## 📖 Kullanım Kılavuzu

### 1. Ana Arayüz

Uygulama **3 ana panel**e sahiptir:

- **Sol Panel**: Kural kütüphanesi ve arama
- **Orta Panel**: Seçili kuralın detayları
- **Sağ Panel**: SPL Query editörü

### 2. Kural Arama

- Sol üstteki arama kutusuna yazmaya başlayın
- Gerçek zamanlı filtreleme otomatik çalışır
- Kural adı, açıklama, kategori, önem seviyesi veya query içeriğinde arama yapar
- `X` butonuna tıklayarak aramayı temizleyebilirsiniz

### 3. Yeni Kural Ekleme

1. Sağ üstteki **"Yeni Kural Ekle"** butonuna tıklayın
2. Formu doldurun:
   - **Kural Adı**: Anlamlı bir isim verin (Örn: "Brute Force Login Attempt")
   - **Açıklama**: Kuralın ne yaptığını açıklayın
   - **Kategori**: Authentication, Network, Malware, vb.
   - **Önem Seviyesi**: Critical, High, Medium, Low, Info
   - **SPL Query**: Splunk sorgunuzu yazın
3. **"Kaydet"** butonuna tıklayın

### 4. Kural Düzenleme

1. Sol panelden düzenlemek istediğiniz kuralı seçin
2. Orta panelde **"Düzenle"** butonuna tıklayın
3. Değişiklikleri yapın ve **"Kaydet"**e tıklayın

### 5. Kural Silme

1. Silmek istediğiniz kuralı seçin
2. **"Sil"** butonuna tıklayın
3. Onay mesajını kabul edin

### 6. SPL Query Kullanımı

**Query Kopyalama:**
- Sağ paneldeki **"Kopyala"** butonuna tıklayın
- Query otomatik olarak panonuza kopyalanır
- Splunk arayüzüne yapıştırarak kullanın

**Query Düzenleme:**
- Sağ paneldeki textarea'da doğrudan düzenleme yapabilirsiniz
- Değişiklikler otomatik olarak kaydedilir
- Query değiştiğinde "Son Güncelleme" tarihi otomatik güncellenir

### 7. Tema Değiştirme

- Sağ üstteki **güneş/ay** ikonuna tıklayın
- Dark ↔ Light tema arasında geçiş yapın
- Tercihiniz otomatik olarak kaydedilir

## 🎨 Splunk UI Uyumluluğu

Bu araç, Splunk Enterprise arayüzüne benzer bir tasarım dili kullanır:

- ✅ Koyu gri tonlarda profesyonel palet
- ✅ Yeşil vurgu renkleri (#00a65a)
- ✅ Monospace font (query editörü için)
- ✅ Tutarlı spacing ve padding değerleri
- ✅ Splunk benzeri panel düzeni

## 📊 Örnek Kurallar

Uygulama başlangıçta 8 adet örnek kural ile gelir:

1. **Brute Force Login Attempt** - Başarısız login denemeleri
2. **Suspicious Network Traffic** - Anormal ağ trafiği
3. **Malware File Detection** - Zararlı dosya tespiti
4. **Privilege Escalation Attempt** - Yetki yükseltme
5. **Data Exfiltration via Email** - Email ile veri sızıntısı
6. **Failed VPN Authentication** - VPN bağlantı hataları
7. **Lateral Movement Detection** - Lateral movement tespiti
8. **DNS Tunneling Detection** - DNS üzerinden C2 iletişimi

## 💾 Veri Yönetimi

### LocalStorage Kullanımı

- Tüm kurallar tarayıcının **localStorage**'ında saklanır
- Tarayıcıyı kapatsanız bile verileriniz kaybolmaz
- Veriler cihazınızda yerel olarak saklanır (sunucuya gönderilmez)

### Veri Yedekleme

LocalStorage verileri tarayıcıya özeldir. Farklı tarayıcılarda veya cihazlarda kullanmak için:

1. Tarayıcı geliştirici araçlarını açın (F12)
2. Console'a gidin
3. Dışa aktarma:
   ```javascript
   console.log(JSON.stringify(localStorage.getItem('splunk_rules')));
   ```
4. İçe aktarma:
   ```javascript
   localStorage.setItem('splunk_rules', '[EXPORTED_JSON]');
   location.reload();
   ```

## 🛠️ Teknik Detaylar

### Teknoloji Stack

- **HTML5**: Semantic HTML yapısı
- **CSS3**: Modern CSS özellikleri, CSS Variables, Flexbox, Grid
- **JavaScript (ES6+)**: Vanilla JS, No frameworks

### Tarayıcı Uyumluluğu

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

### Dosya Yapısı

```
query-lib/
├── index.html          # Ana HTML dosyası
├── styles.css          # Tüm stiller (dark/light theme)
├── app.js              # Uygulama mantığı (state, CRUD, search)
└── README.md           # Bu dosya
```

### State Yönetimi

```javascript
AppState = {
    rules: [],              // Tüm kurallar
    selectedRuleId: null,   // Seçili kural ID
    editingRuleId: null,    // Düzenlenen kural ID
    searchQuery: '',        // Arama metni
    theme: 'dark'          // Tema tercihi
}
```

## 🔐 Güvenlik

- ✅ XSS koruması (HTML escaping)
- ✅ Client-side only (sunucu gerekmiyor)
- ✅ Hassas veri yok (LocalStorage'da sadece kurallar)
- ⚠️ LocalStorage limiti: ~5-10MB (binlerce kural için yeterli)

## 📱 Responsive Tasarım

### Masaüstü (>1200px)
- 3 panel yan yana
- Sol: 320px, Orta: Esnek, Sağ: 420px

### Tablet (992px - 1200px)
- 3 panel daha dar
- Sol: 280px, Orta: Esnek, Sağ: 380px

### Mobil (<992px)
- Tek sütun layout
- Sol panel üstte (kaydırılabilir)
- Orta panel gizli
- Sağ panel altta

## 🎯 SOC Kullanım Senaryoları

### Senaryo 1: Olay Müdahale
1. Bir güvenlik olayı tespit edildi
2. Tool'da ilgili kategoriyi ara (örn: "malware")
3. İlgili SPL query'i kopyala
4. Splunk'ta çalıştır ve analiz et

### Senaryo 2: Periyodik Kontrol
1. Rutin güvenlik kontrolleri için önceden hazırlanmış query'leri kullan
2. Her kategori için sorguları sırayla çalıştır
3. Anomalileri tespit et

### Senaryo 3: Yeni Kural Oluşturma
1. Threat intelligence'tan yeni bir tehdit öğrendin
2. SPL query'sini yaz
3. Tool'a ekle ve kategorize et
4. Ekip arkadaşlarınla paylaş (JSON export ile)

## 🤝 Katkıda Bulunma

Bu proje açık kaynak değildir ancak önerilerinizi iletebilirsiniz.

## 📄 Lisans

Bu proje dahili kullanım içindir.

## 👨‍💻 Geliştirici

SOC Engineer + Frontend/UI Architect + Splunk SPL Expert

---

## 🎓 Eğitim Modu (Education Module)

Yeni kullanıcılar için **interaktif tutorial** ekledik!

### Education Mode'a Geçiş

```bash
# education klasöründen
open education/index.html

# Veya
cd education
python3 -m http.server 8000
# http://localhost:8000
```

### Özellikler

- ✅ Adım adım interaktif eğitim (23 adım)
- ✅ Blur + spotlight UX
- ✅ Real-time validation
- ✅ Türkçe içerik
- ✅ Ana tool'un tam kopyası
- ✅ Doğru aksiyon yapana kadar ilerleme yok

### Ne Öğretir?

1. Library kullanımı
2. Rule ekleme/düzenleme
3. MITRE mapping
4. Arama ve filtreleme
5. Map views (Category, Severity, MITRE)
6. Starred & Verified features
7. Coverage dashboard
8. Tema değiştirme

**Süre:** ~15-20 dakika  
**Hedef:** Yeni SOC analyst onboarding

**Detaylı bilgi:** `education/README.md`

---

## 🆘 Sorun Giderme

### Kurallar görünmüyor
- Tarayıcı console'unu kontrol edin (F12)
- LocalStorage'ı temizleyin: `localStorage.clear()` ve sayfayı yenileyin
- Örnek kurallar otomatik yüklenecektir

### Theme çalışmıyor
- Tarayıcı CSS Variables desteklemiyor olabilir
- Modern bir tarayıcı kullandığınızdan emin olun

### Kopyala çalışmıyor
- HTTPS veya localhost'ta çalıştığınızdan emin olun
- Clipboard API bazı tarayıcılarda güvenli bağlantı gerektirir

### Responsive çalışmıyor
- Tarayıcı zoom seviyenizi kontrol edin (%100 olmalı)
- Tarayıcı penceresini yeniden boyutlandırın

---

**⚡ Not**: Bu araç tamamen **client-side** çalışır. Hiçbir sunucu veya backend gerektirmez. Tüm veriler tarayıcınızda güvenle saklanır.
