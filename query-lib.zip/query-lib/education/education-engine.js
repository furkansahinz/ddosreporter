/**
 * SPL Detection Library - Education Engine
 * Interactive Step-by-Step Tutorial System (Türkçe)
 */

// =============================================================================
// TUTORIAL STEPS (Türkçe)
// =============================================================================

const EDUCATION_STEPS = [
    {
        id: 'welcome',
        title: 'SPL Detection Library\'ye Hoş Geldiniz!',
        description: 'Bu interaktif eğitim size detection rule yönetiminin tüm özelliklerini öğretecek. Hazırsanız "Devam Et" butonuna tıklayın!',
        targetElement: null,
        actionType: 'manual_continue',
        waitForUser: true,
        validation: null
    },
    {
        id: 'library_intro',
        title: 'Library Ana Görünümü',
        description: 'Bu 3-panel görünüm detection rule yönetiminin kalbidir. Sol: Rule listesi, Orta: Detaylar, Sağ: SPL sorgusu. Devam etmek için "Devam Et" butonuna tıklayın.',
        targetElement: '.app-main',
        actionType: 'manual_continue',
        waitForUser: true,
        validation: null
    },
    {
        id: 'select_rule',
        title: 'Bir Rule Seçin',
        description: 'Sol paneldeki ilk rule\'a tıklayın. Rule detaylarını görmek için seçmeniz gerekiyor.',
        targetElement: '.rule-list .rule-item:first-child',
        actionType: 'click',
        validation: () => AppState.selectedRuleId !== null
    },
    {
        id: 'view_details',
        title: 'Rule Detayları',
        description: 'Orta panelde rule\'un açıklamasını, kategori, severity ve MITRE mapping bilgilerini görüyorsunuz. Devam etmek için "Devam Et" butonuna tıklayın.',
        targetElement: '.rule-details',
        actionType: 'manual_continue',
        waitForUser: true,
        validation: null
    },
    {
        id: 'view_query',
        title: 'SPL Query Paneli',
        description: 'Sağ panelde Splunk SPL sorgusu gösteriliyor. "Kopyala" butonuna tıklayarak Splunk\'a yapıştırabilirsiniz. Devam etmek için "Devam Et" butonuna tıklayın.',
        targetElement: '.query-panel',
        actionType: 'manual_continue',
        waitForUser: true,
        validation: null
    },
    {
        id: 'search_demo',
        title: 'Gerçek Zamanlı Arama',
        description: 'Sol üstteki arama kutusuna "brute" yazın. ENTER basmadan anında filtreleme çalışacak.',
        targetElement: '#searchInput',
        actionType: 'input',
        validation: () => {
            const input = document.getElementById('searchInput');
            return input && input.value.toLowerCase().includes('brute');
        }
    },
    {
        id: 'clear_search',
        title: 'Aramayı Temizleyin',
        description: 'Arama kutusunun sağındaki X butonuna tıklayın veya metni silin.',
        targetElement: '#searchClear',
        actionType: 'click',
        validation: () => {
            const input = document.getElementById('searchInput');
            return input && input.value === '';
        }
    },
    {
        id: 'add_rule_intro',
        title: 'Yeni Rule Ekleme',
        description: 'Sağ üstteki "Yeni Kural Ekle" butonuna tıklayın. Kendi detection rule\'ınızı ekleyeceksiniz.',
        targetElement: '#addRuleBtn',
        actionType: 'click',
        validation: () => {
            const modal = document.getElementById('modalOverlay');
            return modal && modal.style.display !== 'none';
        }
    },
    {
        id: 'enter_name',
        title: 'Rule Adı Girin',
        description: 'Rule name alanına "Suspicious PowerShell Activity" yazın (en az 5 karakter).',
        targetElement: '#ruleName',
        actionType: 'input',
        validation: () => {
            const input = document.getElementById('ruleName');
            return input && input.value.trim().length >= 5;
        }
    },
    {
        id: 'enter_description',
        title: 'Açıklama Ekleyin',
        description: 'Description alanına rule\'un ne tespit ettiğini yazın (en az 10 karakter).',
        targetElement: '#ruleDescription',
        actionType: 'input',
        validation: () => {
            const input = document.getElementById('ruleDescription');
            return input && input.value.trim().length >= 10;
        }
    },
    {
        id: 'select_category',
        title: 'Kategori Seçin',
        description: 'Category dropdown\'ından herhangi bir kategori seçin.',
        targetElement: '#ruleCategory',
        actionType: 'select',
        validation: () => {
            const select = document.getElementById('ruleCategory');
            return select && select.value !== '';
        }
    },
    {
        id: 'select_severity',
        title: 'Severity Seçin',
        description: 'Severity dropdown\'ından bir önem seviyesi seçin (Critical, High, Medium, Low, Info).',
        targetElement: '#ruleSeverity',
        actionType: 'select',
        validation: () => {
            const select = document.getElementById('ruleSeverity');
            return select && select.value !== '';
        }
    },
    {
        id: 'enter_query',
        title: 'SPL Query Ekleyin',
        description: 'SPL Query alanına Splunk sorgunuzu yazın. Örnek: index=windows | stats count by user',
        targetElement: '#ruleQuery',
        actionType: 'input',
        validation: () => {
            const input = document.getElementById('ruleQuery');
            return input && input.value.trim().length >= 20;
        }
    },
    {
        id: 'enter_mitre',
        title: 'MITRE Technique ID',
        description: 'MITRE ATT&CK Technique ID girin. Örnek: T1059 (format: T#### veya T####.###)',
        targetElement: '#mitreTechnique',
        actionType: 'input',
        validation: () => {
            const input = document.getElementById('mitreTechnique');
            const pattern = /^T\d{4}(\.\d{3})?$/;
            return input && pattern.test(input.value.trim().toUpperCase());
        }
    },
    {
        id: 'save_rule',
        title: 'Rule\'u Kaydedin',
        description: 'Tüm alanları doldurdunuz! Şimdi "Kaydet" butonuna tıklayarak rule\'u ekleyin.',
        targetElement: '#modalSubmit',
        actionType: 'click',
        validation: () => {
            const modal = document.getElementById('modalOverlay');
            return modal && modal.style.display === 'none';
        }
    },
    {
        id: 'category_map',
        title: 'Category Map Görünümü',
        description: 'Navigation\'da "Category Map" butonuna tıklayın. Rule\'lar kategorilere göre organize edilmiş şekilde görünecek.',
        targetElement: '#viewCategory',
        actionType: 'click',
        validation: () => AppState.currentView === 'category'
    },
    {
        id: 'severity_map',
        title: 'Severity Map (Kanban)',
        description: '"Severity Map" butonuna tıklayın. Rule\'ları kritiklik seviyelerine göre kanban tarzı göreceksiniz.',
        targetElement: '#viewSeverity',
        actionType: 'click',
        validation: () => AppState.currentView === 'severity'
    },
    {
        id: 'back_to_library',
        title: 'Library View\'a Dönün',
        description: 'Navigation\'da "Library" butonuna tıklayarak ana görünüme geri dönün.',
        targetElement: '#viewDefault',
        actionType: 'click',
        validation: () => AppState.currentView === 'default'
    },
    {
        id: 'star_feature',
        title: 'Favorilere Ekleme',
        description: 'Herhangi bir rule kartındaki ☆ ikonuna tıklayın. Rule favorilere eklenecek.',
        targetElement: '.star-btn',
        actionType: 'click',
        validation: () => {
            return AppState.rules.some(r => r.isStarred === true);
        }
    },
    {
        id: 'starred_view',
        title: 'Starred Rules Görünümü',
        description: '"Starred" butonuna tıklayın. Yıldızladığınız rule\'ları göreceksiniz.',
        targetElement: '#viewStarred',
        actionType: 'click',
        validation: () => AppState.currentView === 'starred'
    },
    {
        id: 'mitre_map',
        title: 'MITRE ATT&CK Map',
        description: '"MITRE Map" butonuna tıklayın. Rule\'lar MITRE tactics ve techniques\'e göre organize edilmiş.',
        targetElement: '#viewMitreMap',
        actionType: 'click',
        validation: () => AppState.currentView === 'mitremap'
    },
    {
        id: 'coverage_dashboard',
        title: 'Coverage Dashboard',
        description: '"Coverage" butonuna tıklayın. Detection coverage metriklerinizi ve MITRE gap analizi göreceksiniz.',
        targetElement: '#viewCoverage',
        actionType: 'click',
        validation: () => AppState.currentView === 'coverage'
    },
    {
        id: 'verified_filter',
        title: 'Verified Filter',
        description: 'Library view\'a dönün. Sol paneldeki dropdown\'dan "✓ Verified Only" seçeneğini deneyin.',
        targetElement: '#verifiedFilter',
        actionType: 'select',
        validation: () => {
            const select = document.getElementById('verifiedFilter');
            return select && select.value !== 'all';
        }
    },
    {
        id: 'theme_toggle',
        title: 'Tema Değiştirme',
        description: 'Sağ üstteki tema butonuna (☀️/🌙) tıklayarak Dark/Light mod arasında geçiş yapın.',
        targetElement: '#themeToggle',
        actionType: 'click',
        validation: () => {
            return document.body.classList.contains('light-theme');
        }
    },
    {
        id: 'completion',
        title: 'Tebrikler! 🎉',
        description: 'SPL Detection Library eğitimini tamamladınız. Artık tüm özellikleri kullanabilirsiniz!',
        targetElement: null,
        actionType: 'completion',
        validation: null
    }
];

// =============================================================================
// EDUCATION STATE
// =============================================================================

const EducationState = {
    currentStep: 0,
    totalSteps: EDUCATION_STEPS.length,
    isActive: false,
    completedSteps: []
};

// =============================================================================
// EDUCATION INITIALIZATION
// =============================================================================

function initEducation() {
    // Check if education mode
    if (document.body.dataset.education !== 'true') {
        return;
    }
    
    // Show welcome after 1 second
    setTimeout(() => {
        startEducation();
    }, 1000);
}

function startEducation() {
    EducationState.isActive = true;
    EducationState.currentStep = 0;
    showEducationStep(0);
}

// =============================================================================
// STEP DISPLAY
// =============================================================================

function showEducationStep(stepIndex) {
    if (stepIndex >= EducationState.totalSteps) {
        showCompletion();
        return;
    }
    
    const step = EDUCATION_STEPS[stepIndex];
    EducationState.currentStep = stepIndex;
    
    // Show overlay system
    const overlaySystem = document.getElementById('educationOverlaySystem');
    overlaySystem.style.display = 'block';
    
    // Update content first
    updateStepContent(step);
    updateProgress();
    
    // Small delay for DOM to update (especially after view changes)
    setTimeout(() => {
        const target = step.targetElement ? document.querySelector(step.targetElement) : null;
        
        if (target) {
            // Wait for element to be fully rendered and positioned
            requestAnimationFrame(() => {
                createSpotlight(step, target);
                positionSmartTooltip(step, target);
                addSpotlightGlow(target);
                
                // Setup validation listeners
                setupStepValidation(step);
            });
        } else {
            // No target, full overlay
            createSpotlight(step, null);
            positionSmartTooltip(step, null);
            
            if (step.actionType === 'manual_continue') {
                // Just wait for continue button
            }
        }
    }, 150);
}

function updateStepContent(step) {
    document.getElementById('stepBadge').textContent = `Adım ${EducationState.currentStep + 1}/${EducationState.totalSteps}`;
    document.getElementById('stepTitle').textContent = step.title;
    document.getElementById('stepDescription').textContent = step.description;
    
    // Clear validation
    const feedback = document.getElementById('validationFeedback');
    feedback.style.display = 'none';
    feedback.className = 'validation-feedback';
    
    // Show/hide continue button
    const btnContinue = document.getElementById('btnContinue');
    if (step.actionType === 'manual_continue' || step.actionType === 'wait') {
        btnContinue.style.display = 'inline-block';
    } else {
        btnContinue.style.display = 'none';
    }
}

function updateProgress() {
    const progress = ((EducationState.currentStep + 1) / EducationState.totalSteps) * 100;
    document.getElementById('progressBar').style.width = `${progress}%`;
    document.getElementById('progressText').textContent = `${Math.round(progress)}% Tamamlandı`;
}

function positionSmartTooltip(step, target) {
    const tooltip = document.getElementById('educationTooltip');
    const tooltipWidth = 420;
    const tooltipHeight = tooltip.offsetHeight || 400; // Approximate
    const gap = 20;
    
    if (!target) {
        // Center tooltip
        tooltip.style.top = '50%';
        tooltip.style.left = '50%';
        tooltip.style.transform = 'translate(-50%, -50%)';
        tooltip.style.position = 'fixed';
        tooltip.classList.add('visible');
        return;
    }
    
    const rect = target.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    let top, left, placement = '';
    
    // Try bottom first
    if (viewportHeight - rect.bottom > tooltipHeight + gap + 40) {
        // Place below
        top = rect.bottom + gap;
        left = rect.left + (rect.width / 2) - (tooltipWidth / 2);
        placement = 'bottom';
    }
    // Try top
    else if (rect.top > tooltipHeight + gap + 40) {
        // Place above
        top = rect.top - tooltipHeight - gap;
        left = rect.left + (rect.width / 2) - (tooltipWidth / 2);
        placement = 'top';
    }
    // Try right
    else if (viewportWidth - rect.right > tooltipWidth + gap + 40) {
        // Place right
        top = rect.top + (rect.height / 2) - (tooltipHeight / 2);
        left = rect.right + gap;
        placement = 'right';
    }
    // Try left
    else if (rect.left > tooltipWidth + gap + 40) {
        // Place left
        top = rect.top + (rect.height / 2) - (tooltipHeight / 2);
        left = rect.left - tooltipWidth - gap;
        placement = 'left';
    }
    // Fallback: top-right corner
    else {
        top = 20;
        left = viewportWidth - tooltipWidth - 20;
        placement = 'corner';
    }
    
    // Ensure tooltip stays within viewport
    if (left < 20) left = 20;
    if (left + tooltipWidth > viewportWidth - 20) {
        left = viewportWidth - tooltipWidth - 20;
    }
    if (top < 20) top = 20;
    if (top + tooltipHeight > viewportHeight - 20) {
        top = viewportHeight - tooltipHeight - 20;
    }
    
    // Apply position with animation
    tooltip.style.position = 'fixed';
    tooltip.style.top = `${top}px`;
    tooltip.style.left = `${left}px`;
    tooltip.style.transform = 'none';
    tooltip.dataset.placement = placement;
    
    // Fade in
    requestAnimationFrame(() => {
        tooltip.classList.add('visible');
    });
}

function createSpotlight(step, target) {
    const overlayTop = document.getElementById('overlayTop');
    const overlayLeft = document.getElementById('overlayLeft');
    const overlayRight = document.getElementById('overlayRight');
    const overlayBottom = document.getElementById('overlayBottom');
    
    // Remove pulse from all elements first
    document.querySelectorAll('.education-pulse, .education-glow').forEach(el => {
        el.classList.remove('education-pulse', 'education-glow');
        el.style.boxShadow = '';
    });
    
    if (!target) {
        // Full screen overlay (no spotlight hole)
        overlayTop.style.height = '100vh';
        overlayTop.style.width = '100vw';
        overlayLeft.style.width = '0';
        overlayRight.style.width = '0';
        overlayBottom.style.height = '0';
        return;
    }
    
    const rect = target.getBoundingClientRect();
    const padding = 16;
    
    // Calculate spotlight hole dimensions
    const spotlightTop = Math.max(0, rect.top - padding);
    const spotlightLeft = Math.max(0, rect.left - padding);
    const spotlightWidth = rect.width + padding * 2;
    const spotlightHeight = rect.height + padding * 2;
    const spotlightRight = spotlightLeft + spotlightWidth;
    const spotlightBottom = spotlightTop + spotlightHeight;
    
    // Position 4 overlay parts to create a hole
    overlayTop.style.top = '0';
    overlayTop.style.left = '0';
    overlayTop.style.right = '0';
    overlayTop.style.height = `${spotlightTop}px`;
    overlayTop.style.width = 'auto';
    
    overlayLeft.style.top = `${spotlightTop}px`;
    overlayLeft.style.left = '0';
    overlayLeft.style.width = `${spotlightLeft}px`;
    overlayLeft.style.height = `${spotlightHeight}px`;
    
    overlayRight.style.top = `${spotlightTop}px`;
    overlayRight.style.left = `${spotlightRight}px`;
    overlayRight.style.right = '0';
    overlayRight.style.height = `${spotlightHeight}px`;
    overlayRight.style.width = 'auto';
    
    overlayBottom.style.top = `${spotlightBottom}px`;
    overlayBottom.style.left = '0';
    overlayBottom.style.right = '0';
    overlayBottom.style.bottom = '0';
    overlayBottom.style.height = 'auto';
    overlayBottom.style.width = 'auto';
}

function addSpotlightGlow(target) {
    if (!target) return;
    
    // Add glow effect (but target remains clickable)
    target.classList.add('education-glow');
    
    // Premium subtle pulse
    target.style.transition = 'box-shadow 0.3s ease, transform 0.3s ease';
    target.style.boxShadow = '0 0 0 3px rgba(255, 255, 255, 0.8), 0 0 25px rgba(240, 173, 78, 0.5)';
    
    // Slight scale for attention
    setTimeout(() => {
        target.style.transform = 'scale(1.01)';
        setTimeout(() => {
            target.style.transform = 'scale(1)';
        }, 200);
    }, 100);
}

// =============================================================================
// STEP VALIDATION
// =============================================================================

function setupStepValidation(step) {
    // Remove old listeners (cleanup)
    const oldHandlers = document.querySelectorAll('[data-education-handler]');
    oldHandlers.forEach(el => {
        el.replaceWith(el.cloneNode(true));
    });
    
    if (step.actionType === 'manual_continue') {
        // Wait for continue button only
        return;
    }
    
    if (step.actionType === 'click') {
        setupClickValidation(step);
    } else if (step.actionType === 'input') {
        setupInputValidation(step);
    } else if (step.actionType === 'select') {
        setupSelectValidation(step);
    }
}

function setupClickValidation(step) {
    const target = document.querySelector(step.targetElement);
    if (!target) {
        console.warn('Target element not found:', step.targetElement);
        return;
    }
    
    // Mark element to track handler
    target.dataset.educationHandler = 'true';
    
    const clickHandler = (e) => {
        // Let the click work normally (don't prevent)
        
        setTimeout(() => {
            if (!step.validation || step.validation()) {
                // Remove handler immediately
                target.removeEventListener('click', clickHandler);
                
                // Success animation
                completeStepWithAnimation(target);
            } else {
                showError('Lütfen doğru aksiyonu yapın');
                target.classList.add('education-shake');
                setTimeout(() => target.classList.remove('education-shake'), 400);
            }
        }, 150);
    };
    
    // Add listener
    target.addEventListener('click', clickHandler);
}

function setupInputValidation(step) {
    const target = document.querySelector(step.targetElement);
    if (!target) {
        console.warn('Target element not found:', step.targetElement);
        return;
    }
    
    target.dataset.educationHandler = 'true';
    
    let validationTimeout = null;
    
    const inputHandler = () => {
        // Clear previous timeout
        if (validationTimeout) {
            clearTimeout(validationTimeout);
        }
        
        // Debounce validation
        validationTimeout = setTimeout(() => {
            if (step.validation && step.validation()) {
                // Remove handler immediately
                target.removeEventListener('input', inputHandler);
                
                // Success with animation
                completeStepWithAnimation(target);
            }
        }, 1000);
    };
    
    target.addEventListener('input', inputHandler);
}

function setupSelectValidation(step) {
    const target = document.querySelector(step.targetElement);
    if (!target) {
        console.warn('Target element not found:', step.targetElement);
        return;
    }
    
    target.dataset.educationHandler = 'true';
    
    const changeHandler = () => {
        setTimeout(() => {
            if (!step.validation || step.validation()) {
                // Remove handler
                target.removeEventListener('change', changeHandler);
                
                // Success with animation
                completeStepWithAnimation(target);
            } else {
                showError('Lütfen bir seçim yapın');
            }
        }, 150);
    };
    
    target.addEventListener('change', changeHandler);
}

function showSuccess() {
    const feedback = document.getElementById('validationFeedback');
    feedback.textContent = '✓ Mükemmel! Doğru adım.';
    feedback.className = 'validation-feedback success';
    feedback.style.display = 'block';
}

function completeStepWithAnimation(target) {
    // Show success feedback
    showSuccess();
    
    // Green glow on target
    if (target) {
        target.style.boxShadow = '0 0 0 4px #4CAF50, 0 0 30px rgba(76, 175, 80, 0.7)';
        target.style.transform = 'scale(1.02)';
        
        setTimeout(() => {
            target.style.transform = 'scale(1)';
        }, 200);
    }
    
    // Fade out tooltip
    const tooltip = document.getElementById('educationTooltip');
    tooltip.style.opacity = '0.5';
    
    // Wait then move to next step
    setTimeout(() => {
        tooltip.style.opacity = '1';
        nextEducationStep();
    }, 800);
}

function showError(message) {
    const feedback = document.getElementById('validationFeedback');
    feedback.textContent = '✗ ' + message;
    feedback.className = 'validation-feedback error';
    feedback.style.display = 'block';
    
    // Shake animation
    const target = document.querySelector('.education-pulse');
    if (target) {
        target.classList.add('education-shake');
        setTimeout(() => target.classList.remove('education-shake'), 400);
    }
}

// =============================================================================
// NAVIGATION
// =============================================================================

function nextEducationStep() {
    EducationState.completedSteps.push(EducationState.currentStep);
    
    // Cleanup
    document.querySelectorAll('.education-pulse, .education-glow').forEach(el => {
        el.classList.remove('education-pulse', 'education-glow', 'education-success', 'education-shake');
        el.style.boxShadow = '';
        el.style.transform = '';
    });
    
    // Fade out tooltip
    const tooltip = document.getElementById('educationTooltip');
    tooltip.classList.remove('visible');
    
    // Wait for fade then show next
    setTimeout(() => {
        EducationState.currentStep++;
        showEducationStep(EducationState.currentStep);
    }, 200);
}

function skipStep() {
    nextEducationStep();
}

function restartEducation() {
    EducationState.currentStep = 0;
    EducationState.completedSteps = [];
    
    // Hide completion
    document.getElementById('completionModal').style.display = 'none';
    
    // Reset to library view
    if (typeof switchView === 'function') {
        switchView('default');
    }
    
    startEducation();
}

function closeEducation() {
    if (!confirm('Eğitimi kapatmak istediğinizden emin misiniz?')) {
        return;
    }
    
    EducationState.isActive = false;
    document.getElementById('educationOverlaySystem').style.display = 'none';
    
    // Remove pulse classes
    document.querySelectorAll('.education-pulse').forEach(el => {
        el.classList.remove('education-pulse', 'education-success', 'education-shake');
    });
}

// =============================================================================
// COMPLETION
// =============================================================================

function showCompletion() {
    document.getElementById('educationOverlaySystem').style.display = 'none';
    document.getElementById('completionModal').style.display = 'flex';
    
    // Remove pulse classes and handlers
    document.querySelectorAll('.education-pulse').forEach(el => {
        el.classList.remove('education-pulse');
    });
    
    document.querySelectorAll('[data-education-handler]').forEach(el => {
        delete el.dataset.educationHandler;
    });
}

// =============================================================================
// EVENT LISTENERS
// =============================================================================

function setupEducationListeners() {
    const btnContinue = document.getElementById('btnContinue');
    const btnSkipStep = document.getElementById('btnSkipStep');
    const tooltipClose = document.getElementById('tooltipClose');
    
    if (btnContinue) {
        btnContinue.addEventListener('click', () => {
            const step = EDUCATION_STEPS[EducationState.currentStep];
            if (step.actionType === 'wait' || step.actionType === 'manual_continue') {
                nextEducationStep();
            }
        });
    }
    
    if (btnSkipStep) {
        btnSkipStep.addEventListener('click', skipStep);
    }
    
    if (tooltipClose) {
        tooltipClose.addEventListener('click', closeEducation);
    }
}

// =============================================================================
// WINDOW RESIZE & SCROLL HANDLERS
// =============================================================================

let resizeTimeout = null;

window.addEventListener('resize', () => {
    if (!EducationState.isActive) return;
    
    // Debounce resize
    if (resizeTimeout) {
        clearTimeout(resizeTimeout);
    }
    
    resizeTimeout = setTimeout(() => {
        const step = EDUCATION_STEPS[EducationState.currentStep];
        if (step && step.targetElement) {
            const target = document.querySelector(step.targetElement);
            if (target) {
                createSpotlight(step, target);
                positionSmartTooltip(step, target);
            }
        }
    }, 150);
});

let scrollTimeout = null;

window.addEventListener('scroll', () => {
    if (!EducationState.isActive) return;
    
    if (scrollTimeout) {
        clearTimeout(scrollTimeout);
    }
    
    scrollTimeout = setTimeout(() => {
        const step = EDUCATION_STEPS[EducationState.currentStep];
        if (step && step.targetElement) {
            const target = document.querySelector(step.targetElement);
            if (target) {
                createSpotlight(step, target);
                positionSmartTooltip(step, target);
            }
        }
    }, 100);
}, true); // Use capture to catch all scroll events

// =============================================================================
// AUTO START
// =============================================================================

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => {
            initEducation();
            setupEducationListeners();
        }, 500);
    });
} else {
    setTimeout(() => {
        initEducation();
        setupEducationListeners();
    }, 500);
}
