# 📚 SPL Detection Library - Eğitim Modu

## 🎯 Genel Bakış

Bu, **SPL Detection Library**'nin interaktif eğitim versiyonudur.

**Özellikler:**
- ✅ Ana tool'un tam çalışan kopyası
- ✅ Üzerine entegre interaktif tutorial
- ✅ Blur + spotlight UX
- ✅ Adım adım validation
- ✅ Türkçe eğitim içeriği
- ✅ Gerçek aksiyon gerektirir

## 🚀 Nasıl Çalıştırılır

### Yöntem 1: Direkt Açma
```bash
# education klasöründen
open index.html
```

### Yöntem 2: Web Sunucu
```bash
cd education
python3 -m http.server 8000

# Tarayıcıda
http://localhost:8000
```

## 🎓 Eğitim Akışı

**23 adımlı interaktif tutorial:**

### 📚 Bölüm 1: Temel Kullanım (1-7)
1. Hoş geldiniz
2. Library tanıtımı
3. Rule seçme
4. Detayları görüntüleme
5. SPL query paneli
6. Gerçek zamanlı arama
7. Arama temizleme

### ➕ Bölüm 2: Rule Ekleme (8-14)
8. "Yeni Kural Ekle" butonu
9. Rule adı girme
10. Açıklama yazma
11. Kategori seçme
12. Severity seçme
13. SPL query yazma
14. MITRE ID girme (validation)
15. Kaydetme

### 🗺️ Bölüm 3: Map Views (16-17)
16. Category Map kullanımı
17. Severity Map kullanımı

### ⭐ Bölüm 4: Özellikler (18-19)
18. Yıldızlama (favorites)
19. Starred view

### 🎯 Bölüm 5: MITRE & Analytics (20-21)
20. MITRE Map görünümü
21. Coverage Dashboard

### 🔧 Bölüm 6: Diğer Özellikler (22-23)
22. Verified filter
23. Tema değiştirme

## 💡 Nasıl Çalışır

### Spotlight System
- Ekranın tamamı blur olur
- Sadece hedef element net kalır
- SVG mask ile dinamik spotlight
- Smooth transitions

### Step Validation
- Kullanıcı doğru aksiyonu yapana kadar ilerleme yok
- ✓ Success → Yeşil feedback + next step
- ✗ Error → Kırmızı feedback + shake

### Progress Tracking
- Progress bar (%)
- Adım sayacı (X/23)
- Her adım tamamlandıkça güncellenir

## 🎨 UI/UX

**Renkler:**
- Turuncu border (eğitim modu göstergesi)
- Blur + spotlight
- Soft animasyonlar
- Enterprise tasarım korunur

**Animasyonlar:**
- Pulse: Hedef element pulse efekti
- Shake: Hata durumunda
- Success: Yeşil glow
- Completion: Bounce-in

## 🔧 Özelleştirme

### Yeni Adım Eklemek

`education-engine.js` içinde `EDUCATION_STEPS` dizisine:

```javascript
{
    id: 'my_step',
    title: 'Başlık',
    description: 'Açıklama...',
    targetElement: '#selector',
    actionType: 'click',
    validation: () => {
        // Validation logic
        return true;
    }
}
```

### Action Types

- `manual_continue`: Kullanıcı "Devam Et" butonuna basar
- `wait`: Belirli süre bekle (duration ms)
- `click`: Element'e tıkla
- `input`: Input'a yaz
- `select`: Dropdown seç
- `completion`: Eğitim sonu

## 🎯 Kullanım Senaryoları

### Yeni SOC Analyst Onboarding
1. Eğitim modunu aç
2. Tutorial'ı tamamla (15-20 dk)
3. Ana tool'a geç
4. Confidence ile kullanmaya başla

### Team Training
- Ekip toplantısında
- Büyük ekranda göster
- Özellik tanıtımı

### Self-Learning
- Kendi hızında ilerle
- İstediğin adımı atla
- İstediğin zaman tekrarla

## 🔒 Veri Yönetimi

**Education Mode:**
- ✅ Ana tool'un LocalStorage'ını kullanır
- ✅ Eklediğiniz rule'lar kaydedilir
- ✅ Eğitim bitince ana tool'da da görünür

**Bağımsızlık:**
- Ana proje dosyalarına dokunmaz
- Sadece education/ klasöründe çalışır
- Ana tool etkilenmez

## 📊 Kontroller

**Eğitim Sırasında:**
- ❌ Kapat: Eğitimi kapat (onay ister)
- ⏭️ Bu Adımı Geç: Mevcut adımı atla
- ➡️ Devam Et: Manuel adımlarda

**Eğitim Sonunda:**
- 🏠 Ana Tool'a Geç: ../index.html
- 🔄 Eğitimi Tekrarla: Baştan başla

## 🏅 Tamamlama

Eğitim bitince:
```
🎉 Eğitim Tamamlandı!

Tebrikler! SPL Detection Library'nin
tüm özelliklerini öğrendiniz.

[Ana Tool'a Geç]  [Eğitimi Tekrarla]
```

## 🔍 Sorun Giderme

**Spotlight görünmüyor:**
- Hard refresh (Cmd+Shift+R)
- Browser güncel mi kontrol et

**Adım geçmiyor:**
- Doğru aksiyonu yaptığınızdan emin olun
- Validation feedback'i okuyun
- "Bu Adımı Geç" ile atlayabilirsiniz

**Modal açılmıyor:**
- F12 → Console → Hata kontrol et
- Sayfayı yenileyin

## 🌐 Tarayıcı Desteği

- ✅ Chrome 90+
- ✅ Edge 90+
- ✅ Firefox 88+
- ✅ Safari 14+

Gereksinimler:
- CSS backdrop-filter
- SVG masking
- ES6+ JavaScript

## 📁 Dosya Yapısı

```
/education/
├── index.html          # Ana tool kopyası + education overlay
├── styles.css          # Ana stil + education CSS
├── app.js              # Ana logic
├── education-engine.js # Tutorial engine
└── README.md           # Bu dosya
```

## 🎓 Eğitim Felsefesi

**"Learning by Doing"**
- Sadece okutmaz
- Kullanıcıyı tıklatır
- Yazdırır
- Validate eder
- Doğru yapana kadar ilerletmez

**Interactive > Passive**
- Video tutorial: %10 retention
- Documentation: %20 retention
- Interactive tutorial: %75 retention ✅

## 💼 Enterprise Kullanım

**Onboarding Process:**
1. Yeni analyst'e education/ linkini ver
2. Tutorial'ı tamamlasın
3. Ana tool'a geçsin
4. Productive olsun

**Avantajlar:**
- ⏱️ Zaman tasarrufu (15 dk vs 2 saat training)
- 📈 Daha iyi retention
- 🎯 Standardize onboarding
- 🔄 Tekrarlanabilir

---

**© 2026 SPL Detection Library - Education Module**

**Ana tool'a geçmek için:** `../index.html`
