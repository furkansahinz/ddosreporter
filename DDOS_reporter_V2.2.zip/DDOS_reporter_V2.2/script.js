// DDOS Atak Raporlama Sistemi - JavaScript
// ING Bank SOC Ekip Raporlama Formu

// ==================== ÜLKE LİSTESİ ====================
const countries = [
    'Afganistan', 'Almanya', 'Amerika Birleşik Devletleri', 'Andorra', 'Angola', 'Antigua ve Barbuda',
    'Arjantin', 'Arnavutluk', 'Avustralya', 'Avusturya', 'Azerbaycan', 'Bahamalar', 'Bahreyn',
    'Bangladeş', 'Barbados', 'Belarus', 'Belçika', 'Belize', 'Benin', 'Bhutan', 'Birleşik Arap Emirlikleri',
    'Birleşik Krallık', 'Bolivya', 'Bosna Hersek', 'Botsvana', 'Brezilya', 'Brunei', 'Bulgaristan',
    'Burkina Faso', 'Burundi', 'Cabo Verde', 'Cezayir', 'Cibuti', 'Çad', 'Çek Cumhuriyeti',
    'Çin', 'Danimarka', 'Demokratik Kongo Cumhuriyeti', 'Dominik', 'Dominik Cumhuriyeti',
    'Doğu Timor', 'Ekvador', 'Ekvator Ginesi', 'El Salvador', 'Endonezya', 'Eritre', 'Ermenistan',
    'Estonya', 'Esvati', 'Etiyopya', 'Fas', 'Fiji', 'Filipinler', 'Finlandiya', 'Fransa', 'Gabon',
    'Gambiya', 'Gana', 'Gine', 'Gine-Bissau', 'Grenada', 'Guatemala', 'Guyana', 'Güney Afrika',
    'Güney Kore', 'Güney Sudan', 'Gürcistan', 'Haiti', 'Hindistan', 'Hırvatistan', 'Honduras',
    'Irak', 'İran', 'İrlanda', 'İspanya', 'İsrail', 'İsveç', 'İsviçre', 'İtalya', 'İzlanda',
    'Jamaika', 'Japonya', 'Kamboçya', 'Kamerun', 'Kanada', 'Karadağ', 'Katar', 'Kazakistan',
    'Kenya', 'Kıbrıs', 'Kırgızistan', 'Kiribati', 'Kolombiya', 'Komorlar', 'Kongo', 'Kosta Rika',
    'Küba', 'Kuveyt', 'Laos', 'Lesotho', 'Letonya', 'Liberya', 'Libya', 'Lihtenştayn', 'Litvanya',
    'Lübnan', 'Lüksemburg', 'Macaristan', 'Madagaskar', 'Malavi', 'Maldivler', 'Malezya', 'Mali',
    'Malta', 'Marshall Adaları', 'Mauritius', 'Meksika', 'Mısır', 'Mikronezya', 'Moldova', 'Monako',
    'Mongolia', 'Mozambik', 'Myanmar', 'Namibya', 'Nauru', 'Nepal', 'Nijer', 'Nijerya', 'Nikaragua',
    'Norveç', 'Orta Afrika Cumhuriyeti', 'Özbekistan', 'Pakistan', 'Palau', 'Panama', 'Papua Yeni Gine',
    'Paraguay', 'Peru', 'Polonya', 'Portekiz', 'Romanya', 'Ruanda', 'Rusya', 'Saint Kitts ve Nevis',
    'Saint Lucia', 'Saint Vincent ve Grenadinler', 'Samoa', 'San Marino', 'São Tomé ve Príncipe',
    'Senegal', 'Seyşeller', 'Sierra Leone', 'Singapur', 'Slovakya', 'Slovenya', 'Solomon Adaları',
    'Somali', 'Sri Lanka', 'Sudan', 'Surinam', 'Suriye', 'Suudi Arabistan', 'Şili', 'Tacikistan',
    'Tanzanya', 'Tayland', 'Togo', 'Tonga', 'Trinidad ve Tobago', 'Tunus', 'Türkiye', 'Türkmenistan',
    'Tuvalu', 'Uganda', 'Ukrayna', 'Umman', 'Uruguay', 'Ürdün', 'Vanuatu', 'Vatikan', 'Venezuela',
    'Vietnam', 'Yemen', 'Yeni Zelanda', 'Yeşil Burun Adaları', 'Yunanistan', 'Zambiya', 'Zimbabve'
].sort();

// ==================== SALDIRI SEVİYESİ TABLOSU ====================
const attackLevels = [
    { name: 'Küçük', mbpsMin: 50, mbpsMax: 99, kppsMin: 0, kppsMax: 99999 },
    { name: 'Orta', mbpsMin: 100, mbpsMax: 399, kppsMin: 200000, kppsMax: 499999 },
    { name: 'Orta-Üst', mbpsMin: 400, mbpsMax: 999, kppsMin: 500000, kppsMax: 849999 },
    { name: 'Büyük', mbpsMin: 1000, mbpsMax: 49999, kppsMin: 1000000, kppsMax: 4999999 },
    { name: 'Çok Büyük', mbpsMin: 50000, mbpsMax: Infinity, kppsMin: 10000000, kppsMax: Infinity }
];

// ==================== TARİH/SAAT FORMAT FONKSİYONLARI ====================
// Tarih formatını DD.MM.YYYY'den Date objesine çevirme
function parseTRDate(dateStr) {
    const parts = dateStr.split('.');
    if (parts.length !== 3) return null;
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1; // Month is 0-indexed
    const year = parseInt(parts[2], 10);
    return new Date(year, month, day);
}

// Saat formatını kontrol etme (HH:mm)
function isValidTime(timeStr) {
    const pattern = /^([0-1][0-9]|2[0-3]):([0-5][0-9])$/;
    return pattern.test(timeStr);
}

// Tarih formatını kontrol etme (DD.MM.YYYY)
function isValidDate(dateStr) {
    const pattern = /^(0[1-9]|[12][0-9]|3[01])\.(0[1-9]|1[0-2])\.\d{4}$/;
    return pattern.test(dateStr);
}

// ==================== DOM ELEMENTLERİ ====================
const form = document.getElementById('ddosForm');
const ongoingCheckbox = document.getElementById('ongoing');
const endTimeInput = document.getElementById('endTime');
const noErrorCheckbox = document.getElementById('noError');
const monitoringSection = document.getElementById('monitoringSection');
const addLinkBtn = document.getElementById('addLinkBtn');
const monitoringLinks = document.getElementById('monitoringLinks');
const countrySelect = document.getElementById('countrySelect');
const selectedCountriesDiv = document.getElementById('selectedCountries');
const mbpsInput = document.getElementById('mbps');
const kppsInput = document.getElementById('kpps');
const attackLevelDiv = document.getElementById('attackLevel');
const attackImpactSection = document.getElementById('attackImpactSection');
const summaryTextarea = document.getElementById('summary');
const generateSummaryBtn = document.getElementById('generateSummaryBtn');
const generatePDFBtn = document.getElementById('generatePDFBtn');
const resetBtn = document.getElementById('resetBtn');
const serviceSelect = document.getElementById('serviceSelect');
const selectedServicesDiv = document.getElementById('selectedServices');
const addServiceBtn = document.getElementById('addServiceBtn');
const selectedActionsDiv = document.getElementById('selectedActions');
const addActionBtn = document.getElementById('addActionBtn');
const ipAddressInput = document.getElementById('ipAddressInput');
const addIpBtn = document.getElementById('addIpBtn');
const selectedIpAddressesDiv = document.getElementById('selectedIpAddresses');

// Seçili ülkeler listesi (sıralı)
let selectedCountriesList = [];

// Seçili servisler listesi (sıralı)
let selectedServicesList = [];

// Seçili aksiyonlar listesi
let selectedActionsList = [];

// Seçili saldırı türleri listesi
let selectedAttackTypesList = [];

// Etkilenen IP adresleri listesi
let selectedIpAddressList = [];

// Monitoring linkleri listesi
let monitoringLinksList = [];

// ==================== SAYFA YÜKLENDİĞİNDE ====================
document.addEventListener('DOMContentLoaded', function() {
    initializeCountries();
    setupEventListeners();
    setDefaultDate();
    // Monitoring section başlangıçta görünür
    monitoringSection.style.display = 'block';
});

// Ülke listesini dropdown'a ekle
function initializeCountries() {
    countries.forEach(country => {
        const option = document.createElement('option');
        option.value = country;
        option.textContent = country;
        countrySelect.appendChild(option);
    });
}

// Varsayılan tarihi bugün olarak ayarla
// Varsayılan tarih ve saat ayarla (Türkiye formatı: DD.MM.YYYY ve HH:mm)
function setDefaultDate() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    
    // Tarih: DD.MM.YYYY
    document.getElementById('attackDate').value = `${day}.${month}.${year}`;
    // Başlangıç Saati: HH:mm
    document.getElementById('startTime').value = `${hours}:${minutes}`;
}

// ==================== EVENT LİSTENERS ====================
function setupEventListeners() {
    // Devam Ediyor checkbox
    ongoingCheckbox.addEventListener('change', handleOngoingChange);
    
    // Hata bulunmamaktadır checkbox
    noErrorCheckbox.addEventListener('change', handleNoErrorChange);
    
    // Link ekle butonu
    addLinkBtn.addEventListener('click', addMonitoringLink);
    
    // Ülke seçimi
    countrySelect.addEventListener('change', handleCountrySelection);
    
    // Servis seçimi
    serviceSelect.addEventListener('change', handleServiceSelection);
    
    // Manuel servis ekle
    addServiceBtn.addEventListener('click', addManualService);
    
    // Aksiyon checkbox'ları
    document.querySelectorAll('input[name="actions"]').forEach(checkbox => {
        checkbox.addEventListener('change', handleActionChange);
    });
    
    // Saldırı türü checkbox'ları
    document.querySelectorAll('input[name="attackTypes"]').forEach(checkbox => {
        checkbox.addEventListener('change', handleAttackTypeChange);
    });
    
    // Manuel aksiyon ekle
    addActionBtn.addEventListener('click', addManualAction);
    
    // IP adresi ekle
    addIpBtn.addEventListener('click', addIpAddress);
    ipAddressInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            addIpAddress();
        }
    });
    
    // Saldırı etkisi değişiklikleri
    mbpsInput.addEventListener('input', calculateAttackLevel);
    kppsInput.addEventListener('input', calculateAttackLevel);
    
    // Form değişikliklerinde özeti güncelle
    form.addEventListener('input', debounce(updateSummary, 500));
    
    // Özet güncelle butonu
    generateSummaryBtn.addEventListener('click', updateSummary);
    
    // PDF oluştur
    generatePDFBtn.addEventListener('click', handlePDFGeneration);
    
    // Form submit'i engelle
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        handlePDFGeneration(e);
    });
    
    // Form reset
    resetBtn.addEventListener('click', resetForm);
}

// ==================== DEVAM EDİYOR CHECKBOX ====================
function handleOngoingChange() {
    if (ongoingCheckbox.checked) {
        endTimeInput.disabled = true;
        endTimeInput.value = '';
        endTimeInput.removeAttribute('required');
    } else {
        endTimeInput.disabled = false;
        endTimeInput.setAttribute('required', 'required');
    }
    updateSummary();
}

// ==================== HATA BULUNMAMAKTADIR CHECKBOX ====================
function handleNoErrorChange() {
    if (noErrorCheckbox.checked) {
        monitoringSection.style.display = 'none';
        monitoringLinksList = [];
        monitoringLinks.innerHTML = '';
    } else {
        monitoringSection.style.display = 'block';
    }
    updateSummary();
}

// ==================== MONİTORİNG LİNK EKLEME ====================
function addMonitoringLink() {
    const linkId = 'link_' + Date.now();
    const linkItem = document.createElement('div');
    linkItem.className = 'monitoring-link-item';
    linkItem.id = linkId;
    
    linkItem.innerHTML = `
        <input type="url" class="link-url" placeholder="https://example.com" required>
        <select class="link-duration" required>
            <option value="">Seçiniz</option>
            <option value="30 sn">30 sn</option>
            <option value="1 dk">1 dk</option>
            <option value="2 dk">2 dk</option>
            <option value="5 dk">5 dk</option>
        </select>
        <button type="button" class="remove-link-btn" onclick="removeMonitoringLink('${linkId}')">Kaldır</button>
    `;
    
    monitoringLinks.appendChild(linkItem);
    monitoringLinksList.push({ id: linkId, url: '', duration: '' });
    
    // URL değişikliklerini dinle
    const urlInput = linkItem.querySelector('.link-url');
    const durationSelect = linkItem.querySelector('.link-duration');
    
    urlInput.addEventListener('input', function() {
        const link = monitoringLinksList.find(l => l.id === linkId);
        if (link) link.url = this.value;
        updateSummary();
    });
    
    durationSelect.addEventListener('change', function() {
        const link = monitoringLinksList.find(l => l.id === linkId);
        if (link) link.duration = this.value;
        updateSummary();
    });
}

function removeMonitoringLink(linkId) {
    const linkItem = document.getElementById(linkId);
    if (linkItem) {
        linkItem.remove();
        monitoringLinksList = monitoringLinksList.filter(l => l.id !== linkId);
        updateSummary();
    }
}

// ==================== SERVİS YÖNETİMİ ====================
function handleServiceSelection() {
    const selectedValue = serviceSelect.value;
    if (selectedValue && !selectedServicesList.includes(selectedValue)) {
        selectedServicesList.push(selectedValue);
        updateServiceTags();
        serviceSelect.value = '';
        updateSummary();
    }
}

function addManualService() {
    const serviceName = prompt('Servis adını girin:');
    if (serviceName && serviceName.trim()) {
        const trimmedName = serviceName.trim();
        if (!selectedServicesList.includes(trimmedName)) {
            selectedServicesList.push(trimmedName);
            updateServiceTags();
            updateSummary();
        } else {
            alert('Bu servis zaten eklenmiş!');
        }
    }
}

function updateServiceTags() {
    selectedServicesDiv.innerHTML = '';
    selectedServicesList.forEach(service => {
        const tag = document.createElement('span');
        tag.className = 'service-tag';
        tag.innerHTML = `
            ${service}
            <span class="remove-service" onclick="removeService('${service.replace(/'/g, "\\'")}')">×</span>
        `;
        selectedServicesDiv.appendChild(tag);
    });
}

function removeService(service) {
    selectedServicesList = selectedServicesList.filter(s => s !== service);
    updateServiceTags();
    updateSummary();
}

// ==================== AKSİYON YÖNETİMİ ====================
function handleActionChange(e) {
    const actionValue = e.target.value;
    if (e.target.checked) {
        if (!selectedActionsList.includes(actionValue)) {
            selectedActionsList.push(actionValue);
        }
    } else {
        selectedActionsList = selectedActionsList.filter(a => a !== actionValue);
    }
    updateActionTags();
    updateSummary();
}

function addManualAction() {
    const actionName = prompt('Aksiyon adını girin:');
    if (actionName && actionName.trim()) {
        const trimmedName = actionName.trim();
        if (!selectedActionsList.includes(trimmedName)) {
            selectedActionsList.push(trimmedName);
            updateActionTags();
            updateSummary();
        } else {
            alert('Bu aksiyon zaten eklenmiş!');
        }
    }
}

function updateActionTags() {
    selectedActionsDiv.innerHTML = '';
    selectedActionsList.forEach(action => {
        const tag = document.createElement('span');
        tag.className = 'action-tag';
        tag.innerHTML = `
            ${action}
            <span class="remove-action" onclick="removeAction('${action.replace(/'/g, "\\'")}')">×</span>
        `;
        selectedActionsDiv.appendChild(tag);
    });
}

function removeAction(action) {
    selectedActionsList = selectedActionsList.filter(a => a !== action);
    // Checkbox'ı da kaldır
    const checkbox = Array.from(document.querySelectorAll('input[name="actions"]')).find(cb => cb.value === action);
    if (checkbox) {
        checkbox.checked = false;
    }
    updateActionTags();
    updateSummary();
}

// ==================== SALDIRI TÜRÜ YÖNETİMİ ====================
function handleAttackTypeChange() {
    selectedAttackTypesList = Array.from(document.querySelectorAll('input[name="attackTypes"]:checked')).map(cb => cb.value);
    updateSummary();
}

// ==================== IP ADRESİ YÖNETİMİ ====================
function addIpAddress() {
    const ipValue = ipAddressInput.value.trim();
    
    if (!ipValue) {
        return;
    }
    
    // IPv4 format validasyonu
    const ipv4Regex = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    
    if (!ipv4Regex.test(ipValue)) {
        alert('Geçersiz IP adresi formatı! Lütfen geçerli bir IPv4 adresi giriniz (örn: 192.168.1.1)');
        return;
    }
    
    // Duplicate kontrol
    if (selectedIpAddressList.includes(ipValue)) {
        alert('Bu IP adresi zaten eklenmiş!');
        return;
    }
    
    // IP'yi listeye ekle
    selectedIpAddressList.push(ipValue);
    updateIpTags();
    ipAddressInput.value = '';
    updateSummary();
}

function updateIpTags() {
    selectedIpAddressesDiv.innerHTML = '';
    selectedIpAddressList.forEach(ip => {
        const tag = document.createElement('span');
        tag.className = 'ip-tag';
        tag.innerHTML = `
            ${ip}
            <span class="remove-ip" onclick="removeIpAddress('${ip}')">×</span>
        `;
        selectedIpAddressesDiv.appendChild(tag);
    });
}

function removeIpAddress(ip) {
    selectedIpAddressList = selectedIpAddressList.filter(i => i !== ip);
    updateIpTags();
    updateSummary();
}

// ==================== ÜLKE YÖNETİMİ ====================
function handleCountrySelection() {
    const selectedValue = countrySelect.value;
    
    // Boş seçim veya zaten eklenmiş ülke kontrolü
    if (!selectedValue || selectedValue === '') {
        return;
    }
    
    // Ülke zaten listede varsa ekleme
    if (selectedCountriesList.includes(selectedValue)) {
        // Select'i sıfırla
        countrySelect.value = '';
        return;
    }
    
    // Yeni ülkeyi ekle
    selectedCountriesList.push(selectedValue);
    updateCountryTags();
    
    // Select'i sıfırla (bir sonraki seçim için hazır)
    countrySelect.value = '';
    
    updateSummary();
}

function updateCountryTags() {
    selectedCountriesDiv.innerHTML = '';
    selectedCountriesList.forEach(country => {
        const tag = document.createElement('span');
        tag.className = 'country-tag';
        tag.innerHTML = `
            ${country}
            <span class="remove-country" onclick="removeCountry('${country.replace(/'/g, "\\'")}')">×</span>
        `;
        selectedCountriesDiv.appendChild(tag);
    });
    
    // Seçili ülkeleri select'te gizle/göster
    if (countrySelect) {
        const options = countrySelect.options;
        for (let i = 0; i < options.length; i++) {
            const option = options[i];
            if (option.value && option.value !== '') {
                // Seçili listede varsa gizle, yoksa göster
                option.style.display = selectedCountriesList.includes(option.value) ? 'none' : '';
            }
        }
    }
}

function removeCountry(country) {
    selectedCountriesList = selectedCountriesList.filter(c => c !== country);
    updateCountryTags();
    updateSummary();
    
    // Select'teki ilgili option'ı tekrar göster
    if (countrySelect) {
        const options = countrySelect.options;
        for (let i = 0; i < options.length; i++) {
            if (options[i].value === country) {
                options[i].style.display = '';
                break;
            }
        }
    }
}

// ==================== SALDIRI SEVİYESİ HESAPLAMA ====================
function calculateAttackLevel() {
    const mbps = parseFloat(mbpsInput.value) || 0;
    const kpps = parseFloat(kppsInput.value) || 0;
    
    // Tüm seviye sınıflarını kaldır
    if (attackImpactSection) {
        attackImpactSection.classList.remove('level-small', 'level-medium', 'level-medium-high', 'level-large', 'level-very-large');
    }
    
    if (mbps === 0 && kpps === 0) {
        attackLevelDiv.textContent = '';
        attackLevelDiv.style.display = 'none';
        updateSummary();
        return;
    }
    
    // Her iki değer için seviye bul
    let mbpsLevel = null;
    let kppsLevel = null;
    
    // Mbps seviyesi
    for (const level of attackLevels) {
        if (mbps >= level.mbpsMin && mbps <= level.mbpsMax) {
            mbpsLevel = level;
            break;
        }
    }
    
    // Kpps seviyesi
    for (const level of attackLevels) {
        if (kpps >= level.kppsMin && kpps <= level.kppsMax) {
            kppsLevel = level;
            break;
        }
    }
    
    // Hangisi daha yüksek seviyeye denk geliyorsa onu seç
    let finalLevel = null;
    
    if (mbpsLevel && kppsLevel) {
        // Her ikisi de seviye bulduysa, daha yüksek olanı seç
        const mbpsIndex = attackLevels.findIndex(l => l.name === mbpsLevel.name);
        const kppsIndex = attackLevels.findIndex(l => l.name === kppsLevel.name);
        finalLevel = mbpsIndex > kppsIndex ? mbpsLevel : kppsLevel;
    } else if (mbpsLevel) {
        finalLevel = mbpsLevel;
    } else if (kppsLevel) {
        finalLevel = kppsLevel;
    }
    
    // Eğer hiçbir seviyeye uymuyorsa, en düşük seviyeyi göster
    if (!finalLevel) {
        finalLevel = attackLevels[0];
    }
    
    // Seviyeye göre CSS sınıfı ekle
    const levelClassMap = {
        'Küçük': 'level-small',
        'Orta': 'level-medium',
        'Orta-Üst': 'level-medium-high',
        'Büyük': 'level-large',
        'Çok Büyük': 'level-very-large'
    };
    
    const levelClass = levelClassMap[finalLevel.name];
    if (levelClass && attackImpactSection) {
        attackImpactSection.classList.add(levelClass);
    }
    
    // Görüntüle
    if (finalLevel) {
        attackLevelDiv.textContent = `${mbps} Mbps / ${kpps} Kpps (${finalLevel.name})`;
        attackLevelDiv.style.display = 'block';
    }
    
    updateSummary();
}

// ==================== OTOMATİK ÖZET ÜRETİMİ ====================
function updateSummary() {
    const date = document.getElementById('attackDate').value;
    const startTime = document.getElementById('startTime').value;
    const endTime = ongoingCheckbox.checked ? 'Devam Ediyor' : document.getElementById('endTime').value;
    const services = selectedServicesList.length > 0 ? selectedServicesList.join(', ') : '';
    const mbps = document.getElementById('mbps').value || '0';
    const kpps = document.getElementById('kpps').value || '0';
    const duration = document.getElementById('attackDuration').value;
    
    // Saldırı seviyesini hesapla
    const mbpsNum = parseFloat(mbps) || 0;
    const kppsNum = parseFloat(kpps) || 0;
    let level = '';
    
    if (mbpsNum > 0 || kppsNum > 0) {
        let mbpsLevel = null;
        let kppsLevel = null;
        
        for (const lvl of attackLevels) {
            if (mbpsNum >= lvl.mbpsMin && mbpsNum <= lvl.mbpsMax) {
                mbpsLevel = lvl;
                break;
            }
        }
        
        for (const lvl of attackLevels) {
            if (kppsNum >= lvl.kppsMin && kppsNum <= lvl.kppsMax) {
                kppsLevel = lvl;
                break;
            }
        }
        
        if (mbpsLevel && kppsLevel) {
            const mbpsIndex = attackLevels.findIndex(l => l.name === mbpsLevel.name);
            const kppsIndex = attackLevels.findIndex(l => l.name === kppsLevel.name);
            level = mbpsIndex > kppsIndex ? mbpsLevel.name : kppsLevel.name;
        } else if (mbpsLevel) {
            level = mbpsLevel.name;
        } else if (kppsLevel) {
            level = kppsLevel.name;
        } else {
            level = attackLevels[0].name;
        }
    }
    
    // Tarih formatını düzenle (zaten DD.MM.YYYY formatında)
    let formattedDate = date;
    
    // Özet metni oluştur (sadece zorunlu alanlar doluysa)
    if (date && startTime && services && duration) {
        const durationFormatted = duration ? `${duration} DK` : '';
        const summaryText = `${formattedDate} tarihinde, ${startTime} – ${endTime} saatleri arasında ${services} servisine yönelik DDOS saldırısı tespit edilmiştir. Saldırı sırasında trafik seviyesi ${mbps} Mbps / ${kpps} Kpps (${level}) olarak ölçülmüştür. Saldırı süresi yaklaşık ${durationFormatted} olarak değerlendirilmiştir. İlgili aksiyonlar alınmış olup, izleme servislerinde kısmi erişim sorunları gözlemlenmiştir.`;
        // Kullanıcı manuel düzenleme yapmadıysa otomatik güncelle
        if (!summaryTextarea.dataset.manualEdit) {
            summaryTextarea.value = summaryText;
        }
    }
}

// Özet textarea'ya manuel düzenleme flag'i ekle
summaryTextarea.addEventListener('input', function() {
    this.dataset.manualEdit = 'true';
});

// ==================== PDF OLUŞTURMA (YENİDEN YAZILDI) ====================
async function handlePDFGeneration(e) {
    e.preventDefault();
    
    try {
        // Form validasyonu
        if (!validateForm()) {
            return;
        }
        
        // Özeti güncelle (PDF'den önce)
        updateSummary();
        
        // PDF içeriğini oluştur ve render et
        const pdfContent = document.getElementById('pdfContent');
        pdfContent.innerHTML = generatePDFContent();
        
        // DOM'un render edilmesini bekle
        await new Promise(resolve => setTimeout(resolve, 100));
        
        // PDF oluştur
        await createPDF();
        
    } catch (error) {
        alert('PDF oluşturulurken bir hata oluştu: ' + error.message);
    }
}

function validateForm() {
    // Zorunlu alanları kontrol et
    const date = document.getElementById('attackDate').value;
    const startTime = document.getElementById('startTime').value;
    const endTime = ongoingCheckbox.checked ? 'Devam Ediyor' : document.getElementById('endTime').value;
    const services = selectedServicesList.length;
    const mbps = document.getElementById('mbps').value;
    const kpps = document.getElementById('kpps').value;
    const duration = document.getElementById('attackDuration').value;
    
    // Tarih formatı kontrolü
    if (!date) {
        alert('Lütfen tarih giriniz.');
        return false;
    }
    
    if (!isValidDate(date)) {
        alert('Lütfen geçerli bir tarih giriniz (DD.MM.YYYY formatında, örn: 12.02.2026).');
        return false;
    }
    
    // Başlangıç saati formatı kontrolü
    if (!startTime) {
        alert('Lütfen başlangıç saati giriniz.');
        return false;
    }
    
    if (!isValidTime(startTime)) {
        alert('Lütfen geçerli bir başlangıç saati giriniz (HH:mm formatında 24 saatlik, örn: 14:35).');
        return false;
    }
    
    // Bitiş saati formatı kontrolü
    if (!ongoingCheckbox.checked && !endTime) {
        alert('Lütfen bitiş saati giriniz veya "Devam Ediyor" seçeneğini işaretleyiniz.');
        return false;
    }
    
    if (!ongoingCheckbox.checked && endTime && !isValidTime(endTime)) {
        alert('Lütfen geçerli bir bitiş saati giriniz (HH:mm formatında 24 saatlik, örn: 14:35).');
        return false;
    }
    
    if (services === 0) {
        alert('Lütfen en az bir servis seçiniz.');
        return false;
    }
    
    if (!mbps || !kpps) {
        alert('Lütfen Mbps ve Kpps değerlerini giriniz.');
        return false;
    }
    
    if (!duration) {
        alert('Lütfen saldırı süresini seçiniz.');
        return false;
    }
    
    // Monitoring linkleri kontrolü
    if (!noErrorCheckbox.checked) {
        const linkItems = document.querySelectorAll('.monitoring-link-item');
        for (const item of linkItems) {
            const urlInput = item.querySelector('.link-url');
            const durationSelect = item.querySelector('.link-duration');
            if (urlInput && urlInput.value && (!durationSelect || !durationSelect.value)) {
                alert('Lütfen tüm monitoring linkleri için hata süresini seçiniz.');
                return false;
            }
        }
    }
    
    return true;
}

// --- PDF Header/Footer sabitleri (content flow'dan bağımsız, tüm sayfalarda aynı) ---
var PDF_HEADER_H_MM = 18;
var PDF_FOOTER_H_MM = 10;
var PDF_ING_ORANGE = { r: 255, g: 98, b: 0 }; // ING Bank kurumsal turuncu
var PDF_MARGIN_X_MM = 14;

/** Her sayfada sabit header: sol ING BANK, sağ DDOS Atak Raporu, altında kalın turuncu çizgi. */
function drawPdfPageHeader(pdf) {
    var w = pdf.internal.pageSize.getWidth();
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(16);
    pdf.setTextColor(PDF_ING_ORANGE.r, PDF_ING_ORANGE.g, PDF_ING_ORANGE.b);
    pdf.text('ING BANK', PDF_MARGIN_X_MM, 10);
    pdf.setTextColor(0, 0, 0);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(18);
    pdf.text('DDOS Atak Raporu', w - PDF_MARGIN_X_MM, 10, { align: 'right' });
    pdf.setDrawColor(PDF_ING_ORANGE.r, PDF_ING_ORANGE.g, PDF_ING_ORANGE.b);
    pdf.setLineWidth(0.5);
    pdf.line(PDF_MARGIN_X_MM, 14.5, w - PDF_MARGIN_X_MM, 14.5);
}

/** Her sayfada sabit footer: header ile aynı boyutta gri çizgi, altında ortada "Siber Güvenlik Savunma Merkezi". */
function drawPdfPageFooter(pdf) {
    var w = pdf.internal.pageSize.getWidth();
    var h = pdf.internal.pageSize.getHeight();
    pdf.setDrawColor(160, 160, 160);
    pdf.setLineWidth(0.5);
    pdf.line(PDF_MARGIN_X_MM, h - 8, w - PDF_MARGIN_X_MM, h - 8);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(9);
    pdf.setTextColor(90, 90, 90);
    pdf.text('Siber Güvenlik Savunma Merkezi', w / 2, h - 5, { align: 'center' });
}

/**
 * PDF oluşturma: A4 YATAY (Landscape), TEK SAYFA garantili.
 * İçerik ne kadar uzun olursa olsun tek sayfaya sığdırılır (scaling ile).
 * Manuel addPage yasak, page-break yok, overflow yok.
 */
async function createPDF() {
    var pdfContent = document.getElementById('pdfContent');
    var headerEl = pdfContent.querySelector('.pdf-header');
    var footerEl = pdfContent.querySelector('.pdf-footer');

    // Header/footer canvas'a dahil edilmez; jsPDF ile sayfada ayrı çizilir.
    if (headerEl) headerEl.remove();
    if (footerEl) footerEl.remove();
    
    pdfContent.style.visibility = 'visible';
    pdfContent.style.position = 'fixed';
    pdfContent.style.left = '0';
    pdfContent.style.top = '0';
    pdfContent.style.zIndex = '9999';
    
    // İçeriği landscape için optimize render (kalite vs boyut dengesi)
    var contentH = Math.max(pdfContent.scrollHeight, 600);
    var canvas = await html2canvas(pdfContent, {
        scale: 1.8, // Daha iyi kalite için artırıldı (1.5 → 1.8)
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        windowWidth: 1200,
        windowHeight: contentH,
        removeContainer: false,
        imageTimeout: 0,
        allowTaint: false
    });

    if (headerEl) pdfContent.insertBefore(headerEl, pdfContent.firstChild);
    if (footerEl) pdfContent.appendChild(footerEl);
    
    pdfContent.style.visibility = 'hidden';
    pdfContent.style.position = 'fixed';
    pdfContent.style.left = '-9999px';
    
    // A4 LANDSCAPE PDF oluştur (compress: true ile metadata temizliği)
    var pdf = new window.jspdf.jsPDF({ 
        orientation: 'landscape', 
        unit: 'mm', 
        format: 'a4', 
        compress: true,
        putOnlyUsedFonts: true,
        floatPrecision: 16
    });
    
    var pdfW = pdf.internal.pageSize.getWidth(); // ~297mm
    var pdfH = pdf.internal.pageSize.getHeight(); // ~210mm
    var contentAreaH = pdfH - PDF_HEADER_H_MM - PDF_FOOTER_H_MM;
    var contentAreaW = pdfW - (PDF_MARGIN_X_MM * 2);
    
    // JPEG quality: 0.80 (dosya boyutu optimizasyonu, gözle fark edilmez)
    var imgData = canvas.toDataURL('image/jpeg', 0.80);
    var imgW = canvas.width;
    var imgH = canvas.height;
    
    // TEK SAYFA garantisi için scaling: içeriği content area'ya sığdır
    var scaleW = contentAreaW / (imgW * 0.264583); // px to mm
    var scaleH = contentAreaH / (imgH * 0.264583);
    var scale = Math.min(scaleW, scaleH); // En küçük oran (her iki eksende sığar)
    
    var finalW = (imgW * 0.264583) * scale;
    var finalH = (imgH * 0.264583) * scale;
    
    // İçeriği ortala
    var xOffset = PDF_MARGIN_X_MM + (contentAreaW - finalW) / 2;
    var yOffset = PDF_HEADER_H_MM;
    
    // İçerik çiz
    pdf.addImage(imgData, 'JPEG', xOffset, yOffset, finalW, finalH, undefined, 'FAST');
    
    // Header ve footer çiz (üstte)
    function fillHeaderFooterGap() {
        pdf.setFillColor(255, 255, 255);
        pdf.rect(0, 0, pdfW, PDF_HEADER_H_MM, 'F');
        pdf.rect(0, pdfH - PDF_FOOTER_H_MM, pdfW, PDF_FOOTER_H_MM, 'F');
    }
    
    fillHeaderFooterGap();
    drawPdfPageHeader(pdf);
    drawPdfPageFooter(pdf);
    
    // Minimal metadata (dosya boyutu optimizasyonu)
    pdf.setProperties({
        title: 'DDOS Atak Raporu',
        author: 'ING Bank',
        creator: 'DDOS Reporter'
    });
    
    // Dosya boyutu kontrolü ve 5 MB limiti
    var blob = pdf.output('blob');
    var mb = blob.size / (1024 * 1024);
    
    if (mb > 5) {
        console.warn('UYARI: PDF boyutu 5 MB sınırını aştı: ' + mb.toFixed(2) + ' MB');
        alert('UYARI: PDF dosyası ' + mb.toFixed(2) + ' MB oldu. Bazı içerikleri kısaltmayı düşünün.');
    } else {
        console.log('✓ PDF boyutu: ' + mb.toFixed(2) + ' MB (A4 Landscape, Tek Sayfa, Max: 5 MB)');
    }
    
    // Dosya adı için tarih formatı (DD.MM.YYYY)
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const dateStr = day + '.' + month + '.' + year;
    
    pdf.save('DDOS_Atak_Raporu_' + dateStr + '.pdf');
}

function generatePDFContent() {
    const date = document.getElementById('attackDate').value;
    const startTime = document.getElementById('startTime').value;
    const endTime = ongoingCheckbox.checked ? 'Devam Ediyor' : document.getElementById('endTime').value;
    const services = selectedServicesList.length > 0 ? selectedServicesList.join(', ') : 'Belirtilmemiş';
    const mbps = document.getElementById('mbps').value || '0';
    const kpps = document.getElementById('kpps').value || '0';
    const duration = document.getElementById('attackDuration').value;
    
    // Saldırı seviyesi
    const mbpsNum = parseFloat(mbps) || 0;
    const kppsNum = parseFloat(kpps) || 0;
    let level = '';
    
    if (mbpsNum > 0 || kppsNum > 0) {
        let mbpsLevel = null;
        let kppsLevel = null;
        
        for (const lvl of attackLevels) {
            if (mbpsNum >= lvl.mbpsMin && mbpsNum <= lvl.mbpsMax) {
                mbpsLevel = lvl;
                break;
            }
        }
        
        for (const lvl of attackLevels) {
            if (kppsNum >= lvl.kppsMin && kppsNum <= lvl.kppsMax) {
                kppsLevel = lvl;
                break;
            }
        }
        
        if (mbpsLevel && kppsLevel) {
            const mbpsIndex = attackLevels.findIndex(l => l.name === mbpsLevel.name);
            const kppsIndex = attackLevels.findIndex(l => l.name === kppsLevel.name);
            level = mbpsIndex > kppsIndex ? mbpsLevel.name : kppsLevel.name;
        } else if (mbpsLevel) {
            level = mbpsLevel.name;
        } else if (kppsLevel) {
            level = kppsLevel.name;
        } else {
            level = attackLevels[0].name;
        }
    }
    
    // Tarih formatı (zaten DD.MM.YYYY formatında)
    let formattedDate = date;
    
    // Seçili aksiyonlar
    const actions = [...selectedActionsList];
    
    // Monitoring linkleri - kart tabanlı kurumsal görünüm
    let monitoringContent = '';
    if (noErrorCheckbox.checked) {
        monitoringContent = `
            <div class="pdf-monitoring-wrap">
                <div class="pdf-monitoring-card pdf-monitoring-card--single">
                    <span class="pdf-monitoring-badge pdf-monitoring-badge--ok">Hata bulunmamaktadır</span>
                    <p class="pdf-monitoring-desc">Uptrends monitoring tarafında hata tespit edilmemiştir.</p>
                </div>
            </div>`;
    } else {
        const linkItems = document.querySelectorAll('.monitoring-link-item');
        const validLinks = [];
        linkItems.forEach(item => {
            const urlInput = item.querySelector('.link-url');
            const durationSelect = item.querySelector('.link-duration');
            if (urlInput && urlInput.value && durationSelect && durationSelect.value) {
                validLinks.push({ url: urlInput.value, duration: durationSelect.value });
            }
        });
        
        if (validLinks.length > 0) {
            monitoringContent = '<div class="pdf-monitoring-wrap">';
            validLinks.forEach(link => {
                monitoringContent += `
                    <div class="pdf-monitoring-card">
                        <div class="pdf-monitoring-card-row">
                            <span class="pdf-monitoring-label">URL</span>
                            <span class="pdf-monitoring-value">${link.url}</span>
                        </div>
                        <div class="pdf-monitoring-card-row">
                            <span class="pdf-monitoring-label">Hata süresi</span>
                            <span class="pdf-monitoring-value">${link.duration}</span>
                        </div>
                        <span class="pdf-monitoring-badge pdf-monitoring-badge--warn">Kısa süreli erişim problemi</span>
                    </div>`;
            });
            monitoringContent += '</div>';
        } else {
            monitoringContent = '<div class="pdf-monitoring-wrap"><div class="pdf-monitoring-card pdf-monitoring-card--single"><p class="pdf-monitoring-desc">Bilgi girilmemiş</p></div></div>';
        }
    }
    
    // Ülkeler
    const countriesText = selectedCountriesList.length > 0 
        ? selectedCountriesList.join(', ') 
        : 'Belirtilmemiş';
    
    // Özet metni (kullanıcı düzenlediyse o, yoksa otomatik)
    const summaryText = summaryTextarea.value || 'Özet oluşturulmamış';
    
    // Seviyeye göre PDF renk stilleri
    const levelColorMap = {
        'Küçük': {
            borderColor: '#28A745',
            bgColor: 'rgba(40, 167, 69, 0.05)',
            textColor: '#155724',
            accentColor: '#28A745'
        },
        'Orta': {
            borderColor: '#FFC107',
            bgColor: 'rgba(255, 193, 7, 0.05)',
            textColor: '#856404',
            accentColor: '#FFC107'
        },
        'Orta-Üst': {
            borderColor: '#FF6200',
            bgColor: 'rgba(255, 98, 0, 0.08)',
            textColor: '#CC4E00',
            accentColor: '#FF6200'
        },
        'Büyük': {
            borderColor: '#DC3545',
            bgColor: 'rgba(220, 53, 69, 0.08)',
            textColor: '#721C24',
            accentColor: '#DC3545'
        },
        'Çok Büyük': {
            borderColor: '#721C24',
            bgColor: 'rgba(114, 28, 36, 0.1)',
            textColor: '#721C24',
            accentColor: '#721C24'
        }
    };
    
    const levelColors = levelColorMap[level] || {
        borderColor: '#DEE2E6',
        bgColor: '#FFFFFF',
        textColor: '#1A1A1A',
        accentColor: '#FF6200'
    };
    
    return `
        <div class="pdf-header">
            <div class="pdf-logo">ING BANK</div>
            <div class="pdf-title">DDOS Atak Raporu</div>
        </div>
        
        <div class="pdf-section">
            <div class="pdf-section-title">Zaman Bilgisi</div>
            <div class="pdf-field">
                <span class="pdf-field-label">Tarih:</span>
                <span class="pdf-field-value">${formattedDate}</span>
            </div>
            <div class="pdf-field">
                <span class="pdf-field-label">Başlangıç Saati:</span>
                <span class="pdf-field-value">${startTime}</span>
            </div>
            <div class="pdf-field">
                <span class="pdf-field-label">Bitiş Saati:</span>
                <span class="pdf-field-value">${endTime}</span>
            </div>
        </div>
        
        <div class="pdf-section">
            <div class="pdf-section-title">Servis Bilgisi</div>
            <div class="pdf-field">
                <span class="pdf-field-label">Servis Adı:</span>
                <span class="pdf-field-value">${services}</span>
            </div>
        </div>
        
        <div class="pdf-section" style="border: 2px solid ${levelColors.borderColor}; background-color: ${levelColors.bgColor}; border-radius: 8px; padding: 20px;">
            <div class="pdf-section-title" style="color: ${levelColors.accentColor}; border-bottom-color: ${levelColors.borderColor};">Saldırı Etkisi</div>
            <div class="pdf-field">
                <span class="pdf-field-label">Trafik Seviyesi:</span>
                <span class="pdf-field-value" style="color: ${levelColors.textColor}; font-weight: 600;">${mbps} Mbps / ${kpps} Kpps (${level})</span>
            </div>
        </div>
        
        <div class="pdf-section">
            <div class="pdf-section-title">Saldırı Türü</div>
            <div class="pdf-field-value pdf-attack-types">${selectedAttackTypesList.length > 0 ? '<ul style="list-style-type: disc; padding-left: 18px; margin: 0; font-size: 13px; line-height: 1.35;">' + selectedAttackTypesList.map(t => `<li style="margin-bottom: 2px;">${t}</li>`).join('') + '</ul>' : 'Belirlenemedi'}</div>
        </div>
        
        ${selectedIpAddressList.length > 0 ? `
        <div class="pdf-section">
            <div class="pdf-section-title">Etkilenen IP Adresleri</div>
            <div class="pdf-field-value" style="font-size: ${selectedIpAddressList.length > 30 ? '9px' : selectedIpAddressList.length > 15 ? '10px' : '10px'}; line-height: 1.3; word-wrap: break-word; ${selectedIpAddressList.length > 40 ? 'column-count: 2; column-gap: 15px;' : ''}">${selectedIpAddressList.join(', ')}</div>
        </div>
        ` : ''}
        
        <div class="pdf-section">
            <div class="pdf-section-title">Uptrends Monitoring</div>
            ${monitoringContent}
        </div>
        
        <div class="pdf-section">
            <div class="pdf-section-title">Saldırı Süresi</div>
            <div class="pdf-field">
                <span class="pdf-field-label">Süre:</span>
                <span class="pdf-field-value">${duration ? duration + ' DK' : 'Belirtilmemiş'}</span>
            </div>
        </div>
        
        <div class="pdf-section">
            <div class="pdf-section-title">Saldırı Yapan Ülkeler</div>
            <div class="pdf-field-value" style="font-size: ${selectedCountriesList.length > 20 ? '9px' : '10px'}; ${selectedCountriesList.length > 30 ? 'column-count: 2; column-gap: 15px;' : ''}">${countriesText}</div>
        </div>
        
        <div class="pdf-section">
            <div class="pdf-section-title">Alınan Aksiyonlar</div>
            ${actions.length > 0 
                ? '<ul style="list-style-type: disc; padding-left: 20px;">' + actions.map(a => `<li style="margin-bottom: 5px;">${a}</li>`).join('') + '</ul>' 
                : '<div class="pdf-field-value">Aksiyon belirtilmemiş</div>'}
        </div>
        
        <div class="pdf-section">
            <div class="pdf-section-title">Özet</div>
            <div class="pdf-field-value" style="white-space: pre-wrap;">${summaryText}</div>
        </div>
        
        <div class="pdf-footer">
            Siber Güvenlik Savunma Merkezi  
        </div>
    `;
}

// ==================== FORM RESET ====================
function resetForm() {
    selectedCountriesList = [];
    selectedServicesList = [];
    selectedActionsList = [];
    selectedAttackTypesList = [];
    selectedIpAddressList = [];
    monitoringLinksList = [];
    monitoringLinks.innerHTML = '';
    selectedCountriesDiv.innerHTML = '';
    selectedServicesDiv.innerHTML = '';
    selectedActionsDiv.innerHTML = '';
    selectedIpAddressesDiv.innerHTML = '';
    ipAddressInput.value = '';
    // Ülke seçimini temizle
    if (countrySelect) {
        countrySelect.value = '';
    }
    attackLevelDiv.textContent = '';
    attackLevelDiv.style.display = 'none';
    // Renk sınıflarını kaldır
    if (attackImpactSection) {
        attackImpactSection.classList.remove('level-small', 'level-medium', 'level-medium-high', 'level-large', 'level-very-large');
    }
    // Saldırı türü checkbox'larını temizle
    document.querySelectorAll('input[name="attackTypes"]').forEach(cb => { cb.checked = false; });
    summaryTextarea.dataset.manualEdit = '';
    setDefaultDate();
}

// ==================== UTILITY FUNCTIONS ====================
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Global fonksiyonlar (onclick için)
window.removeMonitoringLink = removeMonitoringLink;
window.removeCountry = removeCountry;
window.removeService = removeService;
window.removeAction = removeAction;
window.removeIpAddress = removeIpAddress;