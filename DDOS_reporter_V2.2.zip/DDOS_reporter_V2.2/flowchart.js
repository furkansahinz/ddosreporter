// DDOS Akış Şeması - ING Bank
// Bağımsız modül - Ana rapor sistemi ile çakışmaz

// ==================== STATE MANAGEMENT ====================
let flowState = {
    fpAcceptedAtStep: null, // FP kabul edilen adım numarası (3-8 arası)
    steps: {} // Her adımın durumu
};

// ==================== DOM ELEMENTS ====================
const backToReportBtn = document.getElementById('backToReportBtn');
const flowchartForm = document.getElementById('flowchartForm');
const reportDate = document.getElementById('reportDate');
const reportTime = document.getElementById('reportTime');
const reporterName = document.getElementById('reporterName');
const generateFlowPDFBtn = document.getElementById('generateFlowPDFBtn');
const resetFlowBtn = document.getElementById('resetFlowBtn');

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    setDefaultDateTime();
    setupEventListeners();
    initializeSteps();
});

// Varsayılan tarih ve saat (Türkiye formatı: DD.MM.YYYY ve HH:mm)
function setDefaultDateTime() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    
    // Türkiye formatı: DD.MM.YYYY
    reportDate.value = `${day}.${month}.${year}`;
    // 24 saatlik format: HH:mm
    reportTime.value = `${hours}:${minutes}`;
}

// Tarih formatını DD.MM.YYYY'den Date objesine çevirme
function parseTRDate(dateStr) {
    const parts = dateStr.split('.');
    if (parts.length !== 3) return null;
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1; // Month is 0-indexed
    const year = parseInt(parts[2], 10);
    return new Date(year, month, day);
}

// Saat formatını kontrol etme (HH:mm)
function isValidTime(timeStr) {
    const pattern = /^([0-1][0-9]|2[0-3]):([0-5][0-9])$/;
    return pattern.test(timeStr);
}

// Tarih formatını kontrol etme (DD.MM.YYYY)
function isValidDate(dateStr) {
    const pattern = /^(0[1-9]|[12][0-9]|3[01])\.(0[1-9]|1[0-2])\.\d{4}$/;
    return pattern.test(dateStr);
}

// Event listener'ları kur
function setupEventListeners() {
    // Geri dön butonu
    backToReportBtn.addEventListener('click', function() {
        window.location.href = 'index.html';
    });

    // PDF oluştur
    generateFlowPDFBtn.addEventListener('click', handleFlowPDFGeneration);

    // Formu temizle
    resetFlowBtn.addEventListener('click', resetFlowForm);

    // Her adım için checkbox event listener
    for (let i = 1; i <= 8; i++) {
        const checkbox = document.getElementById(`step${i}Check`);
        const timeInput = document.getElementById(`step${i}Time`);
        
        checkbox.addEventListener('change', function() {
            handleStepCheckboxChange(i, this.checked);
        });

        // FP butonları (3-8 arası)
        if (i >= 3) {
            const fpBtn = document.getElementById(`fpBtn${i}`);
            fpBtn.addEventListener('click', function() {
                handleFPAccepted(i);
            });
        }
    }
}

// Adımları başlat
function initializeSteps() {
    for (let i = 1; i <= 8; i++) {
        flowState.steps[i] = {
            checked: false,
            date: '',
            time: '',
            extra: '',
            fpAccepted: false
        };
    }
}

// ==================== CHECKBOX HANDLING ====================
function handleStepCheckboxChange(stepNum, isChecked) {
    flowState.steps[stepNum].checked = isChecked;
    
    const stepContent = document.getElementById(`step${stepNum}Content`);
    const dateInput = document.getElementById(`step${stepNum}Date`);
    const timeInput = document.getElementById(`step${stepNum}Time`);
    
    if (isChecked) {
        // İçerik alanını göster ve tarih/saat alanlarını aktif et
        stepContent.classList.add('active');
        dateInput.disabled = false;
        dateInput.required = true;
        timeInput.disabled = false;
        timeInput.required = true;
        
        // Varsayılan tarih ve saat değerlerini otomatik doldur
        if (!dateInput.value) {
            const now = new Date();
            const day = String(now.getDate()).padStart(2, '0');
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const year = now.getFullYear();
            dateInput.value = `${day}.${month}.${year}`;
        }
        
        if (!timeInput.value) {
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            timeInput.value = `${hours}:${minutes}`;
        }
        
        // Ek alanlar varsa (SIR, USOM, Global SIR) aktif et
        if (stepNum === 5) {
            document.getElementById('step5SIR').disabled = false;
        }
        if (stepNum === 7) {
            document.getElementById('step7USOM').disabled = false;
        }
        if (stepNum === 8) {
            document.getElementById('step8GlobalSIR').disabled = false;
        }
        
        // FP butonu varsa (3-8) aktif et
        if (stepNum >= 3) {
            document.getElementById(`fpBtn${stepNum}`).disabled = false;
        }
    } else {
        // İçerik alanını gizle ve tarih/saat alanlarını pasif et
        stepContent.classList.remove('active');
        dateInput.disabled = true;
        dateInput.required = false;
        dateInput.value = '';
        timeInput.disabled = true;
        timeInput.required = false;
        timeInput.value = '';
        
        // Ek alanları temizle
        if (stepNum === 5) {
            const sirInput = document.getElementById('step5SIR');
            sirInput.disabled = true;
            sirInput.value = '';
        }
        if (stepNum === 7) {
            const usomInput = document.getElementById('step7USOM');
            usomInput.disabled = true;
            usomInput.value = '';
        }
        if (stepNum === 8) {
            const globalSirInput = document.getElementById('step8GlobalSIR');
            globalSirInput.disabled = true;
            globalSirInput.value = '';
        }
        
        // FP butonu varsa pasif et
        if (stepNum >= 3) {
            const fpBtn = document.getElementById(`fpBtn${stepNum}`);
            fpBtn.disabled = true;
            fpBtn.classList.remove('active');
        }
        
        // Eğer bu adımda FP kabul edildiyse, sıfırla
        if (flowState.fpAcceptedAtStep === stepNum) {
            flowState.fpAcceptedAtStep = null;
            enableStepsAfter(stepNum);
        }
    }
}

// ==================== FP (FALSE POSITIVE) HANDLING ====================
function handleFPAccepted(stepNum) {
    if (confirm(`Adım ${stepNum}'de FP (False Positive) kabul edilecek. Bu adımdan sonraki tüm adımlar devre dışı kalacaktır. Onaylıyor musunuz?`)) {
        flowState.fpAcceptedAtStep = stepNum;
        flowState.steps[stepNum].fpAccepted = true;
        
        // FP butonunu vurgula
        const fpBtn = document.getElementById(`fpBtn${stepNum}`);
        fpBtn.classList.add('active');
        fpBtn.textContent = 'FP Kabul Edildi ✓';
        
        // Sonraki adımları devre dışı bırak
        disableStepsAfter(stepNum);
        
        alert(`Adım ${stepNum}'den sonraki tüm adımlar devre dışı bırakıldı.`);
    }
}

function disableStepsAfter(stepNum) {
    for (let i = stepNum + 1; i <= 8; i++) {
        const flowStep = document.querySelector(`.flow-step[data-step="${i}"]`);
        const checkbox = document.getElementById(`step${i}Check`);
        
        // Adımı görsel olarak devre dışı bırak
        flowStep.classList.add('disabled');
        checkbox.disabled = true;
        checkbox.checked = false;
        
        // İçeriği gizle
        handleStepCheckboxChange(i, false);
    }
}

function enableStepsAfter(stepNum) {
    for (let i = stepNum + 1; i <= 8; i++) {
        const flowStep = document.querySelector(`.flow-step[data-step="${i}"]`);
        const checkbox = document.getElementById(`step${i}Check`);
        
        // Adımı tekrar aktif et
        flowStep.classList.remove('disabled');
        checkbox.disabled = false;
    }
}

// ==================== PDF GENERATION ====================
async function handleFlowPDFGeneration(e) {
    e.preventDefault();
    
    try {
        // Form validasyonu
        if (!validateFlowForm()) {
            return;
        }
        
        // State'i güncelle
        updateFlowState();
        
        // PDF içeriğini oluştur
        const pdfContent = document.getElementById('flowPdfContent');
        pdfContent.innerHTML = generateFlowPDFContent();
        
        // DOM render bekleme
        await new Promise(resolve => setTimeout(resolve, 100));
        
        // PDF oluştur
        await createFlowPDF();
        
    } catch (error) {
        alert('PDF oluşturulurken bir hata oluştu: ' + error.message);
        console.error(error);
    }
}

function validateFlowForm() {
    // Rapor tarihi kontrolü
    if (!reportDate.value) {
        alert('Lütfen rapor tarihini giriniz.');
        return false;
    }
    
    if (!isValidDate(reportDate.value)) {
        alert('Lütfen geçerli bir tarih giriniz (DD.MM.YYYY formatında, örn: 12.02.2026).');
        return false;
    }
    
    // Rapor saati kontrolü
    if (!reportTime.value) {
        alert('Lütfen rapor saatini giriniz.');
        return false;
    }
    
    if (!isValidTime(reportTime.value)) {
        alert('Lütfen geçerli bir saat giriniz (HH:mm formatında 24 saatlik, örn: 14:35).');
        return false;
    }
    
    if (!reporterName.value || !reporterName.value.trim()) {
        alert('Lütfen raporlayan adını giriniz.');
        return false;
    }
    
    // En az bir adım seçilmiş mi?
    const anyStepChecked = Object.values(flowState.steps).some(step => step.checked);
    if (!anyStepChecked) {
        alert('Lütfen en az bir akış adımı seçiniz.');
        return false;
    }
    
    // Seçili adımlar için tarih ve saat kontrolü
    for (let i = 1; i <= 8; i++) {
        if (flowState.steps[i].checked) {
            const dateInput = document.getElementById(`step${i}Date`);
            const timeInput = document.getElementById(`step${i}Time`);
            
            if (!dateInput.value) {
                alert(`Lütfen Adım ${i} için tarih bilgisi giriniz.`);
                return false;
            }
            if (!isValidDate(dateInput.value)) {
                alert(`Adım ${i} için geçerli bir tarih giriniz (DD.MM.YYYY formatında, örn: 12.02.2026).`);
                return false;
            }
            
            if (!timeInput.value) {
                alert(`Lütfen Adım ${i} için saat bilgisi giriniz.`);
                return false;
            }
            if (!isValidTime(timeInput.value)) {
                alert(`Adım ${i} için geçerli bir saat giriniz (HH:mm formatında 24 saatlik, örn: 14:35).`);
                return false;
            }
        }
    }
    
    return true;
}

function updateFlowState() {
    for (let i = 1; i <= 8; i++) {
        if (flowState.steps[i].checked) {
            const dateInput = document.getElementById(`step${i}Date`);
            const timeInput = document.getElementById(`step${i}Time`);
            flowState.steps[i].date = dateInput.value;
            flowState.steps[i].time = timeInput.value;
            
            // Ek alanlar
            if (i === 5) {
                flowState.steps[i].extra = document.getElementById('step5SIR').value || '';
            }
            if (i === 7) {
                flowState.steps[i].extra = document.getElementById('step7USOM').value || '';
            }
            if (i === 8) {
                flowState.steps[i].extra = document.getElementById('step8GlobalSIR').value || '';
            }
        }
    }
}

function generateFlowPDFContent() {
    const dateStr = reportDate.value;
    const timeStr = reportTime.value;
    const reporter = reporterName.value;
    
    // Tarih formatı (DD.MM.YYYY HH:mm formatında birleştir)
    const formattedDateTime = `${dateStr} ${timeStr}`;
    
    // Adım isimleri
    const stepNames = {
        1: 'DDOS maili geldi',
        2: 'ISP sorgulama için iletildi',
        3: 'Altyapı güvenliğe doğrulama için bu bildirim ile iletildi',
        4: 'Lesson Learned raporu güvenlik mimari ekibi tarafından yazıldı',
        5: 'SIR kaydı açıldı',
        6: 'DDOS bildirisi yapıldı',
        7: 'USOM kaydı açıldı',
        8: 'Global kayıt açıldı'
    };
    
    let stepsHTML = '';
    const fpStep = flowState.fpAcceptedAtStep;
    
    for (let i = 1; i <= 8; i++) {
        // FP kabul edildiyse ve bu adımdan sonraysa gösterme
        if (fpStep && i > fpStep) {
            continue;
        }
        
        // Sadece seçili adımları göster
        if (flowState.steps[i].checked) {
            const stepData = flowState.steps[i];
            const isFPStep = (i === fpStep);
            
            stepsHTML += `
                <div class="pdf-step">
                    <div>
                        <span class="pdf-step-number">${i}.</span>
                        <span class="pdf-step-text">${stepNames[i]}</span>
                    </div>
                    <div class="pdf-step-time">Tarih: ${stepData.date} - Saat: ${stepData.time}</div>`;
            
            // Ek bilgiler (SIR, USOM, Global SIR)
            if (i === 5 && stepData.extra) {
                stepsHTML += `<div class="pdf-step-extra">SIR No: ${stepData.extra}</div>`;
            }
            if (i === 7 && stepData.extra) {
                stepsHTML += `<div class="pdf-step-extra">USOM No: ${stepData.extra}</div>`;
            }
            if (i === 8 && stepData.extra) {
                stepsHTML += `<div class="pdf-step-extra">Global SIR Kaydi No: ${stepData.extra}</div>`;
            }
            
            // FP bildirimi
            if (isFPStep) {
                stepsHTML += `<div class="pdf-fp-notice">⚠ FP (False Positive) olarak değerlendirildi</div>`;
            }
            
            stepsHTML += `</div>`;
        }
    }
    
    return `
        <div class="pdf-section">
            <div class="pdf-section-title">Rapor Bilgileri</div>
            <div class="pdf-field">
                <span class="pdf-field-label">Rapor Tarihi & Saati:</span>
                <span class="pdf-field-value">${formattedDateTime}</span>
            </div>
            <div class="pdf-field">
                <span class="pdf-field-label">Raporlayan:</span>
                <span class="pdf-field-value">${reporter}</span>
            </div>
        </div>
        
        <div class="pdf-section">
            <div class="pdf-section-title">DDOS Akış Adımları</div>
            ${stepsHTML}
        </div>
    `;
}

// ==================== PDF CREATION ====================
var FLOW_PDF_HEADER_H_MM = 18;
var FLOW_PDF_FOOTER_H_MM = 10;
var FLOW_PDF_ING_ORANGE = { r: 255, g: 98, b: 0 };
var FLOW_PDF_MARGIN_X_MM = 14;

function drawFlowPdfPageHeader(pdf) {
    var w = pdf.internal.pageSize.getWidth();
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(16);
    pdf.setTextColor(FLOW_PDF_ING_ORANGE.r, FLOW_PDF_ING_ORANGE.g, FLOW_PDF_ING_ORANGE.b);
    pdf.text('ING BANK', FLOW_PDF_MARGIN_X_MM, 10);
    pdf.setTextColor(0, 0, 0);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(18);
    pdf.text('DDOS Akis Semasi', w - FLOW_PDF_MARGIN_X_MM, 10, { align: 'right' });
    pdf.setDrawColor(FLOW_PDF_ING_ORANGE.r, FLOW_PDF_ING_ORANGE.g, FLOW_PDF_ING_ORANGE.b);
    pdf.setLineWidth(0.5);
    pdf.line(FLOW_PDF_MARGIN_X_MM, 14.5, w - FLOW_PDF_MARGIN_X_MM, 14.5);
}

function drawFlowPdfPageFooter(pdf) {
    var w = pdf.internal.pageSize.getWidth();
    var h = pdf.internal.pageSize.getHeight();
    pdf.setDrawColor(160, 160, 160);
    pdf.setLineWidth(0.5);
    pdf.line(FLOW_PDF_MARGIN_X_MM, h - 8, w - FLOW_PDF_MARGIN_X_MM, h - 8);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(9);
    pdf.setTextColor(90, 90, 90);
    pdf.text('Siber Güvenlik Savunma Merkezi', w / 2, h - 5, { align: 'center' });
}

async function createFlowPDF() {
    var pdfContent = document.getElementById('flowPdfContent');
    
    pdfContent.style.visibility = 'visible';
    pdfContent.style.position = 'fixed';
    pdfContent.style.left = '0';
    pdfContent.style.top = '0';
    pdfContent.style.zIndex = '9999';
    
    var contentH = Math.max(pdfContent.scrollHeight, 800);
    var canvas = await html2canvas(pdfContent, {
        scale: 1.5,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        windowWidth: 794,
        windowHeight: contentH,
        removeContainer: false,
        imageTimeout: 0,
        allowTaint: false
    });
    
    var contentRect = pdfContent.getBoundingClientRect();
    var sectionBounds = [];
    pdfContent.querySelectorAll('.pdf-section, .pdf-step').forEach(function (el) {
        var r = el.getBoundingClientRect();
        var topPx = r.top - contentRect.top;
        sectionBounds.push({ topPx: topPx, hPx: r.height });
    });
    
    pdfContent.style.visibility = 'hidden';
    pdfContent.style.position = 'fixed';
    pdfContent.style.left = '-9999px';
    
    var pdf = new window.jspdf.jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4', compress: true });
    var pdfW = pdf.internal.pageSize.getWidth();
    var pdfH = pdf.internal.pageSize.getHeight();
    var contentAreaH = pdfH - FLOW_PDF_HEADER_H_MM - FLOW_PDF_FOOTER_H_MM;
    
    var imgData = canvas.toDataURL('image/jpeg', 0.85);
    var imgW = canvas.width;
    var imgH = canvas.height;
    var ratio = pdfW / imgW;
    var imgScaledW = imgW * ratio;
    var imgScaledH = imgH * ratio;
    
    var boundsMm = sectionBounds.map(function (s) {
        return {
            top: s.topPx * 1.5 * ratio,
            bottom: (s.topPx + s.hPx) * 1.5 * ratio
        };
    });
    
    function getSafePageStarts() {
        var breakPoints = [0];
        boundsMm.forEach(function (s) {
            breakPoints.push(s.top);
            breakPoints.push(s.bottom);
        });
        breakPoints.push(imgScaledH);
        breakPoints.sort(function (a, b) { return a - b; });
        var starts = [0];
        var cur = 0;
        while (cur < imgScaledH) {
            var maxEnd = cur + contentAreaH;
            var bestEnd = cur;
            for (var j = 0; j < breakPoints.length; j++) {
                if (breakPoints[j] > cur && breakPoints[j] <= maxEnd) bestEnd = breakPoints[j];
                if (breakPoints[j] > maxEnd) break;
            }
            if (bestEnd <= cur) bestEnd = Math.min(cur + contentAreaH, imgScaledH);
            starts.push(bestEnd);
            cur = bestEnd;
        }
        return starts;
    }

    function fillHeaderFooterGap(pdf) {
        var w = pdf.internal.pageSize.getWidth();
        var h = pdf.internal.pageSize.getHeight();
        pdf.setFillColor(255, 255, 255);
        pdf.rect(0, 0, w, FLOW_PDF_HEADER_H_MM, 'F');
        pdf.rect(0, h - FLOW_PDF_FOOTER_H_MM, w, FLOW_PDF_FOOTER_H_MM, 'F');
    }

    if (imgScaledH <= contentAreaH) {
        pdf.addImage(imgData, 'JPEG', 0, FLOW_PDF_HEADER_H_MM, imgScaledW, imgScaledH, undefined, 'FAST');
        fillHeaderFooterGap(pdf);
        drawFlowPdfPageHeader(pdf);
        drawFlowPdfPageFooter(pdf);
    } else {
        var pageStarts = getSafePageStarts();
        for (var i = 0; i < pageStarts.length - 1; i++) {
            if (i > 0) pdf.addPage();
            pdf.addImage(imgData, 'JPEG', 0, FLOW_PDF_HEADER_H_MM - pageStarts[i], imgScaledW, imgScaledH, undefined, 'FAST');
            fillHeaderFooterGap(pdf);
            drawFlowPdfPageHeader(pdf);
            drawFlowPdfPageFooter(pdf);
        }
    }
    
    pdf.setProperties({
        title: 'DDOS Akış Şeması',
        subject: 'DDOS Akış Şeması Raporu',
        author: 'ING Bank',
        creator: 'DDOS Reporter',
        producer: 'DDOS Reporter'
    });
    
    var blob = pdf.output('blob');
    var mb = blob.size / (1024 * 1024);
    console.log('PDF boyutu: ' + mb.toFixed(2) + ' MB');
    
    // Dosya adı için tarih formatı (DD.MM.YYYY)
    var now = new Date();
    var day = String(now.getDate()).padStart(2, '0');
    var month = String(now.getMonth() + 1).padStart(2, '0');
    var year = now.getFullYear();
    var dateStr = day + '.' + month + '.' + year;
    
    pdf.save('DDOS_Akis_Semasi_' + dateStr + '.pdf');
}

// ==================== RESET FORM ====================
function resetFlowForm() {
    if (confirm('Tüm form verileri temizlenecektir. Onaylıyor musunuz?')) {
        flowchartForm.reset();
        setDefaultDateTime();
        initializeSteps();
        
        // Tüm adımları sıfırla
        for (let i = 1; i <= 8; i++) {
            const flowStep = document.querySelector(`.flow-step[data-step="${i}"]`);
            const checkbox = document.getElementById(`step${i}Check`);
            const stepContent = document.getElementById(`step${i}Content`);
            const dateInput = document.getElementById(`step${i}Date`);
            const timeInput = document.getElementById(`step${i}Time`);
            
            flowStep.classList.remove('disabled');
            checkbox.disabled = false;
            checkbox.checked = false;
            stepContent.classList.remove('active');
            dateInput.disabled = true;
            dateInput.value = '';
            timeInput.disabled = true;
            timeInput.value = '';
            
            // Ek alanlar
            if (i === 5) {
                const sirInput = document.getElementById('step5SIR');
                sirInput.disabled = true;
                sirInput.value = '';
            }
            if (i === 7) {
                const usomInput = document.getElementById('step7USOM');
                usomInput.disabled = true;
                usomInput.value = '';
            }
            if (i === 8) {
                const globalSirInput = document.getElementById('step8GlobalSIR');
                globalSirInput.disabled = true;
                globalSirInput.value = '';
            }
            
            // FP butonları
            if (i >= 3) {
                const fpBtn = document.getElementById(`fpBtn${i}`);
                fpBtn.disabled = true;
                fpBtn.classList.remove('active');
                fpBtn.textContent = 'FP Kabul Edildi';
            }
        }
    }
}
